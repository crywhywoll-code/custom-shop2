# time个 — Stage 36: Music Widget Studio

Based on the Stage 35 project archive.

## Added
- Music widget appearance model persisted in SharedPreferences.
- Per-widget panel background color and an optional photo rendered inside the widget bounds, with rounded corners and adjustable overlay opacity.
- Text color, title/artist sizes, padding, corner radius, artwork size, status visibility, and playback-control visibility.
- Auto / vertical / horizontal layout selection; auto follows launcher-reported widget dimensions.
- Album artwork capture from Android MediaSession metadata (`METADATA_KEY_ART`, fallback `METADATA_KEY_ALBUM_ART`).
- Previous, play/pause, and next buttons routed through a non-exported broadcast receiver to active media sessions.
- Compose controls in Widget Studio to change the above settings without rebuilding the app.

## Validation
- Project validation script: passed (including Stage 36 checks).
- Android XML parsing: passed.
- Kotlin delimiter sanity: passed.
- Full Gradle compilation: not run in this environment. Confirm with GitHub Actions before treating the APK as build-ready.

## Notes
- Album art appears only when the active media app exposes artwork through its Android media session metadata.
- Playback commands depend on the active player exposing transport controls and time个 retaining notification-listener access.
- Layout changes and styling apply to all current music widget instances (global music-widget style for this stage).
