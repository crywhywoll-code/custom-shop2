#!/usr/bin/env python3
"""Offline structural checks for the time个 Android project."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
required = [
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/example/glasstime/MainActivity.kt",
    "app/src/main/java/com/example/glasstime/Theme.kt",
    "app/src/main/java/com/example/glasstime/AssistantScreen.kt",
    "app/src/main/java/com/example/glasstime/AdvancedSocialScreen.kt",
    "gen.py",
]
for rel in required:
    if not (ROOT / rel).is_file(): errors.append(f"Missing: {rel}")

def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.exists() else ""

main = read("app/src/main/java/com/example/glasstime/MainActivity.kt")
style = read("app/src/main/java/com/example/glasstime/Screens.kt")
assistant = read("app/src/main/java/com/example/glasstime/AssistantScreen.kt")
theme = read("app/src/main/java/com/example/glasstime/Theme.kt")
gradle = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
checks = {
    "6-tab pager": "pageCount = { 6 }" in main,
    "splash fixed branding": '"time个"' in main and '"by kodokuzawa"' in main,
    "splash animation settings": all(x in theme for x in ("splashEnabled", "splashDuration", "splashAnimation")),
    "assistant confirmation": "Подготовить предложение" in assistant and "Применить" in assistant,
    "assistant undo": "Отменить последнее изменение" in assistant,
    "global font settings": "globalFont" in theme and "Глобальная типографика" in style,
    "glass shape controls": "cardRadius" in theme and "borderAlpha" in theme,
    "Compose animation dependency": "androidx.compose.animation:animation" in gradle,
    "release version": 'versionName = "1.1.0"' in gradle and "versionCode = 2" in gradle,
    "Android app label": 'android:label=' in manifest,
    "local backup covers appearance": '"glass"' in read("app/src/main/java/com/example/glasstime/AdvancedSocialScreen.kt"),
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + "  " + label)
    if not ok: errors.append(label)

# Basic delimiter sanity for changed Kotlin sources (not a substitute for Gradle compilation).
for rel in [
    "app/src/main/java/com/example/glasstime/MainActivity.kt",
    "app/src/main/java/com/example/glasstime/Glass.kt",
    "app/src/main/java/com/example/glasstime/Screens.kt",
    "app/src/main/java/com/example/glasstime/ProfileScreen.kt",
    "app/src/main/java/com/example/glasstime/Theme.kt",
    "app/src/main/java/com/example/glasstime/AssistantScreen.kt",
]:
    src = read(rel)
    # Remove strings and comments to avoid counting braces inside them.
    stripped = re.sub(r'"(?:\\.|[^"\\])*"', '""', src)
    stripped = re.sub(r'//[^\n]*', '', stripped)
    for left, right in [('(', ')'), ('{', '}'), ('[', ']')]:
        if stripped.count(left) != stripped.count(right):
            errors.append(f"Unbalanced {left}{right}: {rel}")
            print("FAIL  delimiter balance: " + rel)
            break
else:
    print("PASS  Kotlin delimiter sanity")

if errors:
    print(f"\nValidation failed: {len(errors)} issue(s)")
    sys.exit(1)
print(f"\nValidation passed: {len(checks) + 1} checks")
