package com.example.glasstime

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream

/** Safe, local catalog for KWGT preset archives. It extracts resources for inspection;
 * it does not execute Kustom formulas or claim native KWGT runtime compatibility. */
object KwgtImportManager {
    private const val PREFS = "kwgt_imports"
    private const val KEY_ITEMS = "items"
    private const val MAX_ARCHIVE_BYTES = 32L * 1024 * 1024
    private const val MAX_EXTRACTED_BYTES = 64L * 1024 * 1024
    private const val MAX_ENTRIES = 500
    private const val MAX_ENTRY_BYTES = 16L * 1024 * 1024
    private val allowedPreview = setOf("png", "jpg", "jpeg", "webp")

    data class ImportedPreset(
        val id: String,
        val name: String,
        val importedAt: Long,
        val entryCount: Int,
        val resourceCount: Int,
        val previewName: String,
        val folderName: String
    )

    fun imports(context: Context): List<ImportedPreset> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id").takeIf { it.matches(Regex("[a-f0-9-]{36}")) } ?: return@mapNotNull null
            ImportedPreset(id, o.optString("name", "KWGT preset").take(80), o.optLong("importedAt"),
                o.optInt("entryCount"), o.optInt("resourceCount"), o.optString("previewName"), o.optString("folderName"))
        }
    }.getOrDefault(emptyList())

    fun import(context: Context, uri: Uri, displayName: String?): ImportedPreset {
        val name = (displayName ?: "KWGT preset").substringAfterLast('/').take(80).ifBlank { "KWGT preset" }
        val id = UUID.randomUUID().toString()
        val root = File(context.filesDir, "kwgt_imports/$id")
        check(root.mkdirs() || root.isDirectory) { "Не удалось создать папку импорта" }
        var entries = 0
        var extracted = 0L
        var resources = 0
        var preview = ""
        try {
            val input = context.contentResolver.openInputStream(uri) ?: error("Не удалось открыть файл")
            val buffered = input.buffered()
            // Check the archive size without trusting the provider's reported length.
            val bytes = buffered.use { stream ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0L
                while (true) {
                    val n = stream.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= MAX_ARCHIVE_BYTES) { "Архив больше 32 МБ" }
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
            require(bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) {
                "Файл не распознан как ZIP-архив KWGT"
            }
            ZipInputStream(bytes.inputStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    require(entries <= MAX_ENTRIES) { "В архиве слишком много файлов" }
                    val rawPath = entry.name.replace('\\', '/')
                    require(!rawPath.startsWith('/') && !rawPath.split('/').any { it == ".." }) {
                        "В архиве обнаружен небезопасный путь"
                    }
                    if (!entry.isDirectory) {
                        val target = File(root, rawPath).canonicalFile
                        require(target.path.startsWith(root.canonicalPath + File.separator)) { "Недопустимый путь в архиве" }
                        target.parentFile?.mkdirs()
                        var entryBytes = 0L
                        target.outputStream().buffered().use { out ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val n = zip.read(buffer)
                                if (n < 0) break
                                entryBytes += n
                                extracted += n
                                require(entryBytes <= MAX_ENTRY_BYTES && extracted <= MAX_EXTRACTED_BYTES) {
                                    "Распакованные данные превышают допустимый размер"
                                }
                                out.write(buffer, 0, n)
                            }
                        }
                        val ext = target.extension.lowercase()
                        if (ext in allowedPreview) {
                            resources++
                            if (preview.isBlank() || target.name.contains("preview", true) || target.name.contains("thumbnail", true)) {
                                preview = target.relativeTo(root).invariantSeparatorsPath
                            }
                        } else if (ext in setOf("json", "xml", "komp", "klwp", "kwgt", "ttf", "otf", "gif", "mp4", "webm")) {
                            resources++
                        }
                    }
                    zip.closeEntry()
                }
            }
            require(entries > 0) { "Архив пустой" }
            val result = ImportedPreset(id, name.removeSuffix(".kwgt").removeSuffix(".zip"), System.currentTimeMillis(), entries, resources, preview, id)
            val all = (listOf(result) + imports(context)).take(30)
            val json = JSONArray()
            all.forEach { item ->
                json.put(JSONObject().put("id", item.id).put("name", item.name).put("importedAt", item.importedAt)
                    .put("entryCount", item.entryCount).put("resourceCount", item.resourceCount)
                    .put("previewName", item.previewName).put("folderName", item.folderName))
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, json.toString()).apply()
            return result
        } catch (error: Throwable) {
            root.deleteRecursively()
            throw error
        }
    }

    fun previewBitmap(context: Context, preset: ImportedPreset): android.graphics.Bitmap? {
        if (preset.previewName.isBlank()) return null
        val file = File(context.filesDir, "kwgt_imports/${preset.folderName}/${preset.previewName}")
        if (!file.isFile || !file.canonicalPath.startsWith(File(context.filesDir, "kwgt_imports/${preset.folderName}").canonicalPath + File.separator)) return null
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 1000 || bounds.outHeight / sample > 1000) sample *= 2
        return android.graphics.BitmapFactory.decodeFile(file.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun openInKustom(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("org.kustom.widget") ?: return false
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun delete(context: Context, preset: ImportedPreset) {
        File(context.filesDir, "kwgt_imports/${preset.folderName}").deleteRecursively()
        val remaining = imports(context).filterNot { it.id == preset.id }
        val json = JSONArray()
        remaining.forEach { item ->
            json.put(JSONObject().put("id", item.id).put("name", item.name).put("importedAt", item.importedAt)
                .put("entryCount", item.entryCount).put("resourceCount", item.resourceCount)
                .put("previewName", item.previewName).put("folderName", item.folderName))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, json.toString()).apply()
    }
}
