package com.example.glasstime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class CommunityPost(
    val id: String,
    val communityId: String,
    val authorId: String,
    val text: String,
    val createdAt: Long,
    val pinned: Boolean = false,
    val likes: Int = 0,
    val liked: Boolean = false,
    val comments: List<String> = emptyList()
)

object CommunityPostStore {
    private const val PREFS = "community_discussions"
    private const val KEY = "posts_v1"

    fun load(context: Context, communityId: String): List<CommunityPost> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    if (item.optString("communityId") != communityId) continue
                    val commentsJson = item.optJSONArray("comments") ?: JSONArray()
                    val comments = buildList {
                        for (j in 0 until commentsJson.length()) {
                            val value = commentsJson.optString(j).take(300)
                            if (value.isNotBlank()) add(value)
                        }
                    }
                    val text = item.optString("text").trim().take(500)
                    if (text.isNotBlank()) add(CommunityPost(
                        id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        communityId = communityId,
                        authorId = item.optString("authorId").take(80),
                        text = text,
                        createdAt = item.optLong("createdAt", 0L),
                        pinned = item.optBoolean("pinned", false),
                        likes = item.optInt("likes", 0).coerceAtLeast(0),
                        liked = item.optBoolean("liked", false),
                        comments = comments
                    ))
                }
            }.sortedWith(compareByDescending<CommunityPost> { it.pinned }.thenByDescending { it.createdAt })
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, posts: List<CommunityPost>) {
        val array = JSONArray()
        posts.take(300).forEach { post ->
            val comments = JSONArray().apply { post.comments.take(100).forEach { put(it.take(300)) } }
            array.put(JSONObject().apply {
                put("id", post.id); put("communityId", post.communityId); put("authorId", post.authorId)
                put("text", post.text.take(500)); put("createdAt", post.createdAt)
                put("pinned", post.pinned); put("likes", post.likes.coerceAtLeast(0))
                put("liked", post.liked); put("comments", comments)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun newPost(communityId: String, authorId: String, text: String) = CommunityPost(
        id = UUID.randomUUID().toString(), communityId = communityId, authorId = authorId,
        text = text.trim().take(500), createdAt = System.currentTimeMillis()
    )
}
