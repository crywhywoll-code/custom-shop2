package com.example.glasstime.domain.repository

interface NavigationRepository {
    fun selectedTab(): Int
    fun saveSelectedTab(tab: Int)
}
