package com.example.glasstime

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val communityAccents = listOf(
    0xFF9CCFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFB8A1D9.toInt(),
    0xFFB65A70.toInt(), 0xFFD0F59A.toInt(), 0xFF777F89.toInt()
)
private val communityPanels = listOf(
    0xFF252B33.toInt(), 0xFF08090B.toInt(), 0xFF3A3030.toInt(),
    0xFF182D45.toInt(), 0xFF342744.toInt(), 0xFF3B3D40.toInt()
)

@Composable
fun CommunityHubScreen(t: ThemeState, onBack: () -> Unit) {
    val context = LocalContext.current
    val userId = remember(context) { ProfileStore.localId(context) }
    val communities = remember(context) { mutableStateListOf<LocalCommunity>().apply { addAll(CommunityStore.load(context)) } }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("COMMUNITY") }
    var isPrivate by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf("") }
    var imageVersion by remember { mutableIntStateOf(0) }
    var postDraft by remember { mutableStateOf("") }
    var commentDraft by remember { mutableStateOf("") }
    var commentTarget by remember { mutableStateOf<CommunityPost?>(null) }
    val discussionPosts = remember(selectedId) {
        mutableStateListOf<CommunityPost>().apply { selectedId?.let { addAll(CommunityPostStore.load(context, it)) } }
    }
    val selected = communities.firstOrNull { it.id == selectedId }
    val avatar = remember(selectedId, imageVersion) {
        selectedId?.let { CommunityStore.loadImage(context, it, false)?.asImageBitmap() }
    }
    val banner = remember(selectedId, imageVersion) {
        selectedId?.let { CommunityStore.loadImage(context, it, true)?.asImageBitmap() }
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val id = selectedId
        if (uri != null && id != null) runCatching { CommunityStore.copyImage(context, id, uri, false) }
            .onSuccess { imageVersion++; feedback = "Аватар сообщества обновлён" }
            .onFailure { feedback = it.message ?: "Не удалось сохранить аватар" }
    }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val id = selectedId
        if (uri != null && id != null) runCatching { CommunityStore.copyImage(context, id, uri, true) }
            .onSuccess { imageVersion++; feedback = "Баннер сообщества обновлён" }
            .onFailure { feedback = it.message ?: "Не удалось сохранить баннер" }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                GText(t, if (selected == null) "Сообщества и кланы" else selected.name, 25, true)
                TextButton(onClick = { if (selected != null) selectedId = null else onBack() }) {
                    Text(if (selected != null) "Назад" else "Профиль")
                }
            }
        }
        if (selected == null) {
            item {
                GlassCard(t) {
                    GText(t, "Твои пространства", 16, true)
                    GText(t, "Создавай сообщества для обсуждений или кланы с короткими тегами вроде [VOID].", 12, secondary = true)
                    Spacer(Modifier.height(10.dp))
                    GButton(t, "+ Создать сообщество или клан", Modifier.fillMaxWidth()) {
                        name = ""; tag = ""; description = ""; kind = "COMMUNITY"; isPrivate = false; showCreate = true
                    }
                }
            }
            if (communities.isEmpty()) {
                item { GlassCard(t) { GText(t, "Пока нет сообществ", 14, true); GText(t, "Создай первое пространство — оно сохранится на этом устройстве.", 11, secondary = true) } }
            }
            items(communities, key = { it.id }) { community ->
                GlassCard(t, Modifier.clickable { selectedId = community.id }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            GText(t, community.name, 16, true)
                            GText(t, "[${community.tag}] · ${if (community.kind == "CLAN") "Клан" else "Сообщество"}", 11, secondary = true)
                        }
                        GText(t, if (community.isPrivate) "ЗАКРЫТОЕ" else "ОТКРЫТОЕ", 9, true)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (community.description.isNotBlank()) GText(t, community.description, 12)
                    GText(t, "Участников: ${community.memberCount} · заявок: ${community.requests.size}", 10, secondary = true)
                    Spacer(Modifier.height(6.dp))
                    GButton(t, "Открыть", Modifier.fillMaxWidth()) { selectedId = community.id }
                }
            }
        } else {
            val community = selected
            val isMember = community.members.any { it.userId == userId }
            val isOwner = community.ownerId == userId
            val hasRequest = community.requests.any { it.userId == userId }
            item {
                GlassCard(t) {
                    Box(Modifier.fillMaxWidth().height(116.dp).clip(RoundedCornerShape(16.dp)).background(Color(community.panelColor))) {
                        if (banner != null) Image(banner, contentDescription = "Баннер", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(58.dp).clip(CircleShape).background(Color(0xFF454C56))) {
                            if (avatar != null) Image(avatar, contentDescription = "Аватар", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Column(Modifier.weight(1f)) {
                            GText(t, community.name, 18, true)
                            Text("[${community.tag}] · ${if (community.kind == "CLAN") "КЛАН" else "СООБЩЕСТВО"}", color = Color(community.accentColor), fontSize = 11.sp)
                            GText(t, "${community.memberCount} участников", 10, secondary = true)
                        }
                    }
                    if (community.description.isNotBlank()) {
                        Spacer(Modifier.height(8.dp)); GText(t, community.description, 13)
                    }
                    Spacer(Modifier.height(10.dp))
                    if (isOwner) {
                        GButton(t, "Изменить аватар", Modifier.fillMaxWidth()) { avatarPicker.launch("image/*") }
                        Spacer(Modifier.height(6.dp))
                        GButton(t, "Изменить баннер", Modifier.fillMaxWidth()) { bannerPicker.launch("image/*") }
                    } else if (!isMember && !hasRequest) {
                        GButton(t, if (community.isPrivate) "Отправить заявку" else "Вступить", Modifier.fillMaxWidth()) {
                            val next = CommunityStore.join(context, communities.toList(), community.id, userId)
                            communities.clear(); communities.addAll(next)
                            feedback = if (community.isPrivate) "Заявка сохранена локально" else "Ты вступил в пространство"
                        }
                    } else if (hasRequest) {
                        GText(t, "Заявка ожидает рассмотрения владельцем.", 11, secondary = true)
                    } else {
                        GText(t, "Ты участник этого пространства.", 11, secondary = true)
                        if (!isOwner) GButton(t, "Покинуть", Modifier.fillMaxWidth()) {
                            val next = CommunityStore.leave(context, communities.toList(), community.id, userId)
                            communities.clear(); communities.addAll(next)
                        }
                    }
                }
            }
            if (isOwner) {
                item {
                    GlassCard(t) {
                        GText(t, "Оформление пространства", 16, true)
                        GText(t, "Отдельная тема сообщества или клана — не меняет общую тему time个.", 10, secondary = true)
                        Spacer(Modifier.height(8.dp))
                        GText(t, "Акцент", 12, true)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            communityAccents.forEach { color ->
                                Box(Modifier.weight(1f).height(34.dp).clip(RoundedCornerShape(9.dp))
                                    .background(Color(color)).clickable {
                                        val next = CommunityStore.updateAppearance(context, communities.toList(), community.id, color, community.panelColor)
                                        communities.clear(); communities.addAll(next)
                                    })
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        GText(t, "Фон панели", 12, true)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            communityPanels.forEach { color ->
                                Box(Modifier.weight(1f).height(34.dp).clip(RoundedCornerShape(9.dp))
                                    .background(Color(color)).clickable {
                                        val next = CommunityStore.updateAppearance(context, communities.toList(), community.id, community.accentColor, color)
                                        communities.clear(); communities.addAll(next)
                                    })
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(community.panelColor))) {
                            Text("[${community.tag}]  ${community.name}", modifier = Modifier.padding(13.dp), color = Color(community.accentColor), fontSize = 13.sp)
                        }
                    }
                }
                item {
                    GlassCard(t) {
                        GText(t, "Управление участниками", 16, true)
                        GText(t, "Владелец может назначать модераторов и обрабатывать заявки. Сейчас данные локальные.", 10, secondary = true)
                        if (community.requests.isEmpty()) GText(t, "Новых заявок нет.", 12, secondary = true)
                        community.requests.forEach { request ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) { GText(t, request.userId.take(18), 11, true); GText(t, "Заявка на вступление", 9, secondary = true) }
                                TextButton(onClick = {
                                    val next = CommunityStore.reviewRequest(context, communities.toList(), community.id, request.userId, true)
                                    communities.clear(); communities.addAll(next)
                                }) { Text("Принять") }
                                TextButton(onClick = {
                                    val next = CommunityStore.reviewRequest(context, communities.toList(), community.id, request.userId, false)
                                    communities.clear(); communities.addAll(next)
                                }) { Text("Отклонить") }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        community.members.filter { it.role != "OWNER" }.forEach { member ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    GText(t, member.userId.take(18), 11, true)
                                    GText(t, if (member.role == "MODERATOR") "Модератор" else "Участник", 9, secondary = true)
                                }
                                TextButton(onClick = {
                                    val next = CommunityStore.setModerator(context, communities.toList(), community.id, member.userId, member.role != "MODERATOR")
                                    communities.clear(); communities.addAll(next)
                                }) { Text(if (member.role == "MODERATOR") "Снять" else "Назначить") }
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(t) {
                    GText(t, "Роли", 15, true)
                    GText(t, "Владелец · полный контроль. Модератор · будущая модерация публикаций. Участник · доступ к пространству.", 11, secondary = true)
                    GText(t, "Права и заявки пока действуют только в локальном хранилище. Серверная проверка появится вместе с Firebase.", 10, secondary = true)
                }
            }
            if (isMember) {
                item {
                    GlassCard(t) {
                        GText(t, "Обсуждения", 17, true)
                        GText(t, "Публикации внутри этого сообщества или клана.", 10, secondary = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = postDraft,
                            onValueChange = { postDraft = it.take(500) },
                            label = { Text("Новая публикация · до 500 символов") },
                            modifier = Modifier.fillMaxWidth(), minLines = 2
                        )
                        Spacer(Modifier.height(7.dp))
                        GButton(t, "Опубликовать", Modifier.fillMaxWidth()) {
                            val post = CommunityPostStore.newPost(community.id, userId, postDraft)
                            if (post.text.isNotBlank()) {
                                discussionPosts.add(0, post)
                                CommunityPostStore.save(context, discussionPosts)
                                postDraft = ""
                                feedback = "Публикация добавлена в обсуждение"
                            }
                        }
                    }
                }
                val orderedDiscussion = discussionPosts.sortedWith(compareByDescending<CommunityPost> { it.pinned }.thenByDescending { it.createdAt })
                items(orderedDiscussion, key = { it.id }) { post ->
                    val canModerate = isOwner || community.members.any { it.userId == userId && it.role == "MODERATOR" }
                    GlassCard(t) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            GText(t, if (post.authorId == userId) "Ты" else post.authorId.take(16), 10, true)
                            if (post.pinned) GText(t, "ЗАКРЕПЛЕНО", 9, true)
                        }
                        GText(t, post.text, 13)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            GButton(t, if (post.liked) "♥ ${post.likes}" else "♡ ${post.likes}", Modifier.weight(1f)) {
                                val index = discussionPosts.indexOfFirst { it.id == post.id }
                                if (index >= 0) {
                                    val old = discussionPosts[index]
                                    discussionPosts[index] = old.copy(liked = !old.liked, likes = (old.likes + if (old.liked) -1 else 1).coerceAtLeast(0))
                                    CommunityPostStore.save(context, discussionPosts)
                                }
                            }
                            GButton(t, "Ответы ${post.comments.size}", Modifier.weight(1f)) {
                                commentTarget = post; commentDraft = ""
                            }
                            if (canModerate) GButton(t, if (post.pinned) "Открепить" else "Закрепить", Modifier.weight(1f)) {
                                val index = discussionPosts.indexOfFirst { it.id == post.id }
                                if (index >= 0) {
                                    discussionPosts[index] = discussionPosts[index].copy(pinned = !discussionPosts[index].pinned)
                                    CommunityPostStore.save(context, discussionPosts)
                                }
                            }
                        }
                        if (post.authorId == userId || canModerate) {
                            TextButton(onClick = {
                                discussionPosts.removeAll { it.id == post.id }
                                CommunityPostStore.save(context, discussionPosts)
                            }) { Text("Удалить публикацию") }
                        }
                    }
                }
            } else {
                item { GlassCard(t) { GText(t, "Обсуждения доступны участникам пространства.", 11, secondary = true) } }
            }
        }
        if (feedback.isNotBlank()) item { GText(t, feedback, 11, true) }
    }

    if (commentTarget != null) {
        val target = commentTarget!!
        AlertDialog(
            onDismissRequest = { commentTarget = null },
            title = { Text("Ответы") },
            text = {
                Column {
                    if (target.comments.isEmpty()) Text("Ответов пока нет.")
                    target.comments.forEach { Text("• $it", modifier = Modifier.padding(vertical = 3.dp)) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = commentDraft, onValueChange = { commentDraft = it.take(300) }, label = { Text("Написать ответ") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = commentDraft.trim()
                    val index = discussionPosts.indexOfFirst { it.id == target.id }
                    if (value.isNotBlank() && index >= 0) {
                        discussionPosts[index] = discussionPosts[index].copy(comments = discussionPosts[index].comments + value)
                        CommunityPostStore.save(context, discussionPosts)
                    }
                    commentTarget = null
                }) { Text("Отправить") }
            },
            dismissButton = { TextButton(onClick = { commentTarget = null }) { Text("Закрыть") } }
        )
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Новое пространство") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it.take(32) }, label = { Text("Название") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(tag, { tag = it.uppercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(12) }, label = { Text("Тег · например VOID") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(description, { description = it.take(240) }, label = { Text("Описание") }, minLines = 2)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GButton(t, if (kind == "COMMUNITY") "✓ Сообщество" else "Сообщество", Modifier.weight(1f)) { kind = "COMMUNITY" }
                        GButton(t, if (kind == "CLAN") "✓ Клан" else "Клан", Modifier.weight(1f)) { kind = "CLAN" }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Закрытое пространство", fontSize = 13.sp)
                            Text("Вступление только по заявке", fontSize = 10.sp)
                        }
                        Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val (next, error) = CommunityStore.create(context, communities.toList(), name, tag, description, kind, isPrivate, userId)
                    if (error == null) {
                        communities.clear(); communities.addAll(next)
                        selectedId = next.firstOrNull()?.id
                        showCreate = false
                        feedback = "Пространство создано и сохранено на устройстве"
                    } else feedback = error
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Отмена") } }
        )
    }
}
