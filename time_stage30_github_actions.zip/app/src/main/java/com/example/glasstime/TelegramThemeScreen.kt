package com.example.glasstime

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ThemeColorTarget(val id: String, val title: String)
private val themeTargets = listOf(
    ThemeColorTarget("background", "Фон чатов"),
    ThemeColorTarget("panel", "Панели"),
    ThemeColorTarget("incoming", "Входящие сообщения"),
    ThemeColorTarget("outgoing", "Исходящие сообщения"),
    ThemeColorTarget("text", "Текст сообщений"),
    ThemeColorTarget("accent", "Ссылки и акценты"),
    ThemeColorTarget("actionBar", "Верхняя панель"),
    ThemeColorTarget("actionText", "Текст верхней панели"),
    ThemeColorTarget("button", "Кнопки"),
    ThemeColorTarget("icon", "Иконки")
)
private val themeSwatches = listOf(
    0xFF08090B.toInt(), 0xFF101216.toInt(), 0xFF1B1F25.toInt(), 0xFF292E35.toInt(),
    0xFF414852.toInt(), 0xFF777F89.toInt(), 0xFFCACDD2.toInt(), 0xFFFFFFFF.toInt(),
    0xFF182D45.toInt(), 0xFF315477.toInt(), 0xFF9CCFFF.toInt(), 0xFF342744.toInt(),
    0xFF754B91.toInt(), 0xFF45232D.toInt(), 0xFFB65A70.toInt(), 0xFFD0F59A.toInt()
)

@Composable
fun TelegramThemesScreen(t: ThemeState) {
    val context = LocalContext.current
    var theme by remember(context) { mutableStateOf(TelegramThemeStore.load(context)) }
    var target by remember { mutableStateOf("background") }
    var feedback by remember { mutableStateOf("") }
    var hexInput by remember { mutableStateOf("#101216") }
    var presetName by remember { mutableStateOf("") }
    var savedThemes by remember(context) { mutableStateOf(TelegramThemeStore.saved(context)) }
    var wallpaperVersion by remember { mutableIntStateOf(0) }
    var wallpaperDim by remember(context) { mutableFloatStateOf(TelegramWallpaperStore.loadDim(context)) }
    val wallpaperBitmap = remember(wallpaperVersion) { TelegramWallpaperStore.loadBitmap(context)?.asImageBitmap() }

    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching { TelegramWallpaperStore.copyFromUri(context, uri) }
            .onSuccess { wallpaperVersion++; feedback = "Фон чата сохранён" }
            .onFailure { feedback = it.message ?: "Не удалось сохранить фон" }
    }
    val wallpaperExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) runCatching { TelegramWallpaperStore.export(context, uri) }
            .onSuccess { feedback = "Изображение фона экспортировано отдельно" }
            .onFailure { feedback = it.message ?: "Ошибка экспорта фона" }
    }

    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(TelegramThemeStore.export(theme)) }
                ?: error("Не удалось создать файл")
        }.onSuccess { feedback = "Файл .attheme экспортирован" }
            .onFailure { feedback = it.message ?: "Ошибка экспорта" }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Не удалось открыть файл")
            TelegramThemeStore.import(bytes)
        }.onSuccess {
            theme = it
            TelegramThemeStore.save(context, it)
            feedback = "Тема импортирована"
        }.onFailure { feedback = it.message ?: "Не удалось импортировать тему" }
    }

    fun colorFor(id: String): Int = when (id) {
        "background" -> theme.background
        "panel" -> theme.panel
        "incoming" -> theme.incomingBubble
        "outgoing" -> theme.outgoingBubble
        "text" -> theme.messageText
        "accent" -> theme.accent
        "actionBar" -> theme.actionBar
        "actionText" -> theme.actionText
        "button" -> theme.button
        else -> theme.iconColor
    }
    fun colorToHex(value: Int) = "#%06X".format(value and 0x00FFFFFF)
    fun updateColor(value: Int) {
        hexInput = colorToHex(value)
        theme = when (target) {
            "background" -> theme.copy(background = value)
            "panel" -> theme.copy(panel = value)
            "incoming" -> theme.copy(incomingBubble = value)
            "outgoing" -> theme.copy(outgoingBubble = value)
            "text" -> theme.copy(messageText = value)
            "accent" -> theme.copy(accent = value)
            "actionBar" -> theme.copy(actionBar = value)
            "actionText" -> theme.copy(actionText = value)
            "button" -> theme.copy(button = value)
            else -> theme.copy(iconColor = value)
        }
        TelegramThemeStore.save(context, theme)
        feedback = "Цвет сохранён"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Темы Telegram", 28, true) }
        item {
            GlassCard(t) {
                GText(t, "Telegram Theme Studio", 17, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Локальный редактор цветов с предпросмотром переписки. Экспортирует файл .attheme для Telegram Android; фактическая поддержка отдельных ключей зависит от версии Telegram.", 12, secondary = true)
                if (feedback.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    GText(t, feedback, 12, true)
                }
            }
        }
        item {
            Box(
                Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(22.dp))
            ) {
                if (wallpaperBitmap != null) {
                    Image(wallpaperBitmap, contentDescription = "Фон предпросмотра Telegram", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize().background(Color(theme.background)))
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = wallpaperDim)))
                Column(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(theme.actionBar)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("time個", color = Color(theme.actionText), fontWeight = FontWeight.SemiBold)
                        Text("⋮", color = Color(theme.iconColor))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Box(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(theme.incomingBubble)).padding(12.dp)) {
                            Text("Пример входящего сообщения", color = Color(theme.messageText), fontSize = 13.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(theme.outgoingBubble)).padding(12.dp)) {
                            Column {
                                Text("Тема выглядит так", color = Color(theme.messageText), fontSize = 13.sp)
                                Text("ссылка и акцент", color = Color(theme.accent), fontSize = 12.sp)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(theme.button)).padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text("Кнопка", color = Color.White, fontSize = 12.sp)
                        }
                    }
                    Text("Предпросмотр · фон и цвета", color = Color(theme.messageText).copy(alpha = .75f), fontSize = 10.sp)
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Что настраиваем", 16, true)
                Spacer(Modifier.height(8.dp))
                themeTargets.forEach { item ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { target = item.id; hexInput = colorToHex(colorFor(item.id)) }.padding(vertical = 9.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GText(t, item.title, 13, target == item.id)
                        Box(Modifier.size(24.dp).clip(RoundedCornerShape(8.dp)).background(Color(colorFor(item.id))))
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Палитра · ${themeTargets.first { it.id == target }.title}", 16, true)
                Spacer(Modifier.height(10.dp))
                themeSwatches.chunked(4).forEach { rowColors ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowColors.forEach { value ->
                            Box(
                                Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(12.dp))
                                    .background(Color(value)).clickable { updateColor(value) }
                            )
                        }
                        repeat(4 - rowColors.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сбросить тему", Modifier.fillMaxWidth()) {
                    theme = TelegramTheme()
                    TelegramThemeStore.save(context, theme)
                    feedback = "Восстановлена стандартная тёмная тема"
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Свой цвет · HEX", 16, true)
                Spacer(Modifier.height(6.dp))
                GText(t, "Поле относится к разделу «${themeTargets.first { it.id == target }.title}»", 12, secondary = true)
                OutlinedTextField(
                    value = hexInput,
                    onValueChange = { hexInput = it.take(9) },
                    label = { Text("#RRGGBB или #AARRGGBB") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                GButton(t, "Применить HEX", Modifier.fillMaxWidth()) {
                    val raw = hexInput.trim().removePrefix("#")
                    val parsed = runCatching {
                        when (raw.length) {
                            6 -> (0xFF000000L or raw.toLong(16)).toInt()
                            8 -> raw.toLong(16).toInt()
                            else -> error("Нужны 6 или 8 символов HEX")
                        }
                    }.getOrNull()
                    if (parsed == null) feedback = "Неверный HEX-цвет"
                    else updateColor(parsed)
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Мои темы", 16, true)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(32) }, label = { Text("Название темы") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить текущую тему", Modifier.fillMaxWidth()) {
                    runCatching { TelegramThemeStore.saveNamed(context, presetName, theme) }
                        .onSuccess { savedThemes = TelegramThemeStore.saved(context); presetName = ""; feedback = "Тема сохранена" }
                        .onFailure { feedback = it.message ?: "Не удалось сохранить тему" }
                }
                savedThemes.forEach { saved ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                        Row(Modifier.fillMaxWidth().clickable {
                            theme = saved.theme
                            TelegramThemeStore.save(context, theme)
                            feedback = "Применена тема «${saved.name}»"
                        }, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(saved.name, color = t.textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Применить", color = t.textColor.copy(alpha = .65f), fontSize = 12.sp)
                        }
                        GButton(t, "Удалить «${saved.name}»", Modifier.fillMaxWidth()) {
                            TelegramThemeStore.deleteNamed(context, saved.name)
                            savedThemes = TelegramThemeStore.saved(context)
                            feedback = "Тема удалена"
                        }
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Обои чата", 16, true)
                Spacer(Modifier.height(6.dp))
                GText(t, if (TelegramWallpaperStore.hasWallpaper(context)) "Собственный фон выбран" else "Пока используется однотонный фон", 12, secondary = true)
                GButton(t, "Выбрать фото для фона", Modifier.fillMaxWidth()) { wallpaperPicker.launch("image/*") }
                Spacer(Modifier.height(8.dp))
                GText(t, "Затемнение · ${(wallpaperDim * 100).toInt()}%", 13)
                Slider(value = wallpaperDim, onValueChange = {
                    wallpaperDim = it
                    TelegramWallpaperStore.saveDim(context, it)
                }, valueRange = 0f..0.8f)
                GButton(t, "Экспортировать фон JPG", Modifier.fillMaxWidth()) { wallpaperExportPicker.launch("telegram_wallpaper.jpg") }
                GText(t, "Фон хранится отдельно от .attheme: экспортируй JPG отдельно и установи его в Telegram вместе с темой.", 11, secondary = true)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Импорт и экспорт", 16, true)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Экспортировать .attheme", Modifier.fillMaxWidth()) { exportPicker.launch("time_theme.attheme") }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Импортировать .attheme", Modifier.fillMaxWidth()) {
                    importPicker.launch(arrayOf("application/octet-stream", "text/plain", "*/*"))
                }
            }
        }
    }
}
