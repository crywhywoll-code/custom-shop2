# Firebase integration plan (stage 25)

The app remains local-first. `SocialRepository` is the boundary between screens and social data. `LocalSocialRepository` is active now; `FirebaseSocialRepository` is a deliberate adapter placeholder and does not perform network requests.

## Suggested Firestore layout

- `users/{uid}` — public profile fields; private settings stored separately and never exposed in public queries.
- `users/{uid}/following/{targetUid}` — subscription edges.
- `posts/{postId}` — author UID, text/media metadata, visibility, timestamps.
- `posts/{postId}/comments/{commentId}` — threaded comments with `parentId`.
- `posts/{postId}/reactions/{uid}` — one reaction per authenticated user.
- `communities/{communityId}` — title, owner UID, visibility and metadata.
- `communities/{communityId}/members/{uid}` — role and membership state.
- `reports/{reportId}` — reporter UID, target, reason, status; readable only by reporter and authorized moderators.
- `moderation/{uid}` — private restrictions, readable only by authorized moderators/backend functions.

## Required security rules before release

1. Deny all access by default; require Firebase Authentication for private writes.
2. Derive author/reporter UID from `request.auth.uid`; never trust a UID supplied by the client.
3. Only an owner/moderator assigned by trusted server-side logic may change community roles, report status, or moderation records.
4. Validate text length, timestamps, visibility, membership and allowed fields in Firestore rules or Cloud Functions.
5. Do not let clients grant themselves owner/admin/verified roles.
6. Use App Check and rate limits for abuse-sensitive endpoints.
7. Never put service-account credentials or private admin keys in the APK.

`google-services.json`, Firebase SDK dependencies, Authentication providers, Firestore rules and Cloud Functions are intentionally not included because no Firebase project credentials/configuration were supplied. The UI must not describe local actions as cloud-synced.
