# Navigation

Six-tab navigation is defined in `domain/model/AppTab.kt`. The pager is swipe-enabled and the selected tab is persisted by `NavigationRepository`.
