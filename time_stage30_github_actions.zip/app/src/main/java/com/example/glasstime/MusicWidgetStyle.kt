package com.example.glasstime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Color
import java.io.File

/** Appearance settings for the music widget; stored locally and applied without rebuilding the APK. */
data class MusicWidgetStyle(
    val backgroundColor: Int = 0xFF17191F.toInt(),
    val backgroundAlpha: Int = 235,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val secondaryTextColor: Int = 0xFFBFC3CC.toInt(),
    val cornerRadius: Int = 22,
    val padding: Int = 14,
    val titleSize: Float = 16f,
    val artistSize: Float = 12f,
    val showArtwork: Boolean = true,
    val showStatus: Boolean = true,
    val showControls: Boolean = true,
    val artworkSize: Int = 72,
    val layoutMode: String = "auto"
)

object MusicWidgetStyleStore {
    private const val PREFS = "music_widget_style"
    private const val BG_FILE = "music_widget_background.jpg"
    private const val ART_FILE = "music_widget_art.jpg"
    fun load(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).let { p ->
        MusicWidgetStyle(
            backgroundColor=p.getInt("bg",0xFF17191F.toInt()), backgroundAlpha=p.getInt("alpha",235).coerceIn(0,255),
            textColor=p.getInt("text",0xFFFFFFFF.toInt()), secondaryTextColor=p.getInt("secondary",0xFFBFC3CC.toInt()),
            cornerRadius=p.getInt("radius",22).coerceIn(0,48), padding=p.getInt("padding",14).coerceIn(4,28),
            titleSize=p.getFloat("title",16f).coerceIn(10f,26f), artistSize=p.getFloat("artist",12f).coerceIn(9f,20f),
            showArtwork=p.getBoolean("art",true), showStatus=p.getBoolean("status",true), showControls=p.getBoolean("controls",true),
            artworkSize=p.getInt("artSize",72).coerceIn(40,120), layoutMode=p.getString("layout","auto") ?: "auto")
    }
    fun save(c: Context, s: MusicWidgetStyle) {
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().apply {
            putInt("bg",s.backgroundColor); putInt("alpha",s.backgroundAlpha); putInt("text",s.textColor); putInt("secondary",s.secondaryTextColor)
            putInt("radius",s.cornerRadius.coerceIn(0,48)); putInt("padding",s.padding.coerceIn(4,28)); putFloat("title",s.titleSize.coerceIn(10f,26f)); putFloat("artist",s.artistSize.coerceIn(9f,20f))
            putBoolean("art",s.showArtwork); putBoolean("status",s.showStatus); putBoolean("controls",s.showControls); putInt("artSize",s.artworkSize.coerceIn(40,120)); putString("layout",s.layoutMode); apply()
        }
        NowPlayingWidgetProvider.updateAll(c)
    }
    fun backgroundFile(c: Context)=File(c.filesDir,BG_FILE)
    fun artworkFile(c: Context)=File(c.filesDir,ART_FILE)
    fun saveBackground(c: Context, bytes: ByteArray) { require(bytes.size <= 8*1024*1024); backgroundFile(c).writeBytes(bytes); NowPlayingWidgetProvider.updateAll(c) }
    fun saveArtwork(c: Context, bitmap: Bitmap?) {
        if (bitmap == null) { artworkFile(c).delete(); return }
        val scaled=Bitmap.createScaledBitmap(bitmap, minOf(bitmap.width,600), minOf(bitmap.height,600), true)
        artworkFile(c).outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG,88,it) }
        if (scaled !== bitmap) scaled.recycle()
    }
    fun backgroundBitmap(c: Context): Bitmap? = BitmapFactory.decodeFile(backgroundFile(c).absolutePath)
    fun artworkBitmap(c: Context): Bitmap? = BitmapFactory.decodeFile(artworkFile(c).absolutePath)
    fun renderedBackground(c: Context, style: MusicWidgetStyle): Bitmap {
        val out = Bitmap.createBitmap(480, 480, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val radius = style.cornerRadius.coerceIn(0,48) * 10f
        val path = Path().apply { addRoundRect(RectF(0f,0f,480f,480f), radius, radius, Path.Direction.CW) }
        canvas.clipPath(path)
        canvas.drawColor(style.backgroundColor)
        val photo = backgroundBitmap(c)
        if (photo != null) {
            val scale = maxOf(480f/photo.width, 480f/photo.height)
            val w=photo.width*scale; val h=photo.height*scale
            val dst=RectF((480f-w)/2f,(480f-h)/2f,(480f+w)/2f,(480f+h)/2f)
            val paint=Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha=style.backgroundAlpha }
            canvas.drawBitmap(photo,null,dst,paint); photo.recycle()
        }
        return out
    }
}
