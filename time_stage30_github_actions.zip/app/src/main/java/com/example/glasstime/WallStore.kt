package com.example.glasstime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class WallPost(
    val id: String,
    val text: String,
    val createdAt: Long,
    val likes: Int = 0,
    val liked: Boolean = false,
    val pinned: Boolean = false,
    val comments: List<String> = emptyList()
)

object WallStore {
    private const val PREFS = "local_profile_wall"
    private const val KEY_POSTS = "posts_v1"

    fun load(context: Context): List<WallPost> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_POSTS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val commentsJson = item.optJSONArray("comments") ?: JSONArray()
                    val comments = buildList {
                        for (j in 0 until commentsJson.length()) {
                            val value = commentsJson.optString(j).take(300)
                            if (value.isNotBlank()) add(value)
                        }
                    }
                    val text = item.optString("text").take(500)
                    if (text.isNotBlank()) add(
                        WallPost(
                            id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                            text = text,
                            createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                            likes = item.optInt("likes", 0).coerceAtLeast(0),
                            liked = item.optBoolean("liked", false),
                            pinned = item.optBoolean("pinned", false),
                            comments = comments
                        )
                    )
                }
            }.sortedWith(compareByDescending<WallPost> { it.pinned }.thenByDescending { it.createdAt })
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, posts: List<WallPost>) {
        val array = JSONArray()
        posts.take(100).forEach { post ->
            val comments = JSONArray()
            post.comments.take(100).forEach { comments.put(it.take(300)) }
            array.put(JSONObject().apply {
                put("id", post.id)
                put("text", post.text.take(500))
                put("createdAt", post.createdAt)
                put("likes", post.likes.coerceAtLeast(0))
                put("liked", post.liked)
                put("pinned", post.pinned)
                put("comments", comments)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_POSTS, array.toString()).apply()
    }

    fun newPost(text: String): WallPost = WallPost(
        id = UUID.randomUUID().toString(),
        text = text.trim().take(500),
        createdAt = System.currentTimeMillis()
    )
}
