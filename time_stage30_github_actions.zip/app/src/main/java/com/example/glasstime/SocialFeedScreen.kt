package com.example.glasstime

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class FeedEntry(val id: String, val source: String, val author: String, val text: String, val createdAt: Long, val pinned: Boolean)

@Composable
fun SocialFeedScreen(t: ThemeState, onBack: () -> Unit) {
    var showExplore by remember { mutableStateOf(false) }
    if (showExplore) {
        CommunityExploreScreen(t) { showExplore = false }
        return
    }
    val context = LocalContext.current
    val currentId = remember(context) { ProfileStore.localId(context) }
    val communities = remember(context) { CommunityStore.load(context) }
    var following by remember { mutableStateOf(SocialFeedStore.following(context)) }
    var targetId by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("ALL") }
    var feedback by remember { mutableStateOf("") }
    var interactionRefresh by remember { mutableIntStateOf(0) }
    var commentTarget by remember { mutableStateOf<FeedEntry?>(null) }
    var commentDraft by remember { mutableStateOf("") }
    var replyParent by remember { mutableStateOf<String?>(null) }
    val ownPosts = remember(context) { WallStore.load(context) }
    val joined = communities.filter { c -> c.members.any { it.userId == currentId } }
    val communityEntries = joined.flatMap { c ->
        CommunityPostStore.load(context, c.id).map { p -> FeedEntry(p.id, c.name, p.authorId, p.text, p.createdAt, p.pinned) }
    }
    val profileEntries = ownPosts.map { p -> FeedEntry(p.id, "Стена профиля", currentId, p.text, p.createdAt, p.pinned) }
    val entries = (profileEntries + communityEntries)
        .filter { if (filter == "COMMUNITIES") it.source != "Стена профиля" else true }
        .sortedWith(compareByDescending<FeedEntry> { it.pinned }.thenByDescending { it.createdAt })

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                GText(t, "Лента", 26, true)
                TextButton(onClick = onBack) { Text("Профиль") }
            }
            GText(t, "Локальная социальная лента", 12, secondary = true)
            Spacer(Modifier.height(8.dp))
            GButton(t, "Найти сообщества и кланы", Modifier.fillMaxWidth()) { showExplore = true }
        }
        item {
            GlassCard(t) {
                GText(t, "Подписки", 16, true)
                GText(t, "Добавляй локальные ID профилей. Реальный поиск пользователей появится после подключения сервера.", 11, secondary = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(targetId, { targetId = it.take(80) }, label = { Text("ID пользователя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(7.dp))
                GButton(t, "Подписаться", Modifier.fillMaxWidth()) {
                    val (next, error) = SocialFeedStore.follow(context, currentId, targetId)
                    following = next
                    feedback = error ?: "Подписка добавлена"
                    if (error == null) targetId = ""
                }
                if (feedback.isNotBlank()) Text(feedback, color = t.textColor.copy(alpha = .7f), fontSize = 11.sp)
                Text("Подписки: ${following.size}", color = t.textColor.copy(alpha = .65f), fontSize = 11.sp)
            }
        }
        if (following.isNotEmpty()) {
            item {
                GlassCard(t) {
                    GText(t, "Твои подписки", 14, true)
                    following.forEach { id ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(id, color = t.textColor, fontSize = 12.sp)
                            TextButton(onClick = { following = SocialFeedStore.unfollow(context, id) }) { Text("Отписаться") }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GButton(t, if (filter == "ALL") "✓ Всё" else "Всё", Modifier.weight(1f)) { filter = "ALL" }
                GButton(t, if (filter == "COMMUNITIES") "✓ Сообщества" else "Сообщества", Modifier.weight(1f)) { filter = "COMMUNITIES" }
            }
        }
        if (entries.isEmpty()) {
            item { GlassCard(t) { GText(t, "Пока пусто", 15, true); GText(t, "Создай публикацию на своей стене или в сообществе — она появится здесь.", 11, secondary = true) } }
        }
        items(entries, key = { "${it.source}_${it.id}" }) { post ->
            GlassCard(t) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    GText(t, post.source, 13, true)
                    if (post.pinned) GText(t, "ЗАКРЕПЛЕНО", 9, true)
                }
                Text("${post.author} · ${SimpleDateFormat("dd.MM · HH:mm", Locale.getDefault()).format(Date(post.createdAt))}", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp)
                Spacer(Modifier.height(6.dp))
                GText(t, post.text, 13)
                val reactions = remember(interactionRefresh, post.id) { InteractionStore.reactions(context, post.id) }
                val comments = remember(interactionRefresh, post.id) { InteractionStore.comments(context, post.id) }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("♥", "🔥", "✦").forEach { emoji ->
                        val count = reactions.count { it.emoji == emoji }
                        GButton(t, "$emoji $count", Modifier.weight(1f)) {
                            InteractionStore.toggleReaction(context, post.id, currentId, emoji)
                            interactionRefresh++
                        }
                    }
                    GButton(t, "Ответы ${comments.size}", Modifier.weight(1f)) {
                        commentTarget = post
                        commentDraft = ""
                        replyParent = null
                    }
                }
                TextButton(onClick = {
                    commentTarget = post
                    commentDraft = ""
                    replyParent = null
                }) { Text("Открыть обсуждение", color = t.textColor.copy(alpha = .7f)) }
            }
        }
    }
    if (commentTarget != null) {
        val target = commentTarget!!
        val thread = remember(interactionRefresh, target.id) { InteractionStore.comments(context, target.id) }
        AlertDialog(
            onDismissRequest = { commentTarget = null },
            title = { Text("Обсуждение") },
            text = {
                Column {
                    if (thread.isEmpty()) Text("Комментариев пока нет.")
                    thread.filter { it.parentId == null }.forEach { item ->
                        Text("${item.authorId}: ${item.body}", modifier = Modifier.padding(vertical = 3.dp))
                        thread.filter { it.parentId == item.id }.forEach { reply ->
                            Text("↳ ${reply.body}", modifier = Modifier.padding(start = 12.dp, bottom = 3.dp), fontSize = 12.sp)
                        }
                        TextButton(onClick = { replyParent = item.id }) { Text("Ответить") }
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(commentDraft, { commentDraft = it.take(300) }, label = { Text(if (replyParent == null) "Комментарий" else "Ответ на комментарий") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (InteractionStore.addComment(context, target.id, currentId, commentDraft, replyParent)) interactionRefresh++
                    replyParent = null
                    commentTarget = null
                }) { Text("Отправить") }
            },
            dismissButton = { TextButton(onClick = { commentTarget = null }) { Text("Закрыть") } }
        )
    }
}
