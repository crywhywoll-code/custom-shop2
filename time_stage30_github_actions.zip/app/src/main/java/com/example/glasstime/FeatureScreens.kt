package com.example.glasstime

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.provider.OpenableColumns
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

private val widgetPanelColors = listOf(
    "Графит" to 0xFF252B33.toInt(),
    "Чёрный" to 0xFF08090B.toInt(),
    "Серый" to 0xFF555B63.toInt(),
    "Синий" to 0xFF182D45.toInt(),
    "Бордовый" to 0xFF45232D.toInt(),
    "Фиолетовый" to 0xFF342744.toInt()
)
private val widgetTextColors = listOf(
    "Белый" to 0xFFFFFFFF.toInt(),
    "Серый" to 0xFFCACDD2.toInt(),
    "Голубой" to 0xFF9CCFFF.toInt(),
    "Красный" to 0xFFFFA1A1.toInt(),
    "Лайм" to 0xFFD0F59A.toInt()
)

@Composable
private fun ModuleLanding(
    t: ThemeState,
    title: String,
    subtitle: String,
    status: String,
    points: List<String>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, title, 28, true) }
        item {
            GlassCard(t) {
                GText(t, subtitle, 15, true)
                Spacer(Modifier.height(8.dp))
                GText(t, status, 12, secondary = true)
            }
        }
        items(points.size) { index ->
            GlassCard(t) { GText(t, points[index], 14) }
        }
    }
}

@Composable
fun WidgetStudioScreen(t: ThemeState) {
    val context = LocalContext.current
    val clockIds = remember(context) {
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, ClockDateWidgetProvider::class.java)).toList()
    }
    val photoIds = remember(context) {
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, PhotoWidgetProvider::class.java)).toList()
    }
    var targetClockId by remember { mutableIntStateOf(clockIds.firstOrNull() ?: AppWidgetManagerIds.NONE) }
    var targetPhotoId by remember { mutableIntStateOf(photoIds.firstOrNull() ?: AppWidgetManagerIds.NONE) }
    val initial = remember(context) { ClockWidgetStyleStore.load(context, targetClockId) }
    var timeSize by remember { mutableFloatStateOf(initial.timeSize) }
    var dateSize by remember { mutableFloatStateOf(initial.dateSize) }
    var textColor by remember { mutableIntStateOf(initial.textColor) }
    var panelColor by remember { mutableIntStateOf(initial.panelColor) }
    var panelAlpha by remember { mutableFloatStateOf(initial.panelAlpha.toFloat()) }
    var font by remember { mutableStateOf(initial.font) }
    var horizontalAlignment by remember { mutableStateOf(initial.horizontalAlignment) }
    var verticalAlignment by remember { mutableStateOf(initial.verticalAlignment) }
    var showDate by remember { mutableStateOf(initial.showDate) }
    var customText by remember { mutableStateOf(initial.customText) }
    var showCustomText by remember { mutableStateOf(initial.showCustomText) }
    var cropZoom by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).zoom) }
    var cropX by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).x) }
    var cropY by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).y) }
    var photoCornerRadius by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).cornerRadius) }
    var presetName by remember { mutableStateOf("") }
    var savedPresets by remember(context) { mutableStateOf(WidgetPresetManager.savedPresets(context)) }
    var feedback by remember { mutableStateOf("") }
    var importedKwgt by remember(context) { mutableStateOf(KwgtImportManager.imports(context)) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                WidgetPresetManager.copyPhotoFromUri(context, uri, targetPhotoId.takeIf { it != AppWidgetManagerIds.NONE })
                PhotoWidgetProvider.updateAll(context)
            }.onSuccess { feedback = "Фото сохранено и применено к фото-виджету" }
                .onFailure { feedback = "Не удалось сохранить фото: ${it.message ?: "ошибка"}" }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val style = ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font, horizontalAlignment, verticalAlignment, showDate, customText, showCustomText)
                val bytes = WidgetPresetManager.export(context, style)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: error("Не удалось создать файл")
            }.onSuccess { feedback = "Пресет .time экспортирован" }
                .onFailure { feedback = "Ошибка экспорта: ${it.message ?: "неизвестная ошибка"}" }
        }
    }
    val kwgtPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val displayName = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                KwgtImportManager.import(context, uri, displayName)
            }.onSuccess { preset ->
                importedKwgt = KwgtImportManager.imports(context)
                feedback = "«${preset.name}» добавлен в каталог: ${preset.entryCount} файлов, ${preset.resourceCount} ресурсов"
            }.onFailure { feedback = "Импорт KWGT не выполнен: ${it.message ?: "ошибка архива"}" }
        }
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Не удалось открыть файл")
                WidgetPresetManager.import(context, bytes)
            }.onSuccess { style ->
                ClockWidgetStyleStore.save(context, style, targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                timeSize = style.timeSize
                dateSize = style.dateSize
                textColor = style.textColor
                panelColor = style.panelColor
                panelAlpha = style.panelAlpha.toFloat()
                font = style.font
                horizontalAlignment = style.horizontalAlignment; verticalAlignment = style.verticalAlignment
                showDate = style.showDate; customText = style.customText; showCustomText = style.showCustomText
                ClockDateWidgetProvider.updateAll(context)
                PhotoWidgetProvider.updateAll(context)
                feedback = "Пресет импортирован и применён"
            }.onFailure { feedback = "Не удалось импортировать: ${it.message ?: "ошибка файла"}" }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Виджеты", 28, true) }
        item {
            GlassCard(t) {
                GText(t, "Widget Studio", 17, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Настрой оформление настоящего виджета часов. Запрос обновления времени — каждые 30 секунд; Android может задерживать его ради экономии батареи.", 13, secondary = true)
                if (feedback.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    GText(t, feedback, 12, true)
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Экземпляр часов", 16, true)
                Spacer(Modifier.height(6.dp))
                if (clockIds.isEmpty()) GText(t, "Сначала добавь часы на главный экран. Пока настройки будут общими для будущих виджетов.", 12, secondary = true)
                else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    clockIds.forEachIndexed { index, id ->
                        GChip(t, "Часы ${index + 1}", targetClockId == id) {
                            targetClockId = id
                            val selected = ClockWidgetStyleStore.load(context, id)
                            timeSize = selected.timeSize; dateSize = selected.dateSize
                            textColor = selected.textColor; panelColor = selected.panelColor
                            panelAlpha = selected.panelAlpha.toFloat(); font = selected.font
                            horizontalAlignment = selected.horizontalAlignment; verticalAlignment = selected.verticalAlignment
                            showDate = selected.showDate; customText = selected.customText; showCustomText = selected.showCustomText
                        }
                    }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Color(panelColor).copy(alpha = panelAlpha / 255f))
                    .padding(20.dp)
            ) {
                val family = when (font) {
                    "serif" -> FontFamily.Serif
                    "mono" -> FontFamily.Monospace
                    else -> FontFamily.SansSerif
                }
                Column(Modifier.fillMaxWidth(), horizontalAlignment = when (horizontalAlignment) { "center" -> androidx.compose.ui.Alignment.CenterHorizontally; "end" -> androidx.compose.ui.Alignment.End; else -> androidx.compose.ui.Alignment.Start }, verticalArrangement = when (verticalAlignment) { "top" -> Arrangement.Top; "bottom" -> Arrangement.Bottom; else -> Arrangement.Center }) {
                    androidx.compose.material3.Text(
                        text = "12:45", color = Color(textColor), fontSize = timeSize.sp,
                        fontFamily = family, fontWeight = FontWeight.Light,
                        lineHeight = (timeSize * 1.1f).sp
                    )
                    if (showDate) {
                        Spacer(Modifier.height(3.dp))
                        androidx.compose.material3.Text(
                            text = "суббота, 7 ноября", color = Color(textColor).copy(alpha = 0.72f),
                            fontSize = dateSize.sp, fontFamily = family
                        )
                    }
                    if (showCustomText && customText.isNotBlank()) {
                        Spacer(Modifier.height(3.dp))
                        androidx.compose.material3.Text(customText, color = Color(textColor).copy(alpha = .78f), fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Размер текста", 16, true)
                Spacer(Modifier.height(8.dp))
                GText(t, "Часы · ${timeSize.toInt()} sp", 13)
                Slider(value = timeSize, onValueChange = { timeSize = it }, valueRange = 28f..60f)
                GText(t, "Дата · ${dateSize.toInt()} sp", 13)
                Slider(value = dateSize, onValueChange = { dateSize = it }, valueRange = 10f..20f)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Шрифт", 16, true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GChip(t, "Sans", font == "sans") { font = "sans" }
                    GChip(t, "Serif", font == "serif") { font = "serif" }
                    GChip(t, "Mono", font == "mono") { font = "mono" }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Расположение элементов", 16, true)
                Spacer(Modifier.height(8.dp))
                GText(t, "По горизонтали", 13)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GChip(t, "Слева", horizontalAlignment == "start") { horizontalAlignment = "start" }
                    GChip(t, "По центру", horizontalAlignment == "center") { horizontalAlignment = "center" }
                    GChip(t, "Справа", horizontalAlignment == "end") { horizontalAlignment = "end" }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "По вертикали", 13)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GChip(t, "Сверху", verticalAlignment == "top") { verticalAlignment = "top" }
                    GChip(t, "По центру", verticalAlignment == "center") { verticalAlignment = "center" }
                    GChip(t, "Снизу", verticalAlignment == "bottom") { verticalAlignment = "bottom" }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    GText(t, "Показывать дату", 13)
                    Switch(checked = showDate, onCheckedChange = { showDate = it })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    GText(t, "Дополнительная надпись", 13)
                    Switch(checked = showCustomText, onCheckedChange = { showCustomText = it })
                }
                OutlinedTextField(value = customText, onValueChange = { customText = it.take(48) }, label = { androidx.compose.material3.Text("Текст виджета") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Цвет текста", 16, true)
                Spacer(Modifier.height(8.dp))
                widgetTextColors.forEach { (name, value) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { textColor = value }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GText(t, name, 14, textColor == value)
                        Box(Modifier.height(22.dp).fillMaxWidth(0.12f).clip(RoundedCornerShape(8.dp)).background(Color(value)))
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фон виджета", 16, true)
                Spacer(Modifier.height(8.dp))
                widgetPanelColors.forEach { (name, value) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { panelColor = value }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GText(t, name, 14, panelColor == value)
                        Box(Modifier.height(22.dp).fillMaxWidth(0.12f).clip(RoundedCornerShape(8.dp)).background(Color(value)))
                    }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "Прозрачность · ${((panelAlpha / 255f) * 100).toInt()}%", 13)
                Slider(value = panelAlpha, onValueChange = { panelAlpha = it }, valueRange = 80f..255f)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить и применить", Modifier.fillMaxWidth()) {
                    ClockWidgetStyleStore.save(context, ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font, horizontalAlignment, verticalAlignment, showDate, customText, showCustomText), targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                    ClockDateWidgetProvider.updateAll(context)
                    feedback = "Оформление часов применено к выбранному экземпляру"
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фото-виджет", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Выбери изображение из галереи. Оно будет сохранено локально и появится в отдельном виджете на рабочем столе.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Выбрать фото", Modifier.fillMaxWidth()) { photoPicker.launch("image/*") }
                Spacer(Modifier.height(6.dp))
                GText(t, "После выбора добавь виджет «Фото» через меню виджетов лаунчера.", 12, secondary = true)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Настройка фото-виджета", 16, true)
                Spacer(Modifier.height(6.dp))
                if (photoIds.isEmpty()) GText(t, "Сначала добавь фото-виджет на рабочий стол.", 12, secondary = true)
                else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    photoIds.forEachIndexed { index, id ->
                        GChip(t, "Фото ${index + 1}", targetPhotoId == id) {
                            targetPhotoId = id
                            val crop = WidgetInstanceStore.loadCrop(context, id)
                            cropZoom = crop.zoom; cropX = crop.x; cropY = crop.y; photoCornerRadius = crop.cornerRadius
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "Масштаб · ${String.format(java.util.Locale.getDefault(), "%.1f", cropZoom)}×", 13)
                Slider(value = cropZoom, onValueChange = { cropZoom = it }, valueRange = 1f..2.5f)
                GText(t, "Смещение по горизонтали", 13)
                Slider(value = cropX, onValueChange = { cropX = it }, valueRange = -1f..1f)
                GText(t, "Смещение по вертикали", 13)
                Slider(value = cropY, onValueChange = { cropY = it }, valueRange = -1f..1f)
                GText(t, "Скругление углов · ${photoCornerRadius.toInt()} dp", 13)
                Slider(value = photoCornerRadius, onValueChange = { photoCornerRadius = it }, valueRange = 0f..48f)
                GButton(t, "Сохранить кадрирование и углы", Modifier.fillMaxWidth()) {
                    WidgetInstanceStore.saveCrop(context, targetPhotoId.takeIf { it != AppWidgetManagerIds.NONE }, WidgetInstanceStore.PhotoCrop(cropZoom, cropX, cropY, photoCornerRadius))
                    PhotoWidgetProvider.updateAll(context)
                    feedback = "Позиция фото сохранена для выбранного виджета"
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Сохранённые варианты", 16, true)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(32) }, label = { androidx.compose.material3.Text("Название варианта") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить вариант", Modifier.fillMaxWidth()) {
                    runCatching { WidgetPresetManager.saveNamedPreset(context, presetName, ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font, horizontalAlignment, verticalAlignment, showDate, customText, showCustomText)) }
                        .onSuccess { savedPresets = WidgetPresetManager.savedPresets(context); presetName = ""; feedback = "Вариант сохранён" }
                        .onFailure { feedback = it.message ?: "Не удалось сохранить вариант" }
                }
                savedPresets.forEach { preset ->
                    Row(Modifier.fillMaxWidth().clickable {
                        val selected = WidgetPresetManager.applyNamedPreset(context, preset.name, targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                        timeSize = selected.timeSize; dateSize = selected.dateSize
                        textColor = selected.textColor; panelColor = selected.panelColor
                        panelAlpha = selected.panelAlpha.toFloat(); font = selected.font
                        horizontalAlignment = selected.horizontalAlignment; verticalAlignment = selected.verticalAlignment
                        showDate = selected.showDate; customText = selected.customText; showCustomText = selected.showCustomText
                        ClockDateWidgetProvider.updateAll(context)
                        feedback = "Применён вариант «${preset.name}»"
                    }.padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        GText(t, preset.name, 14, true)
                        GText(t, "Применить", 12, secondary = true)
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Пресеты .time", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Экспорт сохраняет оформление часов и выбранное фото в один файл. Импорт проверяет формат и версию перед применением.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Экспортировать .time", Modifier.fillMaxWidth()) {
                    exportPicker.launch("widget_style.time")
                }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Импортировать .time", Modifier.fillMaxWidth()) {
                    importPicker.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Импорт KWGT", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Добавляй .kwgt или ZIP-пресеты. time个 проверит архив, безопасно извлечёт ресурсы и сохранит каталог с количеством файлов. Формулы, динамика и анимации KWGT пока не исполняются внутри time个.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Импортировать .kwgt", Modifier.fillMaxWidth()) {
                    kwgtPicker.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed", "*/*"))
                }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Открыть KWGT", Modifier.fillMaxWidth()) {
                    feedback = if (KwgtImportManager.openInKustom(context)) "KWGT открыт. Импортированные ресурсы доступны в каталоге time个." else "KWGT не найден. Установи Kustom Widget Maker, чтобы открыть редактор."
                }
                if (importedKwgt.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    GText(t, "Импортированные пресеты · ${importedKwgt.size}", 14, true)
                    importedKwgt.forEach { preset ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                            val previewBitmap = remember(preset.id, preset.previewName) { KwgtImportManager.previewBitmap(context, preset) }
                            if (previewBitmap != null) {
                                Image(previewBitmap.asImageBitmap(), contentDescription = "Превью ${preset.name}",
                                    modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)),
                                    contentScale = ContentScale.Fit)
                                Spacer(Modifier.height(6.dp))
                            }
                            GText(t, preset.name, 14, true)
                            GText(t, "${preset.entryCount} файлов · ${preset.resourceCount} ресурсов", 11, secondary = true)
                            GText(t, "Добавлен ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date(preset.importedAt))}", 10, secondary = true)
                            GButton(t, "Удалить импорт", Modifier.fillMaxWidth()) {
                                KwgtImportManager.delete(context, preset)
                                importedKwgt = KwgtImportManager.imports(context)
                                feedback = "Пресет удалён из каталога"
                            }
                        }
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Музыкальный виджет", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Показывает текущий трек и исполнителя. Для работы нужен доступ time个 к уведомлениям.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Добавить музыкальный виджет", Modifier.fillMaxWidth()) {
                    val pinned = runCatching {
                        AppWidgetManager.getInstance(context).requestPinAppWidget(
                            ComponentName(context, NowPlayingWidgetProvider::class.java), null, null
                        )
                    }.getOrDefault(false)
                    feedback = if (pinned) "Подтверди добавление виджета на главном экране" else "Лаунчер не поддерживает прямое добавление. Добавь «Музыка» через меню виджетов."
                }
                Spacer(Modifier.height(6.dp))
                GText(t, "Если кнопка не сработает, открой меню виджетов рабочего стола и выбери «Музыка — time个».", 11, secondary = true)
            }
        }
        item {
            val initialMusicStyle = remember(context) { MusicWidgetStyleStore.load(context) }
            var musicStyle by remember(context) { mutableStateOf(initialMusicStyle) }
            var musicFeedback by remember { mutableStateOf("") }
            val musicBackgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                if (uri != null) runCatching {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать фото")
                    MusicWidgetStyleStore.saveBackground(context, bytes)
                    musicFeedback = "Фон внутри музыкального виджета обновлён"
                }.onFailure { musicFeedback = it.message ?: "Не удалось установить фон" }
            }
            GlassCard(t) {
                GText(t, "Music Widget Studio", 18, true)
                GText(t, "Настраивай плеер отдельно: фон внутри виджета, обложку, размеры, структуру и элементы.", 12, secondary = true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    widgetPanelColors.forEach { (name, color) ->
                        Box(Modifier.weight(1f).height(34.dp).clip(RoundedCornerShape(9.dp)).background(Color(color)).clickable {
                            musicStyle = musicStyle.copy(backgroundColor = color); MusicWidgetStyleStore.save(context, musicStyle)
                        })
                    }
                }
                GText(t, "Структура плеера", 13, true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("auto" to "Авто", "vertical" to "Вертикально", "horizontal" to "Горизонтально").forEach { (mode, label) ->
                        GButton(t, label, Modifier.weight(1f)) { musicStyle = musicStyle.copy(layoutMode = mode); MusicWidgetStyleStore.save(context, musicStyle) }
                    }
                }
                GText(t, "Цвет текста", 13, true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    widgetTextColors.forEach { (name, color) ->
                        Box(Modifier.weight(1f).height(28.dp).clip(RoundedCornerShape(8.dp)).background(Color(color)).clickable {
                            musicStyle = musicStyle.copy(textColor = color); MusicWidgetStyleStore.save(context, musicStyle)
                        })
                    }
                }
                GButton(t, "Выбрать фото для фона плеера", Modifier.fillMaxWidth()) { musicBackgroundPicker.launch("image/*") }
                GButton(t, "Убрать фото-фон", Modifier.fillMaxWidth()) { MusicWidgetStyleStore.backgroundFile(context).delete(); MusicWidgetStyleStore.save(context, musicStyle) }
                GText(t, "Прозрачность подложки · ${musicStyle.backgroundAlpha}", 12)
                Slider(value = musicStyle.backgroundAlpha.toFloat(), onValueChange = { musicStyle = musicStyle.copy(backgroundAlpha = it.toInt()) }, valueRange = 0f..255f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                GText(t, "Скругление · ${musicStyle.cornerRadius} dp", 12)
                Slider(value = musicStyle.cornerRadius.toFloat(), onValueChange = { musicStyle = musicStyle.copy(cornerRadius = it.toInt()) }, valueRange = 0f..48f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                GText(t, "Внутренние отступы · ${musicStyle.padding} dp", 12)
                Slider(value = musicStyle.padding.toFloat(), onValueChange = { musicStyle = musicStyle.copy(padding = it.toInt()) }, valueRange = 4f..28f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                GText(t, "Размер названия · ${musicStyle.titleSize.toInt()} sp", 12)
                Slider(value = musicStyle.titleSize, onValueChange = { musicStyle = musicStyle.copy(titleSize = it) }, valueRange = 10f..26f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                GText(t, "Размер исполнителя · ${musicStyle.artistSize.toInt()} sp", 12)
                Slider(value = musicStyle.artistSize, onValueChange = { musicStyle = musicStyle.copy(artistSize = it) }, valueRange = 9f..20f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                GText(t, "Размер обложки · ${musicStyle.artworkSize} dp", 12)
                Slider(value = musicStyle.artworkSize.toFloat(), onValueChange = { musicStyle = musicStyle.copy(artworkSize = it.toInt()) }, valueRange = 40f..120f, onValueChangeFinished = { MusicWidgetStyleStore.save(context, musicStyle) })
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    GText(t, "Обложка трека", 13); Switch(checked = musicStyle.showArtwork, onCheckedChange = { musicStyle = musicStyle.copy(showArtwork = it); MusicWidgetStyleStore.save(context, musicStyle) })
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    GText(t, "Статус NOW PLAYING", 13); Switch(checked = musicStyle.showStatus, onCheckedChange = { musicStyle = musicStyle.copy(showStatus = it); MusicWidgetStyleStore.save(context, musicStyle) })
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    GText(t, "Кнопки управления", 13); Switch(checked = musicStyle.showControls, onCheckedChange = { musicStyle = musicStyle.copy(showControls = it); MusicWidgetStyleStore.save(context, musicStyle) })
                }
                GButton(t, "Применить настройки плеера", Modifier.fillMaxWidth()) { MusicWidgetStyleStore.save(context, musicStyle); musicFeedback = "Настройки применены ко всем музыкальным виджетам" }
                if (musicFeedback.isNotBlank()) GText(t, musicFeedback, 11, secondary = true)
                GText(t, "Обложка автоматически берётся из метаданных активного музыкального приложения, если оно передаёт её Android. Некоторые плееры не предоставляют изображение.", 11, secondary = true)
            }
        }
    }
}

