package com.example.glasstime

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.OutlinedTextField
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

private val widgetPanelColors = listOf(
    "Графит" to 0xFF252B33.toInt(),
    "Чёрный" to 0xFF08090B.toInt(),
    "Серый" to 0xFF555B63.toInt(),
    "Синий" to 0xFF182D45.toInt(),
    "Бордовый" to 0xFF45232D.toInt(),
    "Фиолетовый" to 0xFF342744.toInt()
)
private val widgetTextColors = listOf(
    "Белый" to 0xFFFFFFFF.toInt(),
    "Серый" to 0xFFCACDD2.toInt(),
    "Голубой" to 0xFF9CCFFF.toInt(),
    "Красный" to 0xFFFFA1A1.toInt(),
    "Лайм" to 0xFFD0F59A.toInt()
)

@Composable
private fun ModuleLanding(
    t: ThemeState,
    title: String,
    subtitle: String,
    status: String,
    points: List<String>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, title, 28, true) }
        item {
            GlassCard(t) {
                GText(t, subtitle, 15, true)
                Spacer(Modifier.height(8.dp))
                GText(t, status, 12, secondary = true)
            }
        }
        items(points.size) { index ->
            GlassCard(t) { GText(t, points[index], 14) }
        }
    }
}

@Composable
fun WidgetStudioScreen(t: ThemeState) {
    val context = LocalContext.current
    val clockIds = remember(context) {
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, ClockDateWidgetProvider::class.java)).toList()
    }
    val photoIds = remember(context) {
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, PhotoWidgetProvider::class.java)).toList()
    }
    var targetClockId by remember { mutableIntStateOf(clockIds.firstOrNull() ?: AppWidgetManagerIds.NONE) }
    var targetPhotoId by remember { mutableIntStateOf(photoIds.firstOrNull() ?: AppWidgetManagerIds.NONE) }
    val initial = remember(context) { ClockWidgetStyleStore.load(context, targetClockId) }
    var timeSize by remember { mutableFloatStateOf(initial.timeSize) }
    var dateSize by remember { mutableFloatStateOf(initial.dateSize) }
    var textColor by remember { mutableIntStateOf(initial.textColor) }
    var panelColor by remember { mutableIntStateOf(initial.panelColor) }
    var panelAlpha by remember { mutableFloatStateOf(initial.panelAlpha.toFloat()) }
    var font by remember { mutableStateOf(initial.font) }
    var cropZoom by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).zoom) }
    var cropX by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).x) }
    var cropY by remember(targetPhotoId) { mutableFloatStateOf(WidgetInstanceStore.loadCrop(context, targetPhotoId).y) }
    var presetName by remember { mutableStateOf("") }
    var savedPresets by remember(context) { mutableStateOf(WidgetPresetManager.savedPresets(context)) }
    var feedback by remember { mutableStateOf("") }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                WidgetPresetManager.copyPhotoFromUri(context, uri, targetPhotoId.takeIf { it != AppWidgetManagerIds.NONE })
                PhotoWidgetProvider.updateAll(context)
            }.onSuccess { feedback = "Фото сохранено и применено к фото-виджету" }
                .onFailure { feedback = "Не удалось сохранить фото: ${it.message ?: "ошибка"}" }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val style = ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font)
                val bytes = WidgetPresetManager.export(context, style)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: error("Не удалось создать файл")
            }.onSuccess { feedback = "Пресет .time экспортирован" }
                .onFailure { feedback = "Ошибка экспорта: ${it.message ?: "неизвестная ошибка"}" }
        }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Не удалось открыть файл")
                WidgetPresetManager.import(context, bytes)
            }.onSuccess { style ->
                ClockWidgetStyleStore.save(context, style, targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                timeSize = style.timeSize
                dateSize = style.dateSize
                textColor = style.textColor
                panelColor = style.panelColor
                panelAlpha = style.panelAlpha.toFloat()
                font = style.font
                ClockDateWidgetProvider.updateAll(context)
                PhotoWidgetProvider.updateAll(context)
                feedback = "Пресет импортирован и применён"
            }.onFailure { feedback = "Не удалось импортировать: ${it.message ?: "ошибка файла"}" }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Виджеты", 28, true) }
        item {
            GlassCard(t) {
                GText(t, "Widget Studio", 17, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Настрой оформление настоящего виджета часов. Запрос обновления времени — каждые 30 секунд; Android может задерживать его ради экономии батареи.", 13, secondary = true)
                if (feedback.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    GText(t, feedback, 12, true)
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Экземпляр часов", 16, true)
                Spacer(Modifier.height(6.dp))
                if (clockIds.isEmpty()) GText(t, "Сначала добавь часы на главный экран. Пока настройки будут общими для будущих виджетов.", 12, secondary = true)
                else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    clockIds.forEachIndexed { index, id ->
                        GChip(t, "Часы ${index + 1}", targetClockId == id) {
                            targetClockId = id
                            val selected = ClockWidgetStyleStore.load(context, id)
                            timeSize = selected.timeSize; dateSize = selected.dateSize
                            textColor = selected.textColor; panelColor = selected.panelColor
                            panelAlpha = selected.panelAlpha.toFloat(); font = selected.font
                        }
                    }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Color(panelColor).copy(alpha = panelAlpha / 255f))
                    .padding(20.dp)
            ) {
                val family = when (font) {
                    "serif" -> FontFamily.Serif
                    "mono" -> FontFamily.Monospace
                    else -> FontFamily.SansSerif
                }
                androidx.compose.material3.Text(
                    text = "12:45", color = Color(textColor), fontSize = timeSize.sp,
                    fontFamily = family, fontWeight = FontWeight.Light,
                    lineHeight = (timeSize * 1.1f).sp
                )
                Spacer(Modifier.height(3.dp))
                androidx.compose.material3.Text(
                    text = "суббота, 7 ноября", color = Color(textColor).copy(alpha = 0.72f),
                    fontSize = dateSize.sp, fontFamily = family
                )
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Размер текста", 16, true)
                Spacer(Modifier.height(8.dp))
                GText(t, "Часы · ${timeSize.toInt()} sp", 13)
                Slider(value = timeSize, onValueChange = { timeSize = it }, valueRange = 28f..60f)
                GText(t, "Дата · ${dateSize.toInt()} sp", 13)
                Slider(value = dateSize, onValueChange = { dateSize = it }, valueRange = 10f..20f)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Шрифт", 16, true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GChip(t, "Sans", font == "sans") { font = "sans" }
                    GChip(t, "Serif", font == "serif") { font = "serif" }
                    GChip(t, "Mono", font == "mono") { font = "mono" }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Цвет текста", 16, true)
                Spacer(Modifier.height(8.dp))
                widgetTextColors.forEach { (name, value) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { textColor = value }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GText(t, name, 14, textColor == value)
                        Box(Modifier.height(22.dp).fillMaxWidth(0.12f).clip(RoundedCornerShape(8.dp)).background(Color(value)))
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фон виджета", 16, true)
                Spacer(Modifier.height(8.dp))
                widgetPanelColors.forEach { (name, value) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { panelColor = value }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GText(t, name, 14, panelColor == value)
                        Box(Modifier.height(22.dp).fillMaxWidth(0.12f).clip(RoundedCornerShape(8.dp)).background(Color(value)))
                    }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "Прозрачность · ${((panelAlpha / 255f) * 100).toInt()}%", 13)
                Slider(value = panelAlpha, onValueChange = { panelAlpha = it }, valueRange = 80f..255f)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить и применить", Modifier.fillMaxWidth()) {
                    ClockWidgetStyleStore.save(context, ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font), targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                    ClockDateWidgetProvider.updateAll(context)
                    feedback = "Оформление часов применено к выбранному экземпляру"
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фото-виджет", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Выбери изображение из галереи. Оно будет сохранено локально и появится в отдельном виджете на рабочем столе.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Выбрать фото", Modifier.fillMaxWidth()) { photoPicker.launch("image/*") }
                Spacer(Modifier.height(6.dp))
                GText(t, "После выбора добавь виджет «Фото» через меню виджетов лаунчера.", 12, secondary = true)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Настройка фото-виджета", 16, true)
                Spacer(Modifier.height(6.dp))
                if (photoIds.isEmpty()) GText(t, "Сначала добавь фото-виджет на рабочий стол.", 12, secondary = true)
                else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    photoIds.forEachIndexed { index, id ->
                        GChip(t, "Фото ${index + 1}", targetPhotoId == id) {
                            targetPhotoId = id
                            val crop = WidgetInstanceStore.loadCrop(context, id)
                            cropZoom = crop.zoom; cropX = crop.x; cropY = crop.y
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "Масштаб · ${String.format(java.util.Locale.getDefault(), "%.1f", cropZoom)}×", 13)
                Slider(value = cropZoom, onValueChange = { cropZoom = it }, valueRange = 1f..2.5f)
                GText(t, "Смещение по горизонтали", 13)
                Slider(value = cropX, onValueChange = { cropX = it }, valueRange = -1f..1f)
                GText(t, "Смещение по вертикали", 13)
                Slider(value = cropY, onValueChange = { cropY = it }, valueRange = -1f..1f)
                GButton(t, "Сохранить кадрирование", Modifier.fillMaxWidth()) {
                    WidgetInstanceStore.saveCrop(context, targetPhotoId.takeIf { it != AppWidgetManagerIds.NONE }, WidgetInstanceStore.PhotoCrop(cropZoom, cropX, cropY))
                    PhotoWidgetProvider.updateAll(context)
                    feedback = "Позиция фото сохранена для выбранного виджета"
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Сохранённые варианты", 16, true)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(32) }, label = { androidx.compose.material3.Text("Название варианта") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить вариант", Modifier.fillMaxWidth()) {
                    runCatching { WidgetPresetManager.saveNamedPreset(context, presetName, ClockWidgetStyle(timeSize, dateSize, textColor, panelColor, panelAlpha.toInt(), font)) }
                        .onSuccess { savedPresets = WidgetPresetManager.savedPresets(context); presetName = ""; feedback = "Вариант сохранён" }
                        .onFailure { feedback = it.message ?: "Не удалось сохранить вариант" }
                }
                savedPresets.forEach { preset ->
                    Row(Modifier.fillMaxWidth().clickable {
                        val selected = WidgetPresetManager.applyNamedPreset(context, preset.name, targetClockId.takeIf { it != AppWidgetManagerIds.NONE })
                        timeSize = selected.timeSize; dateSize = selected.dateSize
                        textColor = selected.textColor; panelColor = selected.panelColor
                        panelAlpha = selected.panelAlpha.toFloat(); font = selected.font
                        ClockDateWidgetProvider.updateAll(context)
                        feedback = "Применён вариант «${preset.name}»"
                    }.padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        GText(t, preset.name, 14, true)
                        GText(t, "Применить", 12, secondary = true)
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Пресеты .time", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Экспорт сохраняет оформление часов и выбранное фото в один файл. Импорт проверяет формат и версию перед применением.", 13, secondary = true)
                Spacer(Modifier.height(10.dp))
                GButton(t, "Экспортировать .time", Modifier.fillMaxWidth()) {
                    exportPicker.launch("widget_style.time")
                }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Импортировать .time", Modifier.fillMaxWidth()) {
                    importPicker.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Музыкальный виджет", 16, true)
                Spacer(Modifier.height(5.dp))
                GText(t, "Показывает текущий трек и исполнителя. Для работы нужен доступ time个 к уведомлениям.", 13, secondary = true)
            }
        }
    }
}

