package com.example.glasstime

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val profileAccents = listOf(
    0xFF9CCFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFB8A1D9.toInt(),
    0xFFB65A70.toInt(), 0xFFD0F59A.toInt(), 0xFF777F89.toInt()
)
private val nameDecorations = listOf("", "✦", "†", "☾", "◇", "〆")
private val profileTags = listOf("", "ARCHIVE", "VOID", "NIGHT", "CLASSIC")

@Composable
fun ProfileScreen(t: ThemeState) {
    var showCommunities by remember { mutableStateOf(false) }
    var showFeed by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var showAssistant by remember { mutableStateOf(false) }
    when {
        showCommunities -> CommunityHubScreen(t) { showCommunities = false }
        showFeed -> SocialFeedScreen(t) { showFeed = false }
        showAdvanced -> AdvancedSocialScreen(t) { showAdvanced = false }
        showAssistant -> AssistantScreen(t) { showAssistant = false }
        else -> ProfileEditorScreen(t, { showCommunities = true }, { showFeed = true }, { showAdvanced = true }, { showAssistant = true })
    }
}

@Composable
private fun ProfileEditorScreen(t: ThemeState, onOpenCommunities: () -> Unit, onOpenFeed: () -> Unit, onOpenAdvanced: () -> Unit, onOpenAssistant: () -> Unit) {
    val context = LocalContext.current
    val initial = remember(context) { ProfileStore.load(context) }
    var username by remember { mutableStateOf(initial.username) }
    var bio by remember { mutableStateOf(initial.bio) }
    var accent by remember { mutableIntStateOf(initial.accent) }
    var isPrivate by remember { mutableStateOf(initial.isPrivate) }
    var decoration by remember { mutableStateOf(initial.nameDecoration) }
    var profileTag by remember { mutableStateOf(initial.profileTag) }
    var musicMode by remember { mutableStateOf(initial.musicMode) }
    var manualTrack by remember { mutableStateOf(initial.manualTrack) }
    var manualArtist by remember { mutableStateOf(initial.manualArtist) }
    var showMusic by remember { mutableStateOf(initial.showMusic) }
    var showBio by remember { mutableStateOf(initial.showBio) }
    var avatarVersion by remember { mutableIntStateOf(0) }
    var bannerVersion by remember { mutableIntStateOf(0) }
    var musicRefresh by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf("") }
    var wallDraft by remember { mutableStateOf("") }
    val wallPosts = remember(context) { mutableStateListOf<WallPost>().apply { addAll(WallStore.load(context)) } }
    var commentTarget by remember { mutableStateOf<WallPost?>(null) }
    var commentDraft by remember { mutableStateOf("") }
    val orderedPosts = wallPosts.sortedWith(compareByDescending<WallPost> { it.pinned }.thenByDescending { it.createdAt })
    val avatar = remember(avatarVersion) { ProfileStore.loadImage(context, false)?.asImageBitmap() }
    val banner = remember(bannerVersion) { ProfileStore.loadImage(context, true)?.asImageBitmap() }
    val liveTrack = remember(musicRefresh, musicMode) {
        if (musicMode == "AUTO") MediaLog.nowPlaying(context).firstOrNull() else null
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching { ProfileStore.copyImage(context, uri, false) }
            .onSuccess { avatarVersion++; feedback = "Аватар обновлён" }
            .onFailure { feedback = it.message ?: "Не удалось сохранить аватар" }
    }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching { ProfileStore.copyImage(context, uri, true) }
            .onSuccess { bannerVersion++; feedback = "Баннер обновлён" }
            .onFailure { feedback = it.message ?: "Не удалось сохранить баннер" }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Профиль", 28, true) }
        item {
            GlassCard(t) {
                GText(t, "Социальные пространства", 16, true)
                GText(t, "Создавай сообщества и кланы, настраивай доступ и управляй ролями.", 11, secondary = true)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сообщества и кланы", Modifier.fillMaxWidth(), onOpenCommunities)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Открыть социальную ленту", Modifier.fillMaxWidth(), onOpenFeed)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Социальный центр · этапы 19–25", Modifier.fillMaxWidth(), onOpenAdvanced)
                Spacer(Modifier.height(8.dp))
                GButton(t, "AI-ассистент · этап 26", Modifier.fillMaxWidth(), onOpenAssistant)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Предпросмотр профиля", 16, true)
                Spacer(Modifier.height(8.dp))
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(t.cardColor)) {
                    Box(Modifier.fillMaxWidth().height(112.dp).background(Color(accent))) {
                        if (banner != null) Image(banner, contentDescription = "Баннер профиля", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Color(accent))) {
                            if (avatar != null) Image(avatar, contentDescription = "Аватар", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Box(Modifier.fillMaxSize().padding(18.dp).background(Color.Black.copy(alpha = .16f), CircleShape))
                        }
                        Column(Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                if (decoration.isNotBlank()) Text(decoration, color = Color(accent), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(username.ifBlank { "user" }, color = t.textColor, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                                // Fixed project mark; it is not a user-selectable decoration.
                                Text("个", color = Color(accent), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Text(ProfileStore.localId(context), color = t.textColor.copy(alpha = .55f), fontSize = 11.sp)
                            if (profileTag.isNotBlank()) Text(profileTag, color = Color(accent), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            if (showBio && bio.isNotBlank()) Text(bio, color = t.textColor.copy(alpha = .82f), fontSize = 12.sp)
                            if (showMusic) {
                                val title = if (musicMode == "AUTO") liveTrack?.title.orEmpty() else manualTrack
                                val artist = if (musicMode == "AUTO") liveTrack?.artist.orEmpty() else manualArtist
                                if (title.isNotBlank()) Text("♫ $title${if (artist.isNotBlank()) " · $artist" else ""}", color = t.textColor.copy(alpha = .78f), fontSize = 11.sp)
                            }
                        }
                    }
                }
                Text("Значок подтверждения требует серверной проверки владельцем и не выбирается вручную.", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Изображения", 16, true)
                Spacer(Modifier.height(8.dp))
                GButton(t, "Выбрать аватар", Modifier.fillMaxWidth()) { avatarPicker.launch("image/*") }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Выбрать баннер", Modifier.fillMaxWidth()) { bannerPicker.launch("image/*") }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Информация", 16, true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(username, { username = it.filterNot { ch -> ch.isWhitespace() }.take(24) }, label = { Text("Имя пользователя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(bio, { bio = it.take(160) }, label = { Text("О себе · до 160 символов") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Spacer(Modifier.height(6.dp))
                Text("Локальный ID: ${ProfileStore.localId(context)}", color = t.textColor.copy(alpha = .6f), fontSize = 11.sp)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Украшение имени", 16, true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    nameDecorations.forEach { value ->
                        Box(Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (decoration == value) Color(accent).copy(alpha = .30f) else t.cardColor)
                            .clickable { decoration = value }) {
                            Box(Modifier.fillMaxSize().padding(8.dp)) {
                                Text(if (value.isBlank()) "—" else value, color = t.textColor, fontSize = 16.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                GText(t, "Декоративная метка", 13, true)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    profileTags.forEach { value ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (profileTag == value) Color(accent).copy(alpha = .28f) else t.cardColor)
                            .clickable { profileTag = value }.padding(vertical = 9.dp, horizontal = 3.dp)) {
                            Text(if (value.isBlank()) "Нет" else value, color = t.textColor, fontSize = 9.sp)
                        }
                    }
                }
                Text("Это декоративные элементы, не отметка верификации. Символ 个 закреплён за проектом.", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Музыкальный статус", 16, true)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton(t, if (musicMode == "AUTO") "✓ Автоматически" else "Автоматически", Modifier.weight(1f)) { musicMode = "AUTO"; musicRefresh++ }
                    GButton(t, if (musicMode == "MANUAL") "✓ Вручную" else "Вручную", Modifier.weight(1f)) { musicMode = "MANUAL" }
                }
                if (musicMode == "AUTO") {
                    Spacer(Modifier.height(8.dp))
                    Text("Трек берётся из активной MediaSession. Разреши доступ к уведомлениям для обнаружения плеера.", color = t.textColor.copy(alpha = .62f), fontSize = 11.sp)
                    GButton(t, "Обновить статус", Modifier.fillMaxWidth()) { musicRefresh++ }
                    if (liveTrack == null) Text("Сейчас активный трек не обнаружен.", color = t.textColor.copy(alpha = .6f), fontSize = 11.sp)
                } else {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(manualTrack, { manualTrack = it.take(80) }, label = { Text("Название трека") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(manualArtist, { manualArtist = it.take(60) }, label = { Text("Исполнитель") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Акцент профиля", 16, true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    profileAccents.forEach { color ->
                        Box(Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(10.dp))
                            .background(Color(color)).clickable { accent = color })
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Приватность", 16, true)
                ProfileSwitch(t, "Закрытый профиль", "Локальная настройка; публикация заработает после подключения backend.", isPrivate) { isPrivate = it }
                ProfileSwitch(t, "Показывать описание", "Скрывает био в предпросмотре профиля.", showBio) { showBio = it }
                ProfileSwitch(t, "Показывать музыку", "Скрывает музыкальный статус в предпросмотре.", showMusic) { showMusic = it }
                Spacer(Modifier.height(8.dp))
                GButton(t, "Сохранить профиль", Modifier.fillMaxWidth()) {
                    ProfileStore.save(context, LocalProfile(username, bio, accent, isPrivate, decoration, profileTag, musicMode, manualTrack, manualArtist, showMusic, showBio))
                    AccountStore.updateCurrent(context)
                    feedback = "Профиль сохранён на устройстве"
                }
                if (feedback.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    GText(t, feedback, 12, true)
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Стена профиля", 16, true)
                Text("Локальные публикации: текст, реакции, комментарии и закрепление.", color = t.textColor.copy(alpha = .58f), fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = wallDraft,
                    onValueChange = { wallDraft = it.take(500) },
                    label = { Text("Новая публикация") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                Spacer(Modifier.height(7.dp))
                GButton(t, "Опубликовать", Modifier.fillMaxWidth()) {
                    val post = WallStore.newPost(wallDraft)
                    if (post.text.isNotBlank()) {
                        wallPosts.add(0, post)
                        WallStore.save(context, wallPosts)
                        wallDraft = ""
                        feedback = "Публикация добавлена на локальную стену"
                    }
                }
                if (orderedPosts.isEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("Пока нет публикаций.", color = t.textColor.copy(alpha = .6f), fontSize = 12.sp)
                }
            }
        }
        items(orderedPosts, key = { it.id }) { post ->
            GlassCard(t) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(post.createdAt)), color = t.textColor.copy(alpha = .55f), fontSize = 10.sp)
                    if (post.pinned) Text("ЗАКРЕПЛЕНО", color = Color(accent), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Text(post.text, color = t.textColor, fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    GButton(t, if (post.liked) "♥ ${post.likes}" else "♡ ${post.likes}", Modifier.weight(1f)) {
                        val index = wallPosts.indexOfFirst { it.id == post.id }
                        if (index >= 0) {
                            val old = wallPosts[index]
                            wallPosts[index] = old.copy(liked = !old.liked, likes = (old.likes + if (old.liked) -1 else 1).coerceAtLeast(0))
                            WallStore.save(context, wallPosts)
                        }
                    }
                    GButton(t, "Комментарии ${post.comments.size}", Modifier.weight(1f)) {
                        commentTarget = post
                        commentDraft = ""
                    }
                    GButton(t, if (post.pinned) "Открепить" else "Закрепить", Modifier.weight(1f)) {
                        val index = wallPosts.indexOfFirst { it.id == post.id }
                        if (index >= 0) {
                            wallPosts[index] = wallPosts[index].copy(pinned = !wallPosts[index].pinned)
                            WallStore.save(context, wallPosts)
                        }
                    }
                }
                TextButton(onClick = {
                    wallPosts.removeAll { it.id == post.id }
                    WallStore.save(context, wallPosts)
                }) { Text("Удалить публикацию", color = t.textColor.copy(alpha = .65f)) }
            }
        }
    }
    if (commentTarget != null) {
        val target = commentTarget!!
        AlertDialog(
            onDismissRequest = { commentTarget = null },
            title = { Text("Комментарии") },
            text = {
                Column {
                    if (target.comments.isEmpty()) Text("Комментариев пока нет.")
                    target.comments.forEach { comment ->
                        Text("• $comment", modifier = Modifier.padding(vertical = 3.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = commentDraft,
                        onValueChange = { commentDraft = it.take(300) },
                        label = { Text("Написать комментарий") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = commentDraft.trim()
                    val index = wallPosts.indexOfFirst { it.id == target.id }
                    if (value.isNotBlank() && index >= 0) {
                        wallPosts[index] = wallPosts[index].copy(comments = wallPosts[index].comments + value)
                        WallStore.save(context, wallPosts)
                    }
                    commentTarget = null
                }) { Text("Отправить") }
            },
            dismissButton = { TextButton(onClick = { commentTarget = null }) { Text("Закрыть") } }
        )
    }
}

@Composable
private fun ProfileSwitch(t: ThemeState, title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            GText(t, title, 14, true)
            GText(t, description, 10, secondary = true)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
