package com.example.glasstime

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class AppUsage(val pkg: String, val label: String, val icon: ImageBitmap?, val millis: Long)

fun fmt(ms: Long): String {
    val m = ms / 60000
    val h = m / 60
    return if (h > 0) "$h ч ${m % 60} мин" else if (m > 0) "$m мин" else "меньше минуты"
}

object AppInfo {
    private val icons = ConcurrentHashMap<String, ImageBitmap>()

    fun label(c: Context, pkg: String): String {
        return try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun icon(c: Context, pkg: String): ImageBitmap? {
        icons[pkg]?.let { return it }
        return try {
            val bmp = c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            icons[pkg] = bmp
            bmp
        } catch (e: Exception) {
            null
        }
    }
}

object UsageData {
    @Suppress("DEPRECATION")
    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun midnight(): Calendar {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal
    }

    private fun record(c: Context, usm: UsageStatsManager) {
        val stats = usm.queryAndAggregateUsageStats(midnight().timeInMillis, System.currentTimeMillis())
        val d = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val e = c.getSharedPreferences("usage", Context.MODE_PRIVATE).edit()
        for (s in stats.values) {
            if (s.totalTimeInForeground >= 1000L) e.putLong("u:" + d + ":" + s.packageName, s.totalTimeInForeground)
        }
        e.apply()
    }

    fun load(c: Context, days: Int): List<AppUsage> {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        record(c, usm)
        val cal = midnight()
        if (days == 0) cal.add(Calendar.DAY_OF_YEAR, -365) else if (days > 1) cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
        val stats = usm.queryAndAggregateUsageStats(cal.timeInMillis, System.currentTimeMillis())
        val totals = HashMap<String, Long>()
        for (s in stats.values) totals[s.packageName] = s.totalTimeInForeground
        if (days == 0) {
            val own = HashMap<String, Long>()
            for ((key, value) in c.getSharedPreferences("usage", Context.MODE_PRIVATE).all) {
                val v = (value as? Long) ?: continue
                val parts = key.split(":", limit = 3)
                if (parts.size == 3 && parts[0] == "u") own[parts[2]] = (own[parts[2]] ?: 0L) + v
            }
            for ((pkg, v) in own) {
                if (v > (totals[pkg] ?: 0L)) totals[pkg] = v
            }
        }
        val pm = c.packageManager
        val out = ArrayList<AppUsage>()
        for ((pkg, ms) in totals) {
            if (ms < 60_000L) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            out.add(AppUsage(pkg, AppInfo.label(c, pkg), AppInfo.icon(c, pkg), ms))
        }
        out.sortByDescending { it.millis }
        return out
    }
}

class MediaRow(val pkg: String, val label: String, val icon: ImageBitmap?, val millis: Long)
class NowPlaying(val pkg: String, val title: String, val artist: String)

object MediaLog {
    private fun sp(c: Context) = c.getSharedPreferences("media", Context.MODE_PRIVATE)
    private fun dateStr(d: Date): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(d)
    private const val MAX_SESSION = 12 * 3600_000L

    fun onStart(c: Context, pkg: String) {
        sp(c).edit().putLong("p:$pkg", System.currentTimeMillis()).apply()
        notifyMusicWidget(c)
    }

    fun onStop(c: Context, pkg: String) {
        val s = sp(c)
        val st = s.getLong("p:$pkg", 0L)
        if (st > 0L) {
            val d = (System.currentTimeMillis() - st).coerceIn(0L, MAX_SESSION)
            val k = "t:" + dateStr(Date()) + ":" + pkg
            s.edit().putLong(k, s.getLong(k, 0L) + d).remove("p:$pkg").apply()
        }
        notifyMusicWidget(c)
    }

    fun setMeta(c: Context, pkg: String, title: String?, artist: String?) {
        sp(c).edit()
            .putString("title:$pkg", title ?: "")
            .putString("artist:$pkg", artist ?: "")
            .apply()
        notifyMusicWidget(c)
    }

    private fun notifyMusicWidget(c: Context) {
        c.sendBroadcast(Intent(NowPlayingWidgetProvider.ACTION_MEDIA_UPDATE).setPackage(c.packageName))
    }

    fun rows(c: Context, days: Int): List<MediaRow> {
        val dates = HashSet<String>()
        for (i in 0 until days) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            dates.add(dateStr(cal.time))
        }
        val totals = HashMap<String, Long>()
        val now = System.currentTimeMillis()
        for ((key, value) in sp(c).all) {
            val v = (value as? Long) ?: continue
            if (key.startsWith("t:")) {
                val parts = key.split(":", limit = 3)
                if (parts.size == 3 && (days == 0 || parts[1] in dates)) {
                    totals[parts[2]] = (totals[parts[2]] ?: 0L) + v
                }
            } else if (key.startsWith("p:")) {
                val pkg = key.substring(2)
                val live = (now - v).coerceIn(0L, MAX_SESSION)
                totals[pkg] = (totals[pkg] ?: 0L) + live
            }
        }
        return totals.entries
            .filter { it.value >= 1000L }
            .sortedByDescending { it.value }
            .map { MediaRow(it.key, AppInfo.label(c, it.key), AppInfo.icon(c, it.key), it.value) }
    }

    fun nowPlaying(c: Context): List<NowPlaying> {
        val s = sp(c)
        val out = ArrayList<NowPlaying>()
        for ((key, value) in s.all) {
            if (key.startsWith("p:") && value is Long) {
                val pkg = key.substring(2)
                out.add(NowPlaying(pkg, s.getString("title:$pkg", "") ?: "", s.getString("artist:$pkg", "") ?: ""))
            }
        }
        return out
    }

    fun listenerEnabled(c: Context): Boolean {
        return NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    }
}
