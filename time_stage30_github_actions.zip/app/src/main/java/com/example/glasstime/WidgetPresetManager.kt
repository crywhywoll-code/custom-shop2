package com.example.glasstime

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object WidgetPresetManager {
    const val PHOTO_FILE = "widget_photo.jpg"
    private const val FORMAT = "time-widget"
    private const val VERSION = 2
    private const val MAX_PRESET_BYTES = 12 * 1024 * 1024
    private const val MAX_PHOTO_BYTES = 8 * 1024 * 1024
    private const val PRESET_PREFS = "widget_named_presets"
    private const val PRESET_LIST = "items"

    data class NamedPreset(val name: String, val style: ClockWidgetStyle)

    fun copyPhotoFromUri(context: Context, uri: Uri, widgetId: Int? = null) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: error("Не удалось открыть изображение")
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Файл не является изображением" }
        var sample = 1
        while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: error("Не удалось прочитать изображение")
        try {
            WidgetInstanceStore.photoFile(context, widgetId).outputStream().use { out ->
                check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) { "Не удалось сохранить изображение" }
            }
        } finally { bitmap.recycle() }
    }

    fun saveNamedPreset(context: Context, name: String, style: ClockWidgetStyle) {
        val cleanName = name.trim().take(32)
        require(cleanName.isNotBlank()) { "Укажи название пресета" }
        val all = savedPresets(context).filterNot { it.name.equals(cleanName, true) }.toMutableList()
        require(all.size <= 19) { "Можно хранить не более 20 пресетов" }
        all.add(0, NamedPreset(cleanName, style))
        savePresetList(context, all)
    }

    fun savedPresets(context: Context): List<NamedPreset> = runCatching {
        val raw = context.getSharedPreferences(PRESET_PREFS, Context.MODE_PRIVATE).getString(PRESET_LIST, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val name = item.optString("name").take(32)
            if (name.isBlank()) return@mapNotNull null
            NamedPreset(name, readStyle(item.optJSONObject("style") ?: JSONObject()))
        }
    }.getOrDefault(emptyList())

    fun applyNamedPreset(context: Context, name: String, widgetId: Int? = null): ClockWidgetStyle {
        val preset = savedPresets(context).firstOrNull { it.name == name } ?: error("Пресет не найден")
        ClockWidgetStyleStore.save(context, preset.style, widgetId)
        return preset.style
    }

    private fun savePresetList(context: Context, presets: List<NamedPreset>) {
        val array = JSONArray()
        presets.forEach { array.put(JSONObject().put("name", it.name).put("style", styleJson(it.style))) }
        context.getSharedPreferences(PRESET_PREFS, Context.MODE_PRIVATE).edit()
            .putString(PRESET_LIST, array.toString()).apply()
    }

    fun export(context: Context, style: ClockWidgetStyle): ByteArray {
        val json = JSONObject().apply {
            put("format", FORMAT)
            put("version", VERSION)
            put("widget", styleJson(style))
            val variants = JSONArray()
            savedPresets(context).forEach { variants.put(JSONObject().put("name", it.name).put("style", styleJson(it.style))) }
            put("presets", variants)
            val photo = File(context.filesDir, PHOTO_FILE)
            if (photo.exists() && photo.length() <= MAX_PHOTO_BYTES) {
                put("photoJpegBase64", Base64.encodeToString(photo.readBytes(), Base64.NO_WRAP))
            }
        }
        return json.toString(2).toByteArray(Charsets.UTF_8)
    }

    fun import(context: Context, bytes: ByteArray): ClockWidgetStyle {
        require(bytes.isNotEmpty() && bytes.size <= MAX_PRESET_BYTES) { "Файл пустой или слишком большой" }
        val json = JSONObject(bytes.toString(Charsets.UTF_8))
        require(json.optString("format") == FORMAT) { "Это не пресет виджетов time个" }
        val version = json.optInt("version", -1)
        require(version in 1..VERSION) { "Версия пресета не поддерживается" }
        val style = readStyle(json.optJSONObject("widget") ?: error("В пресете нет оформления виджета"))
        if (version >= 2) {
            val variants = json.optJSONArray("presets") ?: JSONArray()
            val imported = (0 until variants.length()).mapNotNull { i ->
                val item = variants.optJSONObject(i) ?: return@mapNotNull null
                val name = item.optString("name").trim().take(32)
                if (name.isBlank()) null else NamedPreset(name, readStyle(item.optJSONObject("style") ?: JSONObject()))
            }.take(20)
            savePresetList(context, imported)
        }
        val encodedPhoto = json.optString("photoJpegBase64", "")
        if (encodedPhoto.isNotBlank()) {
            val imageBytes = Base64.decode(encodedPhoto, Base64.DEFAULT)
            require(imageBytes.size <= MAX_PHOTO_BYTES) { "Изображение в пресете слишком большое" }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, bounds)
            require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Изображение в пресете повреждено" }
            var sample = 1
            while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2
            val bitmap = BitmapFactory.decodeByteArray(
                imageBytes, 0, imageBytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: error("Изображение в пресете повреждено")
            try {
                File(context.filesDir, PHOTO_FILE).outputStream().use { out ->
                    check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out))
                }
            } finally { bitmap.recycle() }
        }
        ClockWidgetStyleStore.save(context, style)
        return style
    }

    private fun styleJson(style: ClockWidgetStyle) = JSONObject().apply {
        put("timeSize", style.timeSize.toDouble())
        put("dateSize", style.dateSize.toDouble())
        put("textColor", style.textColor)
        put("panelColor", style.panelColor)
        put("panelAlpha", style.panelAlpha)
        put("font", style.font)
    }

    private fun readStyle(w: JSONObject) = ClockWidgetStyle(
        timeSize = w.optDouble("timeSize", 42.0).toFloat().coerceIn(28f, 60f),
        dateSize = w.optDouble("dateSize", 13.0).toFloat().coerceIn(10f, 20f),
        textColor = w.optInt("textColor", 0xFFFFFFFF.toInt()),
        panelColor = w.optInt("panelColor", 0xFF252B33.toInt()),
        panelAlpha = w.optInt("panelAlpha", 220).coerceIn(80, 255),
        font = w.optString("font", "sans").takeIf { it in setOf("sans", "serif", "mono") } ?: "sans"
    )
}
