package com.example.glasstime

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

class MediaTrackerService : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private val controllers = HashMap<String, MediaController>()
    private val callbacks = HashMap<String, MediaController.Callback>()
    private val playing = HashSet<String>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list ->
            refresh(list ?: emptyList())
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val m = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm = m
        val cn = ComponentName(this, MediaTrackerService::class.java)
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            refresh(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // no access yet
        }
    }

    override fun onListenerDisconnected() {
        shutdown()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        for ((pkg, c) in controllers) {
            callbacks[pkg]?.let { c.unregisterCallback(it) }
            stopTrack(pkg)
        }
        controllers.clear()
        callbacks.clear()
    }

    private fun refresh(list: List<MediaController>) {
        val pkgs = list.map { it.packageName }.toSet()
        for (pkg in controllers.keys.toList()) {
            if (pkg !in pkgs) {
                stopTrack(pkg)
                val c = controllers.remove(pkg)
                val cb = callbacks.remove(pkg)
                if (c != null && cb != null) c.unregisterCallback(cb)
            }
        }
        for (c in list) {
            val pkg = c.packageName
            if (controllers.containsKey(pkg)) continue
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    handle(pkg, state)
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    meta(pkg, metadata)
                }
            }
            c.registerCallback(cb)
            controllers[pkg] = c
            callbacks[pkg] = cb
            handle(pkg, c.playbackState)
            meta(pkg, c.metadata)
        }
    }

    private fun handle(pkg: String, st: PlaybackState?) {
        val isPlaying = st?.state == PlaybackState.STATE_PLAYING
        if (isPlaying) {
            if (playing.add(pkg)) MediaLog.onStart(this, pkg)
        } else {
            stopTrack(pkg)
        }
    }

    private fun stopTrack(pkg: String) {
        if (playing.remove(pkg)) MediaLog.onStop(this, pkg)
    }

    private fun meta(pkg: String, md: MediaMetadata?) {
        MediaLog.setMeta(
            this,
            pkg,
            md?.getString(MediaMetadata.METADATA_KEY_TITLE),
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        )
    }
}
