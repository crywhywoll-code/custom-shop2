package com.example.glasstime

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.content.Intent
import android.graphics.Bitmap
import android.service.notification.NotificationListenerService

class MediaTrackerService : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private val controllers = HashMap<String, MediaController>()
    private val callbacks = HashMap<String, MediaController.Callback>()
    private val playing = HashSet<String>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list ->
            refresh(list ?: emptyList())
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val m = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm = m
        val cn = ComponentName(this, MediaTrackerService::class.java)
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            refresh(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // no access yet
        }
    }

    override fun onListenerDisconnected() {
        shutdown()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        for ((pkg, c) in controllers) {
            callbacks[pkg]?.let { c.unregisterCallback(it) }
            stopTrack(pkg)
        }
        controllers.clear()
        callbacks.clear()
    }

    private fun refresh(list: List<MediaController>) {
        val pkgs = list.map { it.packageName }.toSet()
        for (pkg in controllers.keys.toList()) {
            if (pkg !in pkgs) {
                stopTrack(pkg)
                val c = controllers.remove(pkg)
                val cb = callbacks.remove(pkg)
                if (c != null && cb != null) c.unregisterCallback(cb)
            }
        }
        for (c in list) {
            val pkg = c.packageName
            if (controllers.containsKey(pkg)) continue
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    handle(pkg, state)
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    meta(pkg, metadata)
                }
            }
            c.registerCallback(cb)
            controllers[pkg] = c
            callbacks[pkg] = cb
            handle(pkg, c.playbackState)
            meta(pkg, c.metadata)
        }
    }

    private fun handle(pkg: String, st: PlaybackState?) {
        val isPlaying = st?.state == PlaybackState.STATE_PLAYING
        if (isPlaying) {
            if (playing.add(pkg)) MediaLog.onStart(this, pkg)
        } else {
            stopTrack(pkg)
        }
    }

    private fun stopTrack(pkg: String) {
        if (playing.remove(pkg)) MediaLog.onStop(this, pkg)
    }

    private fun meta(pkg: String, md: MediaMetadata?) {
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        runCatching { MusicWidgetStyleStore.saveArtwork(this, art) }
        MediaLog.setMeta(
            this,
            pkg,
            md?.getString(MediaMetadata.METADATA_KEY_TITLE),
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val cn = ComponentName(this, MediaTrackerService::class.java)
        val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        runCatching {
            val sessions = manager.getActiveSessions(cn)
            val target = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: sessions.firstOrNull()
            when (action) {
                ACTION_PREVIOUS -> target?.transportControls?.skipToPrevious()
                ACTION_PLAY_PAUSE -> {
                    if (target?.playbackState?.state == PlaybackState.STATE_PLAYING) target.transportControls.pause()
                    else target?.transportControls?.play()
                }
                ACTION_NEXT -> target?.transportControls?.skipToNext()
            }
        }
        return android.app.Service.START_NOT_STICKY
    }

    companion object {
        const val ACTION_PREVIOUS = "com.example.glasstime.MEDIA_PREVIOUS"
        const val ACTION_PLAY_PAUSE = "com.example.glasstime.MEDIA_PLAY_PAUSE"
        const val ACTION_NEXT = "com.example.glasstime.MEDIA_NEXT"
    }
}

class MusicWidgetControlReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: android.content.Context, intent: Intent) {
        runCatching {
            val manager = context.getSystemService(android.content.Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(context, MediaTrackerService::class.java))
            val target = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: sessions.firstOrNull()
            when (intent.action) {
                MediaTrackerService.ACTION_PREVIOUS -> target?.transportControls?.skipToPrevious()
                MediaTrackerService.ACTION_PLAY_PAUSE -> {
                    if (target?.playbackState?.state == PlaybackState.STATE_PLAYING) target.transportControls.pause()
                    else target?.transportControls?.play()
                }
                MediaTrackerService.ACTION_NEXT -> target?.transportControls?.skipToNext()
            }
        }
    }
}
