package com.example.glasstime

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.UUID

data class LocalProfile(
    val username: String = "user",
    val bio: String = "",
    val accent: Int = 0xFF9CCFFF.toInt(),
    val isPrivate: Boolean = true,
    val nameDecoration: String = "",
    val profileTag: String = "",
    val musicMode: String = "AUTO",
    val manualTrack: String = "",
    val manualArtist: String = "",
    val showMusic: Boolean = true,
    val showBio: Boolean = true
)

object ProfileStore {
    private const val PREFS = "local_profile"
    private const val AVATAR = "profile_avatar.jpg"
    private const val BANNER = "profile_banner.jpg"

    fun load(context: Context): LocalProfile {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return LocalProfile(
            username = p.getString("username", "user") ?: "user",
            bio = p.getString("bio", "") ?: "",
            accent = p.getInt("accent", 0xFF9CCFFF.toInt()),
            isPrivate = p.getBoolean("private", true),
            nameDecoration = p.getString("name_decoration", "") ?: "",
            profileTag = p.getString("profile_tag", "") ?: "",
            musicMode = p.getString("music_mode", "AUTO") ?: "AUTO",
            manualTrack = p.getString("manual_track", "") ?: "",
            manualArtist = p.getString("manual_artist", "") ?: "",
            showMusic = p.getBoolean("show_music", true),
            showBio = p.getBoolean("show_bio", true)
        )
    }

    fun save(context: Context, profile: LocalProfile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("username", profile.username.trim().take(24).ifBlank { "user" })
            .putString("bio", profile.bio.take(160))
            .putInt("accent", profile.accent)
            .putBoolean("private", profile.isPrivate)
            .putString("name_decoration", profile.nameDecoration.take(4))
            .putString("profile_tag", profile.profileTag.take(18))
            .putString("music_mode", if (profile.musicMode == "MANUAL") "MANUAL" else "AUTO")
            .putString("manual_track", profile.manualTrack.take(80))
            .putString("manual_artist", profile.manualArtist.take(60))
            .putBoolean("show_music", profile.showMusic)
            .putBoolean("show_bio", profile.showBio)
            .apply()
    }

    fun localId(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = p.getString("local_id", null)
        if (existing != null) return existing
        val id = "local-" + UUID.randomUUID().toString().take(8)
        p.edit().putString("local_id", id).apply()
        return id
    }

    fun copyImage(context: Context, uri: Uri, banner: Boolean) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: error("Не удалось открыть изображение")
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Файл не является изображением" }
        val limit = if (banner) 1600 else 720
        var sample = 1
        while (bounds.outWidth / sample > limit || bounds.outHeight / sample > limit) sample *= 2
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: error("Не удалось прочитать изображение")
        val target = File(context.filesDir, if (banner) BANNER else AVATAR)
        try {
            target.outputStream().use { out ->
                check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) { "Не удалось сохранить изображение" }
            }
        } finally { bitmap.recycle() }
    }

    fun loadImage(context: Context, banner: Boolean): Bitmap? {
        val file = File(context.filesDir, if (banner) BANNER else AVATAR).takeIf { it.exists() } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        val limit = if (banner) 1200 else 500
        while (bounds.outWidth / sample > limit || bounds.outHeight / sample > limit) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
