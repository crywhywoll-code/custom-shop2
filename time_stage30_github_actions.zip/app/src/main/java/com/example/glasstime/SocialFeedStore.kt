package com.example.glasstime

import android.content.Context
import org.json.JSONArray

/** Local relationship graph. Replace with a backend repository before multi-device release. */
object SocialFeedStore {
    private const val PREFS = "social_graph"
    private const val KEY = "following_v1"

    fun following(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            buildList { for (i in 0 until a.length()) a.optString(i).trim().take(80).takeIf { it.isNotBlank() }?.let(::add) }.distinct()
        }.getOrDefault(emptyList())
    }

    fun follow(context: Context, currentUserId: String, targetId: String): Pair<List<String>, String?> {
        val id = targetId.trim().removePrefix("@").take(80)
        if (id.length < 4) return following(context) to "ID должен содержать минимум 4 символа"
        if (id == currentUserId) return following(context) to "Нельзя подписаться на собственный профиль"
        val current = following(context)
        if (id in current) return current to "Эта подписка уже добавлена"
        val next = (listOf(id) + current).take(300)
        save(context, next)
        return next to null
    }

    fun unfollow(context: Context, id: String): List<String> {
        val next = following(context).filterNot { it == id }
        save(context, next)
        return next
    }

    private fun save(context: Context, ids: List<String>) {
        val array = JSONArray().apply { ids.take(300).forEach { put(it) } }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }
}
