package com.example.glasstime

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

class Preset(val name: String, val colors: List<Color>)

val Presets = listOf(
    Preset("Рассвет", listOf(Color(0xFFFF9A9E), Color(0xFFFAD0C4), Color(0xFFA18CD1))),
    Preset("Океан", listOf(Color(0xFF2193B0), Color(0xFF6DD5ED), Color(0xFF3A6073))),
    Preset("Ночь", listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))),
    Preset("Лес", listOf(Color(0xFF134E5E), Color(0xFF71B280), Color(0xFF0B3D2E))),
    Preset("Графит", listOf(Color(0xFF232526), Color(0xFF414345), Color(0xFF6B6B6B))),
    Preset("Лаванда", listOf(Color(0xFFDDD6F3), Color(0xFFFAACA8), Color(0xFF9AA7F0)))
)

val Accents = listOf(
    Color(0xFF7CC4FF),
    Color(0xFFFF8FB1),
    Color(0xFFB9F27C),
    Color(0xFFFFD36E),
    Color(0xFFC8A2FF),
    Color(0xFFFFFFFF)
)

class ThemeState(private val sp: SharedPreferences) {
    var bgType by mutableIntStateOf(sp.getInt("bgType", 0))
    var preset by mutableIntStateOf(sp.getInt("preset", 0))
    var blur by mutableFloatStateOf(sp.getFloat("blur", 18f))
    var glass by mutableFloatStateOf(sp.getFloat("glass", 0.18f))
    var dim by mutableFloatStateOf(sp.getFloat("dim", 0.12f))
    var darkText by mutableStateOf(sp.getBoolean("darkText", false))
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var appTheme by mutableStateOf(sp.getString("appTheme", "Glass") ?: "Glass")
    var photo by mutableStateOf<ImageBitmap?>(null)
    var globalFont by mutableStateOf(sp.getString("globalFont", "Sans") ?: "Sans")
    var cardRadius by mutableFloatStateOf(sp.getFloat("cardRadius", 24f))
    var borderAlpha by mutableFloatStateOf(sp.getFloat("borderAlpha", 0.32f))
    var pressEffects by mutableStateOf(sp.getBoolean("pressEffects", true))
    var splashEnabled by mutableStateOf(sp.getBoolean("splashEnabled", true))
    var splashDuration by mutableIntStateOf(sp.getInt("splashDuration", 1200))
    var splashAnimation by mutableStateOf(sp.getString("splashAnimation", "Fade") ?: "Fade")

    val textColor: Color
        get() = when (appTheme) {
            "AMOLED" -> Color.White
            "Standard" -> Color(0xFF202124)
            else -> if (darkText) Color(0xFF14161A) else Color.White
        }

    val secondaryTextColor: Color
        get() = when (appTheme) {
            "Standard" -> Color(0xFF5F6368)
            else -> textColor.copy(alpha = 0.7f)
        }

    val cardColor: Color
        get() = when (appTheme) {
            "AMOLED" -> Color(0xFF101010)
            "Standard" -> Color(0xFFFFFFFF)
            else -> Color.Transparent
        }
    val accentColor: Color
        get() = Accents[accent.coerceIn(0, Accents.size - 1)]

    fun save() {
        sp.edit()
            .putInt("bgType", bgType)
            .putInt("preset", preset)
            .putFloat("blur", blur)
            .putFloat("glass", glass)
            .putFloat("dim", dim)
            .putBoolean("darkText", darkText)
            .putInt("accent", accent)
            .putString("appTheme", appTheme)
            .putString("globalFont", globalFont)
            .putFloat("cardRadius", cardRadius)
            .putFloat("borderAlpha", borderAlpha)
            .putBoolean("pressEffects", pressEffects)
            .putBoolean("splashEnabled", splashEnabled)
            .putInt("splashDuration", splashDuration)
            .putString("splashAnimation", splashAnimation)
            .apply()
    }

    fun reset() {
        bgType = 0
        preset = 0
        blur = 18f
        glass = 0.18f
        dim = 0.12f
        darkText = false
        accent = 0
        appTheme = "Glass"
        globalFont = "Sans"; cardRadius = 24f; borderAlpha = 0.32f; pressEffects = true
        splashEnabled = true; splashDuration = 1200; splashAnimation = "Fade"
        save()
    }
}

object PhotoStore {
    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false
            File(ctx.filesDir, "bg.jpg").outputStream().use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun load(ctx: Context): ImageBitmap? {
        val f = File(ctx.filesDir, "bg.jpg")
        if (!f.exists()) return null
        return BitmapFactory.decodeFile(f.path)?.asImageBitmap()
    }
}
