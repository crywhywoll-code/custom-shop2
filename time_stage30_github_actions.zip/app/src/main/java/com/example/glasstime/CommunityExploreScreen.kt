package com.example.glasstime

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CommunityExploreScreen(t: ThemeState, onBack: () -> Unit) {
    val context = LocalContext.current
    val userId = remember(context) { ProfileStore.localId(context) }
    var communities by remember { mutableStateOf(CommunityStore.load(context)) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("ALL") }
    var feedback by remember { mutableStateOf("") }
    val visible = communities.filter { c ->
        val matches = c.name.contains(query, true) || c.tag.contains(query.removePrefix("#"), true) || c.description.contains(query, true)
        val category = when (filter) {
            "OPEN" -> !c.isPrivate
            "CLAN" -> c.kind == "CLAN"
            "COMMUNITY" -> c.kind == "COMMUNITY"
            else -> true
        }
        matches && category
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                GText(t, "Обзор сообществ", 24, true)
                TextButton(onClick = onBack) { Text("Назад") }
            }
            OutlinedTextField(query, { query = it.take(50) }, label = { Text("Поиск по названию или тегу") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL" to "Все", "OPEN" to "Открытые").forEach { (key, label) ->
                        GButton(t, if (filter == key) "✓ $label" else label, Modifier.weight(1f)) { filter = key }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("COMMUNITY" to "Сообщества", "CLAN" to "Кланы").forEach { (key, label) ->
                        GButton(t, if (filter == key) "✓ $label" else label, Modifier.weight(1f)) { filter = key }
                    }
                }
            }
        }
        if (visible.isEmpty()) item { GlassCard(t) { GText(t, "Ничего не найдено", 14, true); GText(t, "Проверь запрос или создай своё пространство.", 11, secondary = true) } }
        items(visible, key = { it.id }) { c ->
            val member = c.members.any { it.userId == userId }
            val requested = c.requests.any { it.userId == userId }
            GlassCard(t) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        GText(t, c.name, 16, true)
                        GText(t, "[${c.tag}] · ${if (c.kind == "CLAN") "Клан" else "Сообщество"}", 10, secondary = true)
                    }
                    GText(t, "${c.memberCount} участников", 9, secondary = true)
                }
                if (c.description.isNotBlank()) GText(t, c.description, 11)
                Spacer(Modifier.height(6.dp))
                when {
                    member -> GText(t, "Ты уже участник", 11, true)
                    requested -> GText(t, "Заявка отправлена", 11, true)
                    else -> GButton(t, if (c.isPrivate) "Подать заявку" else "Вступить", Modifier.fillMaxWidth()) {
                        communities = CommunityStore.join(context, communities, c.id, userId)
                        feedback = if (c.isPrivate) "Заявка отправлена владельцу" else "Ты вступил в ${c.name}"
                    }
                }
            }
        }
        if (feedback.isNotBlank()) item { Text(feedback, color = t.textColor.copy(alpha = .7f), fontSize = 11.sp) }
        item { Text("Обзор показывает только пространства, созданные на этом устройстве. Глобальный поиск появится после подключения backend.", color = t.textColor.copy(alpha = .5f), fontSize = 10.sp) }
    }
}
