package com.example.glasstime.data.local

import android.content.SharedPreferences
import com.example.glasstime.domain.repository.NavigationRepository

class LocalNavigationRepository(
    private val preferences: SharedPreferences
) : NavigationRepository {
    override fun selectedTab(): Int = preferences.getInt("selected_tab", 0).coerceIn(0, 5)

    override fun saveSelectedTab(tab: Int) {
        preferences.edit().putInt("selected_tab", tab.coerceIn(0, 5)).apply()
    }
}
