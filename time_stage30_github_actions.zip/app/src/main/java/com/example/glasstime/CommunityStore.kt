package com.example.glasstime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Local-first community model. IDs are stable so the store can later be replaced by a backend repository. */
data class CommunityMember(val userId: String, val role: String = "MEMBER")
data class CommunityRequest(val userId: String, val createdAt: Long)
data class LocalCommunity(
    val id: String,
    val name: String,
    val tag: String,
    val description: String,
    val kind: String,
    val isPrivate: Boolean,
    val ownerId: String,
    val members: List<CommunityMember>,
    val requests: List<CommunityRequest>,
    val createdAt: Long,
    val accentColor: Int = 0xFF9CCFFF.toInt(),
    val panelColor: Int = 0xFF252B33.toInt()
) {
    val memberCount: Int get() = members.size
}

object CommunityStore {
    private const val PREFS = "local_communities"
    private const val KEY = "communities_v1"

    fun load(context: Context): List<LocalCommunity> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val membersJson = item.optJSONArray("members") ?: JSONArray()
                    val requestsJson = item.optJSONArray("requests") ?: JSONArray()
                    val members = buildList {
                        for (j in 0 until membersJson.length()) {
                            val m = membersJson.optJSONObject(j) ?: continue
                            val id = m.optString("userId").take(80)
                            if (id.isNotBlank()) add(CommunityMember(id, m.optString("role", "MEMBER").take(16)))
                        }
                    }
                    val requests = buildList {
                        for (j in 0 until requestsJson.length()) {
                            val r = requestsJson.optJSONObject(j) ?: continue
                            val id = r.optString("userId").take(80)
                            if (id.isNotBlank()) add(CommunityRequest(id, r.optLong("createdAt", 0L)))
                        }
                    }
                    val name = item.optString("name").trim().take(32)
                    val tag = item.optString("tag").uppercase().take(12)
                    val owner = item.optString("ownerId").take(80)
                    if (name.isNotBlank() && tag.isNotBlank() && owner.isNotBlank()) {
                        add(LocalCommunity(
                            id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                            name = name,
                            tag = tag,
                            description = item.optString("description").take(240),
                            kind = if (item.optString("kind") == "CLAN") "CLAN" else "COMMUNITY",
                            isPrivate = item.optBoolean("isPrivate", false),
                            ownerId = owner,
                            members = members,
                            requests = requests,
                            createdAt = item.optLong("createdAt", 0L),
                            accentColor = item.optInt("accentColor", 0xFF9CCFFF.toInt()),
                            panelColor = item.optInt("panelColor", 0xFF252B33.toInt())
                        ))
                    }
                }
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, communities: List<LocalCommunity>) {
        val array = JSONArray()
        communities.take(100).forEach { c ->
            val members = JSONArray().apply {
                c.members.take(500).forEach { put(JSONObject().put("userId", it.userId).put("role", it.role)) }
            }
            val requests = JSONArray().apply {
                c.requests.take(200).forEach { put(JSONObject().put("userId", it.userId).put("createdAt", it.createdAt)) }
            }
            array.put(JSONObject().apply {
                put("id", c.id); put("name", c.name.take(32)); put("tag", c.tag.take(12))
                put("description", c.description.take(240)); put("kind", c.kind)
                put("isPrivate", c.isPrivate); put("ownerId", c.ownerId)
                put("members", members); put("requests", requests); put("createdAt", c.createdAt)
                put("accentColor", c.accentColor); put("panelColor", c.panelColor)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun create(
        context: Context, current: List<LocalCommunity>, name: String, tag: String,
        description: String, kind: String, isPrivate: Boolean, ownerId: String
    ): Pair<List<LocalCommunity>, String?> {
        val cleanName = name.trim().take(32)
        val cleanTag = tag.trim().uppercase().removePrefix("[").removeSuffix("]")
        if (cleanName.length < 2) return current to "Название должно содержать минимум 2 символа"
        if (!cleanTag.matches(Regex("[A-Z0-9_]{2,12}"))) return current to "Тег: 2–12 символов A–Z, 0–9 или _"
        if (current.any { it.tag.equals(cleanTag, true) }) return current to "Этот тег уже занят на устройстве"
        val created = LocalCommunity(
            id = UUID.randomUUID().toString(), name = cleanName, tag = cleanTag,
            description = description.trim().take(240), kind = if (kind == "CLAN") "CLAN" else "COMMUNITY",
            isPrivate = isPrivate, ownerId = ownerId,
            members = listOf(CommunityMember(ownerId, "OWNER")), requests = emptyList(),
            createdAt = System.currentTimeMillis()
        )
        val next = listOf(created) + current
        save(context, next)
        return next to null
    }

    fun join(context: Context, current: List<LocalCommunity>, id: String, userId: String): List<LocalCommunity> = update(context, current, id) { c ->
        if (c.members.any { it.userId == userId } || c.requests.any { it.userId == userId }) c
        else if (c.isPrivate) c.copy(requests = c.requests + CommunityRequest(userId, System.currentTimeMillis()))
        else c.copy(members = c.members + CommunityMember(userId))
    }

    fun reviewRequest(context: Context, current: List<LocalCommunity>, id: String, userId: String, approve: Boolean): List<LocalCommunity> = update(context, current, id) { c ->
        if (c.ownerId.isBlank()) c else {
            val pending = c.requests.filterNot { it.userId == userId }
            c.copy(requests = pending, members = if (approve && c.members.none { it.userId == userId }) c.members + CommunityMember(userId) else c.members)
        }
    }

    fun setModerator(context: Context, current: List<LocalCommunity>, id: String, userId: String, moderator: Boolean): List<LocalCommunity> = update(context, current, id) { c ->
        if (userId == c.ownerId) c else c.copy(members = c.members.map { m ->
            if (m.userId != userId || m.role == "OWNER") m else m.copy(role = if (moderator) "MODERATOR" else "MEMBER")
        })
    }

    fun leave(context: Context, current: List<LocalCommunity>, id: String, userId: String): List<LocalCommunity> = update(context, current, id) { c ->
        if (userId == c.ownerId) c else c.copy(members = c.members.filterNot { it.userId == userId }, requests = c.requests.filterNot { it.userId == userId })
    }

    fun updateAppearance(context: Context, current: List<LocalCommunity>, id: String, accentColor: Int, panelColor: Int): List<LocalCommunity> =
        update(context, current, id) { c -> c.copy(accentColor = accentColor, panelColor = panelColor) }

    private fun update(context: Context, current: List<LocalCommunity>, id: String, transform: (LocalCommunity) -> LocalCommunity): List<LocalCommunity> {
        val next = current.map { if (it.id == id) transform(it) else it }
        save(context, next)
        return next
    }

    fun copyImage(context: Context, id: String, uri: Uri, banner: Boolean) {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = context.contentResolver.openInputStream(uri) ?: error("Не удалось открыть изображение")
        boundsStream.use { BitmapFactory.decodeStream(it, null, options) }
        require(options.outWidth > 0 && options.outHeight > 0) { "Некорректное изображение" }
        val limit = if (banner) 1800 else 900
        var sample = 1
        while (options.outWidth / sample > limit || options.outHeight / sample > limit) sample *= 2
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: error("Не удалось декодировать изображение")
        val file = File(context.filesDir, "community_${id}_${if (banner) "banner" else "avatar"}.jpg")
        try {
            file.outputStream().use { out -> check(bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)) }
        } finally { bitmap.recycle() }
    }

    fun loadImage(context: Context, id: String, banner: Boolean): Bitmap? {
        val file = File(context.filesDir, "community_${id}_${if (banner) "banner" else "avatar"}.jpg")
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }
}
