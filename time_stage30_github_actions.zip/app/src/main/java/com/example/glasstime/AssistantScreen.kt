package com.example.glasstime

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun AssistantScreen(t: ThemeState, onBack: () -> Unit) {
    val context = LocalContext.current
    var prompt by remember { mutableStateOf("") }
    var suggestion by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Я могу помочь с темами, цветами и настройками time个. Изменения применяются только после твоего подтверждения.") }
    var previous by remember { mutableStateOf<ThemeSnapshot?>(null) }
    var canUndo by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { GText(t, "AI-ассистент", 28, true) }
        item { GlassCard(t) { GText(t, "Локальный помощник", 16, true); GText(t, "Работает без отправки сообщений на сервер. Пока понимает команды настройки внешнего вида; подключение языковой модели потребует отдельного API и сервера.", 12, secondary = true) } }
        item { GlassCard(t) {
            GText(t, "Диалог", 16, true)
            Spacer(Modifier.height(8.dp)); GText(t, reply, 14)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(), label = { androidx.compose.material3.Text("Напиши, что изменить") })
            Spacer(Modifier.height(8.dp))
            GButton(t, "Подготовить предложение", Modifier.fillMaxWidth()) {
                val p = prompt.lowercase()
                suggestion = when {
                    "amoled" in p || "чёрн" in p || "черн" in p -> "Переключить тему приложения на AMOLED"
                    "standard" in p || "светл" in p || "обычн" in p -> "Переключить тему приложения на Standard"
                    "glass" in p || "стекл" in p -> "Переключить тему приложения на Glass"
                    "голуб" in p || "син" in p -> "Установить голубой акцент"
                    "розов" in p -> "Установить розовый акцент"
                    "зелён" in p || "зелен" in p -> "Установить лаймовый акцент"
                    "сброс" in p -> "Сбросить визуальные настройки приложения"
                    else -> "Команда не распознана. Попробуй: «сделай AMOLED», «голубой акцент», «стеклянная тема» или «сбрось стиль»."
                }
                reply = "Я подготовил вариант. Проверь его ниже — ничего ещё не изменено."
            }
        } }
        if (suggestion.isNotBlank()) item { GlassCard(t) {
            GText(t, "Предпросмотр изменения", 16, true); GText(t, suggestion, 14)
            if (!suggestion.startsWith("Команда не распознана")) {
                Spacer(Modifier.height(8.dp))
                GButton(t, "Применить", Modifier.fillMaxWidth()) {
                    previous = ThemeSnapshot(t.appTheme, t.accent, t.bgType, t.preset, t.glass, t.dim, t.blur, t.globalFont, t.cardRadius, t.borderAlpha, t.pressEffects, t.splashEnabled, t.splashDuration, t.splashAnimation)
                    when {
                        "AMOLED" in suggestion -> t.appTheme = "AMOLED"
                        "Standard" in suggestion -> t.appTheme = "Standard"
                        "Glass" in suggestion -> t.appTheme = "Glass"
                        "голубой" in suggestion -> t.accent = 0
                        "розовый" in suggestion -> t.accent = 1
                        "лаймовый" in suggestion -> t.accent = 2
                        "Сбросить" in suggestion -> t.reset()
                    }
                    t.save(); canUndo = true; reply = "Готово. Изменение применено локально."
                    suggestion = ""
                }
            }
        } }
        if (canUndo && previous != null) item { GButton(t, "Отменить последнее изменение", Modifier.fillMaxWidth()) {
            val s = previous!!; t.appTheme=s.theme; t.accent=s.accent; t.bgType=s.bgType; t.preset=s.preset; t.glass=s.glass; t.dim=s.dim; t.blur=s.blur; t.globalFont=s.globalFont; t.cardRadius=s.cardRadius; t.borderAlpha=s.borderAlpha; t.pressEffects=s.pressEffects; t.splashEnabled=s.splashEnabled; t.splashDuration=s.splashDuration; t.splashAnimation=s.splashAnimation; t.save(); canUndo=false; reply="Предыдущее оформление восстановлено."
        } }
        item { GButton(t, "Назад", Modifier.fillMaxWidth(), onBack) }
    }
}

private data class ThemeSnapshot(val theme: String, val accent: Int, val bgType: Int, val preset: Int, val glass: Float, val dim: Float, val blur: Float, val globalFont: String, val cardRadius: Float, val borderAlpha: Float, val pressEffects: Boolean, val splashEnabled: Boolean, val splashDuration: Int, val splashAnimation: String)
