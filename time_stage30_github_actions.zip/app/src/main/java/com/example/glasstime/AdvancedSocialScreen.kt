package com.example.glasstime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

// Stage 19: local interactions, threaded comments and an activity inbox.
data class LocalComment(val id: String, val targetId: String, val authorId: String, val parentId: String?, val body: String, val createdAt: Long)
data class LocalReaction(val targetId: String, val userId: String, val emoji: String, val createdAt: Long)
data class ActivityEvent(val id: String, val kind: String, val title: String, val detail: String, val createdAt: Long, val read: Boolean)

object InteractionStore {
    private const val PREFS = "time_interactions"
    private const val COMMENTS = "comments_v1"
    private const val REACTIONS = "reactions_v1"
    private const val EVENTS = "events_v1"

    fun comments(context: Context, targetId: String): List<LocalComment> {
        val array = read(context, COMMENTS)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val comment = runCatching {
                    LocalComment(
                        item.getString("id"), item.getString("target"), item.getString("author"),
                        item.optString("parent").takeIf { value -> value.isNotBlank() },
                        item.getString("body"), item.optLong("time")
                    )
                }.getOrNull()
                if (comment != null && comment.targetId == targetId) add(comment)
            }
        }.sortedBy { it.createdAt }
    }

    fun reactions(context: Context, targetId: String): List<LocalReaction> {
        val array = read(context, REACTIONS)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val reaction = runCatching {
                    LocalReaction(item.getString("target"), item.getString("user"), item.getString("emoji"), item.optLong("time"))
                }.getOrNull()
                if (reaction != null && reaction.targetId == targetId) add(reaction)
            }
        }
    }

    fun toggleReaction(context: Context, targetId: String, userId: String, emoji: String): List<LocalReaction> {
        require(targetId.isNotBlank() && targetId.length <= 100)
        require(emoji in setOf("♥", "🔥", "✦", "♡", "😂"))
        val all = read(context, REACTIONS)
        val existing = (0 until all.length()).firstOrNull { index ->
            val item = all.optJSONObject(index)
            item != null && item.optString("target") == targetId && item.optString("user") == userId
        } ?: -1
        if (existing >= 0 && all.optJSONObject(existing)?.optString("emoji") == emoji) all.remove(existing)
        else {
            if (existing >= 0) all.remove(existing)
            all.put(JSONObject().put("target", targetId).put("user", userId).put("emoji", emoji).put("time", System.currentTimeMillis()))
        }
        write(context, REACTIONS, all)
        log(context, "reaction", "Реакция", "$emoji · $targetId")
        return reactions(context, targetId)
    }

    fun addComment(context: Context, targetId: String, authorId: String, body: String, parentId: String? = null): Boolean {
        val clean = body.trim().take(300)
        if (clean.isBlank()) return false
        val all = read(context, COMMENTS)
        if (targetId.isBlank() || targetId.length > 100 || authorId.isBlank() || all.length() >= 2000) return false
        if (parentId != null) {
            val validParent = (0 until all.length()).any { i ->
                val parent = all.optJSONObject(i)
                parent != null && parent.optString("id") == parentId && parent.optString("target") == targetId && parent.optString("parent").isBlank()
            }
            if (!validParent) return false
        }
        all.put(JSONObject().put("id", UUID.randomUUID().toString()).put("target", targetId).put("author", authorId)
            .put("parent", parentId ?: "").put("body", clean).put("time", System.currentTimeMillis()))
        write(context, COMMENTS, all)
        log(context, if (parentId == null) "comment" else "reply", if (parentId == null) "Комментарий добавлен" else "Ответ добавлен", clean)
        return true
    }

    fun log(context: Context, kind: String, title: String, detail: String) {
        val all = read(context, EVENTS)
        all.put(JSONObject().put("id", UUID.randomUUID().toString()).put("kind", kind).put("title", title.take(80))
            .put("detail", detail.take(300)).put("time", System.currentTimeMillis()).put("read", false))
        while (all.length() > 300) all.remove(0)
        write(context, EVENTS, all)
    }

    fun events(context: Context): List<ActivityEvent> {
        val array = read(context, EVENTS)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val event = runCatching {
                    ActivityEvent(item.getString("id"), item.getString("kind"), item.getString("title"),
                        item.optString("detail"), item.optLong("time"), item.optBoolean("read"))
                }.getOrNull()
                if (event != null) add(event)
            }
        }.sortedByDescending { it.createdAt }
    }

    fun markRead(context: Context) {
        val all = read(context, EVENTS)
        for (i in 0 until all.length()) all.optJSONObject(i)?.put("read", true)
        write(context, EVENTS, all)
    }

    private fun read(context: Context, key: String) = runCatching {
        JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, "[]") ?: "[]")
    }.getOrDefault(JSONArray())
    private fun write(context: Context, key: String, value: JSONArray) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, value.toString()).apply()
    }
}

// Stage 20: user reports with status tracking. Reports stay on this device until a backend is connected.
data class LocalReport(val id: String, val target: String, val reason: String, val note: String, val status: String, val createdAt: Long)
object ReportStore {
    private const val PREFS = "time_reports"
    fun all(context: Context): List<LocalReport> = runCatching {
        val a = JSONArray(context.getSharedPreferences(PREFS, 0).getString("reports", "[]"))
        (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { LocalReport(it.optString("id"), it.optString("target"), it.optString("reason"), it.optString("note"), it.optString("status", "Новая"), it.optLong("time")) } }
    }.getOrDefault(emptyList()).sortedByDescending { it.createdAt }
    fun submit(context: Context, target: String, reason: String, note: String): Boolean {
        if (target.isBlank() || reason.isBlank()) return false
        val items = all(context).toMutableList()
        if (items.size >= 500) return false
        items.add(LocalReport(UUID.randomUUID().toString(), target.take(100), reason.take(80), note.take(500), "Новая", System.currentTimeMillis()))
        save(context, items)
        InteractionStore.log(context, "report", "Жалоба отправлена", target.take(100))
        return true
    }
    fun update(context: Context, id: String, status: String) = save(context, all(context).map { if (it.id == id) it.copy(status = status) else it })
    private fun save(context: Context, items: List<LocalReport>) {
        val a = JSONArray(); items.take(500).forEach { a.put(JSONObject().put("id", it.id).put("target", it.target).put("reason", it.reason).put("note", it.note).put("status", it.status).put("time", it.createdAt)) }
        context.getSharedPreferences(PREFS, 0).edit().putString("reports", a.toString()).apply()
    }
}

// Stage 21: local moderation controls; they are UI-side safeguards, not server authorization.
object ModerationStore {
    private const val PREFS = "time_moderation"
    fun blocked(context: Context): Set<String> = context.getSharedPreferences(PREFS, 0).getStringSet("blocked", emptySet())?.toSet() ?: emptySet()
    fun restricted(context: Context): Set<String> = context.getSharedPreferences(PREFS, 0).getStringSet("restricted", emptySet())?.toSet() ?: emptySet()
    fun toggle(context: Context, key: String, value: String): Set<String> {
        val p = context.getSharedPreferences(PREFS, 0); val set = (p.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()
        if (!set.add(value)) set.remove(value)
        p.edit().putStringSet(key, set).apply()
        InteractionStore.log(context, "moderation", "Изменены ограничения", value)
        return set
    }
}

// Stage 22: owner tools for reviewing locally stored reports and moderation lists.
// Stage 23: local multi-profile account switching. No passwords are stored by this demo.
data class LocalAccount(val id: String, val name: String, val bio: String, val accent: Int)
object AccountStore {
    private const val PREFS = "time_accounts"
    fun all(context: Context): List<LocalAccount> = runCatching {
        val a = JSONArray(context.getSharedPreferences(PREFS, 0).getString("accounts", "[]"))
        (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { LocalAccount(it.optString("id"), it.optString("name"), it.optString("bio"), it.optInt("accent", 0xFF9CCFFF.toInt())) } }
    }.getOrDefault(emptyList())
    fun current(context: Context): String = context.getSharedPreferences(PREFS, 0).getString("current", "")?.takeIf { it.isNotBlank() } ?: ProfileStore.localId(context)
    fun ensure(context: Context): List<LocalAccount> {
        val list = all(context)
        if (list.isNotEmpty()) return list
        val profile = ProfileStore.load(context); val id = ProfileStore.localId(context)
        return listOf(LocalAccount(id, profile.username, profile.bio, profile.accent)).also { save(context, it, id) }
    }
    fun save(context: Context, accounts: List<LocalAccount>, current: String = current(context)) {
        val a = JSONArray(); accounts.take(10).forEach { a.put(JSONObject().put("id", it.id).put("name", it.name.take(24)).put("bio", it.bio.take(160)).put("accent", it.accent)) }
        context.getSharedPreferences(PREFS, 0).edit().putString("accounts", a.toString()).putString("current", current).apply()
    }
    fun add(context: Context, name: String): List<LocalAccount> {
        val list = ensure(context).toMutableList(); if (name.isBlank() || list.size >= 10) return list
        val id = "local-" + UUID.randomUUID().toString().take(8)
        list.add(LocalAccount(id, name.trim().take(24), "", 0xFF9CCFFF.toInt())); save(context, list, id)
        ProfileStore.save(context, LocalProfile(username = name.trim().take(24)))
        context.getSharedPreferences("local_profile", 0).edit().putString("local_id", id).apply()
        InteractionStore.log(context, "account", "Создан локальный профиль", name)
        return list
    }
    fun switch(context: Context, id: String): List<LocalAccount> {
        val list = ensure(context); val selected = list.firstOrNull { it.id == id } ?: return list
        save(context, list, id); ProfileStore.save(context, ProfileStore.load(context).copy(username = selected.name, bio = selected.bio, accent = selected.accent))
        context.getSharedPreferences("local_profile", 0).edit().putString("local_id", id).apply()
        return list
    }
    fun updateCurrent(context: Context) {
        val id = ProfileStore.localId(context); val profile = ProfileStore.load(context)
        val list = ensure(context).map { if (it.id == id) it.copy(name = profile.username, bio = profile.bio, accent = profile.accent) else it }
        save(context, list, id)
    }
}

// Stage 24: explicit JSON backup/restore. Only allowlisted app preferences are exported.
object LocalBackupStore {
    private val names = listOf("local_profile", "local_profile_wall", "community_discussions", "local_communities", "social_graph", "time_interactions", "time_reports", "time_moderation", "time_accounts", "telegram_theme_draft", "telegram_theme_presets", "telegram_theme_wallpaper", "widget_instances", "widget_named_presets", "clock_widget_style", "navigation", "glass", "usage", "media")
    fun export(context: Context): String {
        val root = JSONObject().put("format", "time-backup").put("version", 1).put("createdAt", System.currentTimeMillis())
        val data = JSONObject()
        names.forEach { name ->
            val values = context.getSharedPreferences(name, 0).all
            val obj = JSONObject()
            values.forEach { (k, v) -> when (v) {
                is String -> obj.put(k, JSONObject().put("type", "string").put("value", v))
                is Boolean -> obj.put(k, JSONObject().put("type", "boolean").put("value", v))
                is Int -> obj.put(k, JSONObject().put("type", "int").put("value", v))
                is Long -> obj.put(k, JSONObject().put("type", "long").put("value", v))
                is Float -> obj.put(k, JSONObject().put("type", "float").put("value", v.toDouble()))
                is Set<*> -> obj.put(k, JSONObject().put("type", "set").put("value", JSONArray(v.filterIsInstance<String>())))
            } }
            data.put(name, obj)
        }
        root.put("data", data)
        return root.toString(2)
    }
    fun import(context: Context, raw: String): Boolean = runCatching {
        require(raw.length <= 5_000_000)
        val root = JSONObject(raw); require(root.optString("format") == "time-backup" && root.optInt("version") == 1)
        val data = root.getJSONObject("data")
        names.forEach { name ->
            val obj = data.optJSONObject(name) ?: return@forEach
            val editor = context.getSharedPreferences(name, 0).edit().clear()
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                when (item.optString("type")) {
                    "string" -> editor.putString(key, item.optString("value"))
                    "boolean" -> editor.putBoolean(key, item.optBoolean("value"))
                    "int" -> editor.putInt(key, item.optInt("value"))
                    "long" -> editor.putLong(key, item.optLong("value"))
                    "float" -> editor.putFloat(key, item.optDouble("value").toFloat())
                    "set" -> { val a = item.optJSONArray("value") ?: JSONArray(); editor.putStringSet(key, (0 until a.length()).map { a.optString(it) }.toSet()) }
                }
            }
            editor.apply()
        }
        true
    }.getOrDefault(false)
}

// Stage 25: repository boundary for Firebase. A real remote implementation is added only with project config.
interface SocialRepository {
    val mode: String
    suspend fun isAvailable(): Boolean
}
class LocalSocialRepository : SocialRepository {
    override val mode = "LOCAL"
    override suspend fun isAvailable() = true
}
class FirebaseSocialRepository(private val projectConfigured: Boolean) : SocialRepository {
    override val mode = if (projectConfigured) "FIREBASE_ADAPTER_PENDING" else "FIREBASE_NOT_CONFIGURED"
    override suspend fun isAvailable() = false // Replace with authenticated Firebase connectivity check after setup.
}

@Composable
fun AdvancedSocialScreen(t: ThemeState, onBack: () -> Unit) {
    var page by remember { mutableStateOf("home") }
    val context = LocalContext.current
    val ownerId = remember(context) { ProfileStore.localId(context) }
    when (page) {
        "interactions" -> InteractionsPage(t, ownerId) { page = "home" }
        "reports" -> ReportsPage(t, ownerId) { page = "home" }
        "moderation" -> ModerationPage(t) { page = "home" }
        "admin" -> AdminPage(t) { page = "home" }
        "accounts" -> AccountsPage(t) { page = "home" }
        "backup" -> BackupPage(t) { page = "home" }
        "backend" -> BackendPage(t) { page = "home" }
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { GText(t, "Социальный центр", 25, true); TextButton(onClick = onBack) { Text("Назад") } } }
            item { GText(t, "Этапы 19–25 · локальные инструменты и подготовка backend", 11, secondary = true) }
            val entries = listOf("interactions" to "Реакции, комментарии и активность", "reports" to "Жалобы и их статусы", "moderation" to "Блокировки и ограничения", "admin" to "Панель владельца", "accounts" to "Аккаунты и переключение", "backup" to "Резервная копия и перенос", "backend" to "Firebase и синхронизация")
            items(entries) { entry -> GlassCard(t) { GText(t, entry.second, 15, true); Spacer(Modifier.height(6.dp)); GButton(t, "Открыть", Modifier.fillMaxWidth()) { page = entry.first } } }
        }
    }
}

@Composable private fun InteractionsPage(t: ThemeState, userId: String, back: () -> Unit) {
    val context = LocalContext.current; var target by remember { mutableStateOf("wall-demo") }; var draft by remember { mutableStateOf("") }; var replyTo by remember { mutableStateOf<String?>(null) }; var refresh by remember { mutableIntStateOf(0) }
    val comments = remember(refresh) { InteractionStore.comments(context, target) }; val reactions = remember(refresh) { InteractionStore.reactions(context, target) }; val events = remember(refresh) { InteractionStore.events(context) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { PageHeader(t, "Взаимодействия", back) }
        item { GlassCard(t) { GText(t, "Тестовая запись", 14, true); OutlinedTextField(target, { target = it.take(100); refresh++ }, label = { Text("ID публикации") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("♡", "♥", "🔥", "✦", "😂").forEach { emoji -> GButton(t, "$emoji ${reactions.count { r -> r.emoji == emoji }}", Modifier.weight(1f)) { InteractionStore.toggleReaction(context, target, userId, emoji); refresh++ } } } } }
        item { GlassCard(t) { GText(t, "Комментарии и ответы", 14, true); OutlinedTextField(draft, { draft = it.take(300) }, label = { Text(if (replyTo == null) "Твой комментарий" else "Ответ на комментарий") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(6.dp)); GButton(t, "Отправить", Modifier.fillMaxWidth()) { if (InteractionStore.addComment(context, target, userId, draft, replyTo)) { draft = ""; replyTo = null; refresh++ } } } }
        items(comments.filter { it.parentId == null }) { comment ->
            GlassCard(t) { Text(comment.body, color = t.textColor, fontSize = 13.sp); Text("${comment.authorId} · ${comment.createdAt}", color = t.textColor.copy(alpha = .5f), fontSize = 9.sp); TextButton(onClick = { replyTo = comment.id }) { Text("Ответить") }
                comments.filter { it.parentId == comment.id }.forEach { child -> Text("↳ ${child.body}", color = t.textColor.copy(alpha = .8f), fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp)) }
            }
        }
        item { GlassCard(t) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { GText(t, "Уведомления и история", 14, true); TextButton(onClick = { InteractionStore.markRead(context); refresh++ }) { Text("Прочитать всё") } }; events.take(12).forEach { Text("• ${it.title}: ${it.detail}", color = t.textColor.copy(alpha = if (it.read) .48f else .85f), fontSize = 11.sp) } } }
    }
}

@Composable private fun ReportsPage(t: ThemeState, userId: String, back: () -> Unit) {
    val context = LocalContext.current; var target by remember { mutableStateOf("") }; var reason by remember { mutableStateOf("Спам") }; var note by remember { mutableStateOf("") }; var refresh by remember { mutableIntStateOf(0) }; var feedback by remember { mutableStateOf("") }
    val reports = remember(refresh) { ReportStore.all(context) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { PageHeader(t, "Жалобы", back) }
        item { GlassCard(t) { GText(t, "Создать жалобу", 15, true); OutlinedTextField(target, { target = it.take(100) }, label = { Text("ID публикации или пользователя") }, modifier = Modifier.fillMaxWidth()); var expanded by remember { mutableStateOf(false) }; Box { TextButton(onClick = { expanded = true }) { Text("Причина: $reason") }; DropdownMenu(expanded, { expanded = false }) { listOf("Спам", "Оскорбления", "Неприемлемый контент", "Выдача себя за другого", "Другое").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { reason = it; expanded = false }) } } }; OutlinedTextField(note, { note = it.take(500) }, label = { Text("Подробности (необязательно)") }, modifier = Modifier.fillMaxWidth()); GButton(t, "Отправить жалобу", Modifier.fillMaxWidth()) { feedback = if (ReportStore.submit(context, target, reason, note)) "Жалоба сохранена локально" else "Проверь ID и причину"; if (feedback.startsWith("Жалоба")) { target = ""; note = ""; refresh++ } }; Text(feedback, color = t.textColor.copy(alpha = .7f), fontSize = 10.sp) } }
        item { GText(t, "Мои обращения · ${reports.size}", 14, true) }
        items(reports) { r -> GlassCard(t) { GText(t, r.target, 13, true); Text("${r.reason} · ${r.status}", color = t.textColor.copy(alpha = .65f), fontSize = 11.sp); if (r.note.isNotBlank()) Text(r.note, color = t.textColor.copy(alpha = .6f), fontSize = 10.sp) } }
    }
}

@Composable private fun ModerationPage(t: ThemeState, back: () -> Unit) {
    val context = LocalContext.current; var target by remember { mutableStateOf("") }; var blocked by remember { mutableStateOf(ModerationStore.blocked(context)) }; var restricted by remember { mutableStateOf(ModerationStore.restricted(context)) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { PageHeader(t, "Модерация", back) }
        item { GlassCard(t) { GText(t, "Локальные ограничения", 14, true); OutlinedTextField(target, { target = it.take(100) }, label = { Text("ID пользователя или публикации") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(6.dp)); GButton(t, "Блокировать / разблокировать", Modifier.fillMaxWidth()) { if (target.isNotBlank()) { blocked = ModerationStore.toggle(context, "blocked", target); target = "" } }; GButton(t, "Ограничить / снять ограничение", Modifier.fillMaxWidth()) { if (target.isNotBlank()) { restricted = ModerationStore.toggle(context, "restricted", target); target = "" } } } }
        item { GlassCard(t) { GText(t, "Заблокировано (${blocked.size})", 13, true); blocked.forEach { Text("• $it", color = t.textColor, fontSize = 11.sp) }; GText(t, "Ограничено (${restricted.size})", 13, true); restricted.forEach { Text("• $it", color = t.textColor, fontSize = 11.sp) } } }
        item { Text("Эти списки действуют только внутри локального клиента. Серверная модерация должна проверять права на backend.", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp) }
    }
}

@Composable private fun AdminPage(t: ThemeState, back: () -> Unit) {
    val context = LocalContext.current; var refresh by remember { mutableIntStateOf(0) }; val reports = remember(refresh) { ReportStore.all(context) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader(t, "Панель владельца", back) }
        item { GlassCard(t) { GText(t, "Локальная сводка", 14, true); Text("Жалоб: ${reports.size} · новых: ${reports.count { it.status == "Новая" }}", color = t.textColor, fontSize = 12.sp); Text("Заблокировано: ${ModerationStore.blocked(context).size} · ограничено: ${ModerationStore.restricted(context).size}", color = t.textColor.copy(alpha = .7f), fontSize = 11.sp); Text("Владелец этого локального профиля: ${ProfileStore.localId(context)}", color = t.textColor.copy(alpha = .55f), fontSize = 9.sp) } }
        items(reports) { r -> GlassCard(t) { GText(t, "${r.target} · ${r.reason}", 13, true); if (r.note.isNotBlank()) Text(r.note, color = t.textColor.copy(alpha = .65f), fontSize = 10.sp); Text("Статус: ${r.status}", color = t.textColor.copy(alpha = .65f), fontSize = 10.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("На проверке", "Отклонена", "Решена").forEach { status -> GButton(t, status, Modifier.weight(1f)) { ReportStore.update(context, r.id, status); refresh++ } } } } }
        item { Text("Это локальная панель для проверки макета. Она не предоставляет глобальные права администратора и не управляет другими устройствами.", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp) }
    }
}

@Composable private fun AccountsPage(t: ThemeState, back: () -> Unit) {
    val context = LocalContext.current; var accounts by remember { mutableStateOf(AccountStore.ensure(context)) }; var name by remember { mutableStateOf("") }; var feedback by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { PageHeader(t, "Аккаунты", back) }
        item { GlassCard(t) { GText(t, "Локальные профили", 14, true); Text("До 10 профилей на одном устройстве. Это не облачные учётные записи; пароли не используются.", color = t.textColor.copy(alpha = .6f), fontSize = 10.sp); OutlinedTextField(name, { name = it.take(24) }, label = { Text("Имя нового профиля") }, modifier = Modifier.fillMaxWidth()); GButton(t, "Создать профиль", Modifier.fillMaxWidth()) { accounts = AccountStore.add(context, name); name = ""; feedback = "Профиль создан" }; Text(feedback, color = t.textColor.copy(alpha = .65f), fontSize = 10.sp) } }
        items(accounts) { a -> GlassCard(t) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { GText(t, a.name, 14, true); Text(a.id, color = t.textColor.copy(alpha = .5f), fontSize = 9.sp) }; if (AccountStore.current(context) == a.id) Text("Активен", color = t.accentColor, fontSize = 11.sp) else TextButton(onClick = { accounts = AccountStore.switch(context, a.id); feedback = "Активный профиль изменён" }) { Text("Переключить") } } } }
    }
}

@Composable private fun BackupPage(t: ThemeState, back: () -> Unit) {
    val context = LocalContext.current; var feedback by remember { mutableStateOf("") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(LocalBackupStore.export(context)) } ?: error("Не удалось открыть файл") }.onSuccess { feedback = "Резервная копия сохранена" }.onFailure { feedback = it.message ?: "Ошибка экспорта" } }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Не удалось прочитать файл") }.mapCatching { raw -> if (LocalBackupStore.import(context, raw)) true else error("Файл не прошёл проверку") }.onSuccess { feedback = "Данные восстановлены. Перезапусти приложение для обновления экранов." }.onFailure { feedback = it.message ?: "Ошибка импорта" } }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageHeader(t, "Резервная копия", back)
        GlassCard(t) { GText(t, "Экспорт и восстановление", 15, true); Text("Создаётся JSON-файл с настройками, локальным профилем, лентой, сообществами, аккаунтами и социальными данными. Изображения профиля и файлы фото-виджетов в эту копию не входят.", color = t.textColor.copy(alpha = .65f), fontSize = 11.sp); Spacer(Modifier.height(8.dp)); GButton(t, "Экспортировать .json", Modifier.fillMaxWidth()) { export.launch("time-backup.json") }; GButton(t, "Импортировать .json", Modifier.fillMaxWidth()) { import.launch(arrayOf("application/json", "text/*")) }; Text("Перед импортом рекомендуется сохранить текущую копию: импорт заменяет соответствующие локальные разделы.", color = t.textColor.copy(alpha = .55f), fontSize = 10.sp); Text(feedback, color = t.accentColor, fontSize = 11.sp) }
    }
}

@Composable private fun BackendPage(t: ThemeState, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageHeader(t, "Firebase и синхронизация", back)
        GlassCard(t) {
            GText(t, "Статус подключения", 15, true)
            Text("Локальный режим активен", color = t.accentColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("Firebase-проект не настроен. Поэтому вход по email/passkey, облачные профили, push-уведомления и синхронизация между устройствами пока не выполняются.", color = t.textColor.copy(alpha = .68f), fontSize = 11.sp)
            Spacer(Modifier.height(8.dp)); GText(t, "Подготовленная структура", 13, true)
            listOf("SocialRepository — единая граница данных", "LocalSocialRepository — текущая локальная реализация", "FirebaseSocialRepository — точка подключения удалённого слоя", "Правила доступа, роли и модерацию нужно проверять на сервере", "Секреты и ключи администратора нельзя хранить в APK").forEach { Text("• $it", color = t.textColor.copy(alpha = .75f), fontSize = 11.sp) }
        }
        GlassCard(t) { GText(t, "Что понадобится для реального запуска", 13, true); Text("Создать Firebase project, добавить Android-приложение с package com.example.glasstime, положить google-services.json в app/, включить Authentication и Firestore, затем добавить Gradle-плагины и серверные Security Rules. После этого можно заменить локальный репозиторий на Firebase.", color = t.textColor.copy(alpha = .68f), fontSize = 11.sp) }
    }
}

@Composable private fun PageHeader(t: ThemeState, title: String, back: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { GText(t, title, 23, true); TextButton(onClick = back) { Text("Назад") } }
}
