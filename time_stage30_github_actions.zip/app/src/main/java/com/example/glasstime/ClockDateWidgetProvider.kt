package com.example.glasstime

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.text.format.DateFormat
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockDateWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context, manager)
        scheduleMinuteRefresh(context)
    }

    override fun onEnabled(context: Context) {
        scheduleMinuteRefresh(context)
    }

    override fun onDisabled(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(refreshPendingIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_BOOT_COMPLETED -> {
                updateAll(context, AppWidgetManager.getInstance(context))
                if (intent.action == Intent.ACTION_BOOT_COMPLETED) scheduleMinuteRefresh(context)
            }
        }
    }

    companion object {
        private const val ACTION_REFRESH = "com.example.glasstime.CLOCK_WIDGET_REFRESH"
        private const val REFRESH_INTERVAL = 30_000L

        private fun refreshPendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, ClockDateWidgetProvider::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(
                context, 4102, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleMinuteRefresh(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val now = System.currentTimeMillis()
            val nextRefresh = now - (now % REFRESH_INTERVAL) + REFRESH_INTERVAL
            alarm.setRepeating(
                AlarmManager.RTC, nextRefresh, REFRESH_INTERVAL, refreshPendingIntent(context)
            )
        }

        fun updateAll(context: Context, manager: AppWidgetManager = AppWidgetManager.getInstance(context)) {
            val component = ComponentName(context, ClockDateWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return
            val is24 = DateFormat.is24HourFormat(context)
            val timePattern = if (is24) "HH:mm" else "h:mm"
            val datePattern = "EEEE, d MMMM"
            val locale = Locale.getDefault()
            val now = Date()
            val time = SimpleDateFormat(timePattern, locale).format(now)
            val date = SimpleDateFormat(datePattern, locale).format(now)
            val timeIds = listOf(R.id.widget_clock_time_sans, R.id.widget_clock_time_serif, R.id.widget_clock_time_mono)
            val dateIds = listOf(R.id.widget_clock_date_sans, R.id.widget_clock_date_serif, R.id.widget_clock_date_mono)
            ids.forEach { widgetId ->
                val style = ClockWidgetStyleStore.load(context, widgetId)
                val selectedFont = when (style.font) { "serif" -> 1; "mono" -> 2; else -> 0 }
                val dateColor = Color.argb(180, Color.red(style.textColor), Color.green(style.textColor), Color.blue(style.textColor))
                val views = RemoteViews(context.packageName, R.layout.widget_clock_date).apply {
                    timeIds.forEachIndexed { index, id ->
                        setTextViewText(id, time)
                        setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, style.timeSize)
                        setTextColor(id, style.textColor)
                        setViewVisibility(id, if (index == selectedFont) View.VISIBLE else View.GONE)
                    }
                    dateIds.forEachIndexed { index, id ->
                        setTextViewText(id, date)
                        setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, style.dateSize)
                        setTextColor(id, dateColor)
                        setViewVisibility(id, if (index == selectedFont) View.VISIBLE else View.GONE)
                    }
                    setInt(R.id.widget_clock_panel, "setColorFilter", style.panelColor)
                    setInt(R.id.widget_clock_panel, "setImageAlpha", style.panelAlpha)
                    setOnClickPendingIntent(R.id.widget_clock_root, openAppIntent(context, 4103 + widgetId))
                }
                manager.updateAppWidget(widgetId, views)
            }
        }
    }
}

class NowPlayingWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = updateAll(context, manager)

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_MEDIA_UPDATE) updateAll(context, AppWidgetManager.getInstance(context))
    }

    companion object {
        const val ACTION_MEDIA_UPDATE = "com.example.glasstime.MEDIA_WIDGET_UPDATE"

        fun updateAll(context: Context, manager: AppWidgetManager = AppWidgetManager.getInstance(context)) {
            val component = ComponentName(context, NowPlayingWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return
            val current = MediaLog.nowPlaying(context).firstOrNull()
            val views = RemoteViews(context.packageName, R.layout.widget_now_playing).apply {
                setTextViewText(R.id.widget_music_title, current?.title?.takeIf { it.isNotBlank() } ?: "Сейчас ничего не играет")
                setTextViewText(R.id.widget_music_artist, current?.artist?.takeIf { it.isNotBlank() } ?: "Открой time个 и включи доступ к уведомлениям")
                setTextViewText(R.id.widget_music_status, if (current != null) "NOW PLAYING" else "MUSIC STATUS")
                setOnClickPendingIntent(R.id.widget_music_root, openAppIntent(context, 4104))
            }
            manager.updateAppWidget(ids, views)
        }
    }
}

private fun openAppIntent(context: Context, requestCode: Int): PendingIntent {
    val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        ?: Intent(context, MainActivity::class.java)
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    return PendingIntent.getActivity(
        context, requestCode, launch,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
