package com.example.glasstime

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.text.format.DateFormat
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockDateWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context, manager)
        scheduleMinuteRefresh(context)
    }

    override fun onEnabled(context: Context) {
        scheduleMinuteRefresh(context)
    }

    override fun onDisabled(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(refreshPendingIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_BOOT_COMPLETED -> {
                updateAll(context, AppWidgetManager.getInstance(context))
                if (intent.action == Intent.ACTION_BOOT_COMPLETED) scheduleMinuteRefresh(context)
            }
        }
    }

    companion object {
        private const val ACTION_REFRESH = "com.example.glasstime.CLOCK_WIDGET_REFRESH"
        private const val REFRESH_INTERVAL = 30_000L

        private fun refreshPendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, ClockDateWidgetProvider::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(
                context, 4102, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleMinuteRefresh(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val now = System.currentTimeMillis()
            val nextRefresh = now - (now % REFRESH_INTERVAL) + REFRESH_INTERVAL
            alarm.setRepeating(
                AlarmManager.RTC, nextRefresh, REFRESH_INTERVAL, refreshPendingIntent(context)
            )
        }

        fun updateAll(context: Context, manager: AppWidgetManager = AppWidgetManager.getInstance(context)) {
            val component = ComponentName(context, ClockDateWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return
            val is24 = DateFormat.is24HourFormat(context)
            val timePattern = if (is24) "HH:mm" else "h:mm"
            val datePattern = "EEEE, d MMMM"
            val locale = Locale.getDefault()
            val now = Date()
            val time = SimpleDateFormat(timePattern, locale).format(now)
            val date = SimpleDateFormat(datePattern, locale).format(now)
            val timeIds = listOf(R.id.widget_clock_time_sans, R.id.widget_clock_time_serif, R.id.widget_clock_time_mono)
            val dateIds = listOf(R.id.widget_clock_date_sans, R.id.widget_clock_date_serif, R.id.widget_clock_date_mono)
            ids.forEach { widgetId ->
                val style = ClockWidgetStyleStore.load(context, widgetId)
                val selectedFont = when (style.font) { "serif" -> 1; "mono" -> 2; else -> 0 }
                val dateColor = Color.argb(180, Color.red(style.textColor), Color.green(style.textColor), Color.blue(style.textColor))
                val horizontalGravity = when (style.horizontalAlignment) { "center" -> Gravity.CENTER_HORIZONTAL; "end" -> Gravity.END; else -> Gravity.START }
                val verticalGravity = when (style.verticalAlignment) { "top" -> Gravity.TOP; "bottom" -> Gravity.BOTTOM; else -> Gravity.CENTER_VERTICAL }
                val views = RemoteViews(context.packageName, R.layout.widget_clock_date).apply {
                    timeIds.forEachIndexed { index, id ->
                        setTextViewText(id, time)
                        setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, style.timeSize)
                        setTextColor(id, style.textColor)
                        setViewVisibility(id, if (index == selectedFont) View.VISIBLE else View.GONE)
                    }
                    dateIds.forEachIndexed { index, id ->
                        setTextViewText(id, date)
                        setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, style.dateSize)
                        setTextColor(id, dateColor)
                        setViewVisibility(id, if (style.showDate && index == selectedFont) View.VISIBLE else View.GONE)
                    }
                    setInt(R.id.widget_clock_content, "setGravity", horizontalGravity or verticalGravity)
                    setTextViewText(R.id.widget_clock_custom_text, style.customText)
                    setTextColor(R.id.widget_clock_custom_text, dateColor)
                    setViewVisibility(R.id.widget_clock_custom_text, if (style.showCustomText && style.customText.isNotBlank()) View.VISIBLE else View.GONE)
                    setInt(R.id.widget_clock_panel, "setColorFilter", style.panelColor)
                    setInt(R.id.widget_clock_panel, "setImageAlpha", style.panelAlpha)
                    setOnClickPendingIntent(R.id.widget_clock_root, openAppIntent(context, 4103 + widgetId))
                }
                manager.updateAppWidget(widgetId, views)
            }
        }
    }
}

class NowPlayingWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        updateWidget(context, manager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_MEDIA_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, NowPlayingWidgetProvider::class.java))
                .forEach { updateWidget(context, manager, it) }
        }
    }

    companion object {
        const val ACTION_MEDIA_UPDATE = "com.example.glasstime.MEDIA_WIDGET_UPDATE"

        private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val options = manager.getAppWidgetOptions(widgetId)
            val minWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            val minHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)
            // Switch to a stacked layout when the launcher resizes the widget into portrait.
            val style = MusicWidgetStyleStore.load(context)
            val vertical = when (style.layoutMode) {
                "vertical" -> true
                "horizontal" -> false
                else -> minHeight > minWidth
            }
            val layout = if (vertical) R.layout.widget_now_playing else R.layout.widget_now_playing_horizontal
            val current = MediaLog.nowPlaying(context).firstOrNull()
            val views = RemoteViews(context.packageName, layout).apply {
                setTextViewText(R.id.widget_music_title, current?.title?.takeIf { it.isNotBlank() } ?: "Сейчас ничего не играет")
                setTextViewText(R.id.widget_music_artist, current?.artist?.takeIf { it.isNotBlank() } ?: "Включи музыку и доступ к уведомлениям")
                setTextViewText(R.id.widget_music_status, if (current != null) "NOW PLAYING" else "MUSIC STATUS")
                setTextColor(R.id.widget_music_title, style.textColor)
                setTextColor(R.id.widget_music_artist, style.secondaryTextColor)
                setTextColor(R.id.widget_music_status, style.secondaryTextColor)
                setTextViewTextSize(R.id.widget_music_title, android.util.TypedValue.COMPLEX_UNIT_SP, style.titleSize)
                setTextViewTextSize(R.id.widget_music_artist, android.util.TypedValue.COMPLEX_UNIT_SP, style.artistSize)
                setViewPadding(R.id.widget_music_content, style.padding, style.padding, style.padding, style.padding)
                setViewVisibility(R.id.widget_music_status, if (style.showStatus) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.widget_music_art, if (style.showArtwork) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.widget_music_controls, if (style.showControls) View.VISIBLE else View.GONE)
                setViewLayoutWidth(R.id.widget_music_art, style.artworkSize)
                setViewLayoutHeight(R.id.widget_music_art, style.artworkSize)
                setInt(R.id.widget_music_root, "setBackgroundColor", style.backgroundColor)
                setImageViewBitmap(R.id.widget_music_background, MusicWidgetStyleStore.renderedBackground(context, style))
                val art = MusicWidgetStyleStore.artworkBitmap(context)
                if (art != null && style.showArtwork) setImageViewBitmap(R.id.widget_music_art, art)
                setOnClickPendingIntent(R.id.widget_music_root, openAppIntent(context, 4104 + widgetId))
                setOnClickPendingIntent(R.id.widget_music_previous, musicAction(context, MediaTrackerService.ACTION_PREVIOUS, 4200 + widgetId))
                setOnClickPendingIntent(R.id.widget_music_play, musicAction(context, MediaTrackerService.ACTION_PLAY_PAUSE, 4300 + widgetId))
                setOnClickPendingIntent(R.id.widget_music_next, musicAction(context, MediaTrackerService.ACTION_NEXT, 4400 + widgetId))
            }
            manager.updateAppWidget(widgetId, views)
        }

        fun updateAll(context: Context, manager: AppWidgetManager = AppWidgetManager.getInstance(context)) {
            val component = ComponentName(context, NowPlayingWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { updateWidget(context, manager, it) }
        }
    }
}

private fun musicAction(context: Context, action: String, requestCode: Int): PendingIntent {
    val intent = Intent(context, MusicWidgetControlReceiver::class.java).setAction(action)
    return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}

private fun openAppIntent(context: Context, requestCode: Int): PendingIntent {
    val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        ?: Intent(context, MainActivity::class.java)
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    return PendingIntent.getActivity(
        context, requestCode, launch,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
