package com.example.glasstime.domain.model

data class AppTab(
    val id: Int,
    val title: String,
    val shortTitle: String,
    val symbol: String
)

object AppTabs {
    val all = listOf(
        AppTab(0, "Экранное время", "Экран", "◷"),
        AppTab(1, "Плееры", "Плееры", "♫"),
        AppTab(2, "Виджеты", "Виджеты", "▦"),
        AppTab(3, "Темы Telegram", "TG темы", "◈"),
        AppTab(4, "Настройки", "Настройки", "⚙"),
        AppTab(5, "Профиль", "Профиль", "◉")
    )
}
