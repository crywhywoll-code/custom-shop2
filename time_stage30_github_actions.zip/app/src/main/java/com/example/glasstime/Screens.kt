package com.example.glasstime

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AppRow(t: ThemeState, icon: ImageBitmap?, label: String, ms: Long, frac: Float) {
    Row(
        modifier = Modifier.fillMaxWidth().glass(t, 24.dp).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Image(
                bitmap = icon,
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
            )
        } else {
            Spacer(Modifier.size(42.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            GText(t, label, 15, true)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.18f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(frac.coerceIn(0.02f, 1f))
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(t.accentColor)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        GText(t, fmt(ms), 13, secondary = true)
    }
}

@Composable
fun UsageScreen(t: ThemeState) {
    val ctx = LocalContext.current
    var range by remember { mutableIntStateOf(1) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            tick++
        }
    }
    val has = remember(tick) { UsageData.hasAccess(ctx) }
    var apps by remember { mutableStateOf<List<AppUsage>>(emptyList()) }
    LaunchedEffect(range, has, tick / 5) {
        if (has) apps = withContext(Dispatchers.IO) { UsageData.load(ctx, range) }
    }
    var total = 0L
    var max = 1L
    for (a in apps) {
        total += a.millis
        if (a.millis > max) max = a.millis
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Экранное время", 30, true) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GChip(t, "Сегодня", range == 1) { range = 1 }
                GChip(t, "7 дней", range == 7) { range = 7 }
                GChip(t, "Всё время", range == 0) { range = 0 }
            }
        }
        if (!has) {
            item {
                GlassCard(t) {
                    GText(t, "Нужен доступ к статистике использования", 16, true)
                    Spacer(Modifier.height(6.dp))
                    GText(t, "Откроются настройки. Найди Glass Time в списке и включи доступ.", 14, secondary = true)
                    Spacer(Modifier.height(12.dp))
                    GButton(t, "Открыть настройки") {
                        ctx.startActivity(
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        } else {
            item {
                GlassCard(t) {
                    GText(t, if (range == 1) "Сегодня всего" else if (range == 7) "За 7 дней всего" else "За всё время", 14, secondary = true)
                    GText(t, fmt(total), 34, true)
                }
            }
            items(apps, key = { it.pkg }) { a ->
                AppRow(t, a.icon, a.label, a.millis, a.millis.toFloat() / max.toFloat())
            }
        }
    }
}

@Composable
fun PlayerScreen(t: ThemeState) {
    val ctx = LocalContext.current
    var range by remember { mutableIntStateOf(1) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            tick++
        }
    }
    val enabled = remember(tick) { try { MediaLog.listenerEnabled(ctx) } catch (e: Exception) { false } }
    val rows = remember(tick, range) { try { MediaLog.rows(ctx, range) } catch (e: Exception) { emptyList<MediaRow>() } }
    val now = remember(tick) { try { MediaLog.nowPlaying(ctx) } catch (e: Exception) { emptyList<NowPlaying>() } }
    var max = 1L
    for (r in rows) if (r.millis > max) max = r.millis

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Плееры", 30, true) }
        if (!enabled) {
            item {
                GlassCard(t) {
                    GText(t, "Нужен доступ к уведомлениям", 16, true)
                    Spacer(Modifier.height(6.dp))
                    GText(
                        t,
                        "Так приложение видит, что сейчас играет, и считает время. Если вкл. недоступно, открой информацию о приложении, нажми три точки и разреши ограниченные настройки.",
                        14,
                        secondary = true
                    )
                    Spacer(Modifier.height(12.dp))
                    GButton(t, "Открыть настройки") {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        } else {
            if (now.isNotEmpty()) {
                items(now, key = { "now:" + it.pkg }) { n ->
                    GlassCard(t) {
                        GText(t, "Сейчас играет · " + AppInfo.label(ctx, n.pkg), 13, secondary = true)
                        GText(t, if (n.title.isEmpty()) "Без названия" else n.title, 20, true)
                        if (n.artist.isNotEmpty()) GText(t, n.artist, 14, secondary = true)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GChip(t, "Сегодня", range == 1) { range = 1 }
                    GChip(t, "7 дней", range == 7) { range = 7 }
                    GChip(t, "Всё время", range == 0) { range = 0 }
                }
            }
            if (rows.isEmpty()) {
                item { GText(t, "Пока ничего не играло. Включи музыку или видео.", 14, secondary = true) }
            }
            items(rows, key = { "row:" + it.pkg }) { r ->
                AppRow(t, r.icon, r.label, r.millis, r.millis.toFloat() / max.toFloat())
            }
        }
    }
}

@Composable
fun SliderRow(t: ThemeState, label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    GText(t, label, 14, secondary = true)
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = t.accentColor,
            activeTrackColor = t.accentColor,
            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
        )
    )
}

@Composable
fun StyleScreen(t: ThemeState) {
    var showAssistant by remember { mutableStateOf(false) }
    if (showAssistant) { AssistantScreen(t) { showAssistant = false }; return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { PhotoStore.save(ctx, uri) }
                if (ok) {
                    t.photo = withContext(Dispatchers.IO) { PhotoStore.load(ctx) }
                    t.bgType = 1
                    t.save()
                }
            }
        }
    }
    val navBlockPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { PhotoStore.saveBlock(ctx, uri, "nav") }
            if (ok) { t.navBlockPhoto = withContext(Dispatchers.IO) { PhotoStore.loadBlock(ctx, "nav") }; t.navBlockMode = "photo"; t.save() }
        }
    }
    val cardBlockPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { PhotoStore.saveBlock(ctx, uri, "card") }
            if (ok) { t.cardBlockPhoto = withContext(Dispatchers.IO) { PhotoStore.loadBlock(ctx, "card") }; t.cardBlockMode = "photo"; t.save() }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { GText(t, "Настройки", 30, true) }
        item { GlassCard(t) { GText(t, "Помощник оформления", 15, true); GText(t, "Опиши нужный стиль — ассистент предложит изменение и дождётся подтверждения.", 12, secondary = true); GButton(t, "Открыть AI-ассистент", Modifier.fillMaxWidth()) { showAssistant = true } } }
        item {
            GlassCard(t) {
                GText(t, "Темы приложения", 16, true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Glass", "AMOLED", "Standard").forEach { themeName ->
                        GChip(t, themeName, t.appTheme == themeName) {
                            t.appTheme = themeName
                            t.save()
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                GText(t, "Выбор сохраняется на устройстве и применяется ко всем текущим экранам.", 12, secondary = true)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фон", 16, true)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Presets.forEachIndexed { i, p ->
                        val selected = t.bgType == 0 && t.preset == i
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(p.colors))
                                .border(if (selected) 3.dp else 1.dp, Color.White.copy(alpha = if (selected) 1f else 0.5f), CircleShape)
                                .clickable {
                                    t.preset = i
                                    t.bgType = 0
                                    t.save()
                                }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GButton(t, "Своё фото") {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    if (t.bgType == 1) {
                        GButton(t, "Убрать фото") {
                            t.bgType = 0
                            t.save()
                        }
                    }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Фоны внутри блоков", 16, true)
                GText(t, "Настраивается отдельно для самой нижней панели и для карточек. Фото размещается внутри формы блока, а не на всём экране.", 12, secondary = true)
                Spacer(Modifier.height(10.dp))
                GText(t, "Нижняя панель", 14, true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("glass" to "Стекло", "solid" to "Цвет", "photo" to "Фото").forEach { (mode, label) ->
                        GChip(t, label, t.navBlockMode == mode) { t.navBlockMode = mode; t.save() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton(t, "Выбрать фото панели") { navBlockPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    GButton(t, "Сбросить") { t.navBlockMode = "glass"; t.save() }
                }
                Spacer(Modifier.height(8.dp))
                GText(t, "Карточки и панели контента", 14, true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("glass" to "Стекло", "solid" to "Цвет", "photo" to "Фото").forEach { (mode, label) ->
                        GChip(t, label, t.cardBlockMode == mode) { t.cardBlockMode = mode; t.save() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton(t, "Выбрать фото карточек") { cardBlockPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    GButton(t, "Сбросить") { t.cardBlockMode = "glass"; t.save() }
                }
                if (t.navBlockMode == "solid" || t.cardBlockMode == "solid") {
                    GText(t, "Цвет заливки", 13, secondary = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0xFF101114.toInt(), 0xFF292D35.toInt(), 0xFF4A3038.toInt(), 0xFF263B43.toInt(), 0xFFF0F0F0.toInt()).forEach { color ->
                            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(color)).border(1.dp, Color.White.copy(alpha = .5f), CircleShape).clickable { if (t.navBlockMode == "solid") t.navBlockColor = color; if (t.cardBlockMode == "solid") t.cardBlockColor = color; t.save() })
                        }
                    }
                }
                SliderRow(t, "Подложка фото / контраст текста", t.blockPhotoDim, 0f..0.75f) { t.blockPhotoDim = it; t.save() }
                GText(t, "При фото текст автоматически выбирает светлую или тёмную сторону в зависимости от настроек темы; подложка помогает сохранить читаемость.", 11, secondary = true)
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Стекло", 16, true)
                SliderRow(t, "Размытие фото (Android 12+)", t.blur, 0f..40f) { t.blur = it; t.save() }
                SliderRow(t, "Прозрачность стекла", t.glass, 0.04f..0.5f) { t.glass = it; t.save() }
                SliderRow(t, "Затемнение фона", t.dim, 0f..0.6f) { t.dim = it; t.save() }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Цвета", 16, true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Accents.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(if (t.accent == i) 3.dp else 1.dp, Color.White.copy(alpha = if (t.accent == i) 1f else 0.5f), CircleShape)
                                .clickable {
                                    t.accent = i
                                    t.save()
                                }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GText(t, "Тёмный текст", 15, modifier = Modifier.weight(1f))
                    Switch(checked = t.darkText, onCheckedChange = { t.darkText = it; t.save() })
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Глобальная типографика", 16, true)
                GText(t, "Единый шрифт для экранов, профилей, ленты и сообществ.", 12, secondary = true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Sans", "Serif", "Mono", "Cursive").forEach { f -> GChip(t, f, t.globalFont == f) { t.globalFont = f; t.save() } }
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Форма и эффекты", 16, true)
                SliderRow(t, "Скругление карточек", t.cardRadius, 8f..36f) { t.cardRadius = it; t.save() }
                SliderRow(t, "Прозрачность границ", t.borderAlpha, 0.05f..0.9f) { t.borderAlpha = it; t.save() }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GText(t, "Эффекты нажатия", 14, modifier = Modifier.weight(1f))
                    Switch(checked = t.pressEffects, onCheckedChange = { t.pressEffects = it; t.save() })
                }
            }
        }
        item {
            GlassCard(t) {
                GText(t, "Splash Studio", 16, true)
                GText(t, "Фиксированная надпись: time个 · by kodokuzawa. Настраивается только фон, анимация и длительность.", 12, secondary = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GText(t, "Показывать заставку", 14, modifier = Modifier.weight(1f))
                    Switch(checked = t.splashEnabled, onCheckedChange = { t.splashEnabled = it; t.save() })
                }
                GText(t, "Анимация", 13, secondary = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Fade", "Scale", "Slide").forEach { a -> GChip(t, a, t.splashAnimation == a) { t.splashAnimation = a; t.save() } }
                }
                SliderRow(t, "Время показа (мс)", t.splashDuration.toFloat(), 500f..4000f) { t.splashDuration = it.toInt(); t.save() }
            }
        }
        item { GButton(t, "Сбросить стиль") { t.reset() } }
    }
}
