package com.example.glasstime

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class PhotoWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context, manager)
    }

    companion object {
        fun updateAll(context: Context, manager: AppWidgetManager = AppWidgetManager.getInstance(context)) {
            val component = ComponentName(context, PhotoWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            ids.forEach { widgetId ->
                val bitmap = WidgetInstanceStore.croppedBitmap(context, widgetId)
                val views = RemoteViews(context.packageName, R.layout.widget_photo).apply {
                    if (bitmap != null) {
                        setImageViewBitmap(R.id.widget_photo_image, bitmap)
                        setViewVisibility(R.id.widget_photo_hint, android.view.View.GONE)
                    } else {
                        setViewVisibility(R.id.widget_photo_hint, android.view.View.VISIBLE)
                    }
                    val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                        ?: Intent(context, MainActivity::class.java)
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    setOnClickPendingIntent(
                        R.id.widget_photo_root,
                        PendingIntent.getActivity(context, 5100 + widgetId, launch,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    )
                }
                manager.updateAppWidget(widgetId, views)
                bitmap?.recycle()
            }
        }
    }
}
