package com.example.glasstime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.io.File

/** Per-AppWidgetId settings. Each placed widget can have its own style and photo crop. */
object WidgetInstanceStore {
    data class PhotoCrop(val zoom: Float = 1f, val x: Float = 0f, val y: Float = 0f, val cornerRadius: Float = 24f)

    private const val PREFS = "widget_instances"

    fun photoFile(context: Context, widgetId: Int?): File = File(
        context.filesDir,
        if (widgetId == null || widgetId == AppWidgetManagerIds.NONE) WidgetPresetManager.PHOTO_FILE
        else "widget_photo_$widgetId.jpg"
    )

    fun saveCrop(context: Context, widgetId: Int?, crop: PhotoCrop) {
        val key = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.toString() ?: "default"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("zoom_$key", crop.zoom.coerceIn(1f, 2.5f))
            .putFloat("x_$key", crop.x.coerceIn(-1f, 1f))
            .putFloat("y_$key", crop.y.coerceIn(-1f, 1f))
            .putFloat("radius_$key", crop.cornerRadius.coerceIn(0f, 48f))
            .apply()
    }

    fun loadCrop(context: Context, widgetId: Int?): PhotoCrop {
        val key = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.toString() ?: "default"
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return PhotoCrop(
            zoom = p.getFloat("zoom_$key", 1f).coerceIn(1f, 2.5f),
            x = p.getFloat("x_$key", 0f).coerceIn(-1f, 1f),
            y = p.getFloat("y_$key", 0f).coerceIn(-1f, 1f),
            cornerRadius = p.getFloat("radius_$key", 24f).coerceIn(0f, 48f)
        )
    }

    fun croppedBitmap(context: Context, widgetId: Int?): Bitmap? {
        val file = photoFile(context, widgetId).takeIf { it.exists() }
            ?: photoFile(context, null).takeIf { it.exists() }
            ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 700 || bounds.outHeight / sample > 700) sample *= 2
        val source = BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return null
        val output = Bitmap.createBitmap(480, 480, Bitmap.Config.ARGB_8888)
        val crop = loadCrop(context, widgetId)
        val canvas = Canvas(output)
        val scale = (480f / minOf(source.width, source.height)) * crop.zoom
        val dx = (480f - source.width * scale) / 2f + crop.x * 150f
        val dy = (480f - source.height * scale) / 2f + crop.y * 150f
        val matrix = Matrix().apply { setScale(scale, scale); postTranslate(dx, dy) }
        val save = canvas.save()
        val radius = crop.cornerRadius.coerceIn(0f, 48f) * 10f
        val path = Path().apply { addRoundRect(RectF(0f, 0f, 480f, 480f), radius, radius, Path.Direction.CW) }
        canvas.clipPath(path)
        canvas.drawBitmap(source, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        canvas.restoreToCount(save)
        source.recycle()
        return output
    }
}

/** Sentinel kept separate to avoid treating Android's valid widget id 0 as a default. */
object AppWidgetManagerIds { const val NONE = -1 }
