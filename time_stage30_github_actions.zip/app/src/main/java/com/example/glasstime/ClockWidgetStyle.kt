package com.example.glasstime

import android.content.Context

/** Appearance settings for a clock/date widget. */
data class ClockWidgetStyle(
    val timeSize: Float = 42f,
    val dateSize: Float = 13f,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val panelColor: Int = 0xFF252B33.toInt(),
    val panelAlpha: Int = 220,
    val font: String = "sans"
)

object ClockWidgetStyleStore {
    private const val PREFS = "clock_widget_style"

    fun load(context: Context, widgetId: Int? = null): ClockWidgetStyle {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val prefix = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.let { "widget_${it}_" } ?: ""
        fun float(key: String, default: Float) = p.getFloat(prefix + key, p.getFloat(key, default))
        fun int(key: String, default: Int) = p.getInt(prefix + key, p.getInt(key, default))
        fun string(key: String, default: String) = p.getString(prefix + key, p.getString(key, default)) ?: default
        return ClockWidgetStyle(
            timeSize = float("time_size", 42f), dateSize = float("date_size", 13f),
            textColor = int("text_color", 0xFFFFFFFF.toInt()),
            panelColor = int("panel_color", 0xFF252B33.toInt()),
            panelAlpha = int("panel_alpha", 220), font = string("font", "sans")
        )
    }

    fun save(context: Context, style: ClockWidgetStyle, widgetId: Int? = null) {
        val prefix = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.let { "widget_${it}_" } ?: ""
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(prefix + "time_size", style.timeSize.coerceIn(28f, 60f))
            .putFloat(prefix + "date_size", style.dateSize.coerceIn(10f, 20f))
            .putInt(prefix + "text_color", style.textColor)
            .putInt(prefix + "panel_color", style.panelColor)
            .putInt(prefix + "panel_alpha", style.panelAlpha.coerceIn(80, 255))
            .putString(prefix + "font", style.font)
            .apply()
    }
}
