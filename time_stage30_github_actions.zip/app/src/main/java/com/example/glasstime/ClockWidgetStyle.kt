package com.example.glasstime

import android.content.Context

/** Appearance settings for a clock/date widget. */
data class ClockWidgetStyle(
    val timeSize: Float = 42f,
    val dateSize: Float = 13f,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val panelColor: Int = 0xFF252B33.toInt(),
    val panelAlpha: Int = 220,
    val font: String = "sans",
    val horizontalAlignment: String = "start",
    val verticalAlignment: String = "center",
    val showDate: Boolean = true,
    val customText: String = "",
    val showCustomText: Boolean = false
)

object ClockWidgetStyleStore {
    private const val PREFS = "clock_widget_style"

    fun load(context: Context, widgetId: Int? = null): ClockWidgetStyle {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val prefix = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.let { "widget_${it}_" } ?: ""
        fun float(key: String, default: Float) = p.getFloat(prefix + key, p.getFloat(key, default))
        fun int(key: String, default: Int) = p.getInt(prefix + key, p.getInt(key, default))
        fun string(key: String, default: String) = p.getString(prefix + key, p.getString(key, default)) ?: default
        return ClockWidgetStyle(
            timeSize = float("time_size", 42f), dateSize = float("date_size", 13f),
            textColor = int("text_color", 0xFFFFFFFF.toInt()),
            panelColor = int("panel_color", 0xFF252B33.toInt()),
            panelAlpha = int("panel_alpha", 220), font = string("font", "sans"),
            horizontalAlignment = string("horizontal_alignment", "start"),
            verticalAlignment = string("vertical_alignment", "center"),
            showDate = p.getBoolean(prefix + "show_date", p.getBoolean("show_date", true)),
            customText = string("custom_text", "").take(48),
            showCustomText = p.getBoolean(prefix + "show_custom_text", p.getBoolean("show_custom_text", false))
        )
    }

    fun save(context: Context, style: ClockWidgetStyle, widgetId: Int? = null) {
        val prefix = widgetId?.takeIf { it != AppWidgetManagerIds.NONE }?.let { "widget_${it}_" } ?: ""
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(prefix + "time_size", style.timeSize.coerceIn(28f, 60f))
            .putFloat(prefix + "date_size", style.dateSize.coerceIn(10f, 20f))
            .putInt(prefix + "text_color", style.textColor)
            .putInt(prefix + "panel_color", style.panelColor)
            .putInt(prefix + "panel_alpha", style.panelAlpha.coerceIn(80, 255))
            .putString(prefix + "font", style.font)
            .putString(prefix + "horizontal_alignment", style.horizontalAlignment.takeIf { it in setOf("start", "center", "end") } ?: "start")
            .putString(prefix + "vertical_alignment", style.verticalAlignment.takeIf { it in setOf("top", "center", "bottom") } ?: "center")
            .putBoolean(prefix + "show_date", style.showDate)
            .putString(prefix + "custom_text", style.customText.take(48))
            .putBoolean(prefix + "show_custom_text", style.showCustomText)
            .apply()
    }
}
