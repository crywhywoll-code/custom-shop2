package com.example.glasstime

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import com.example.glasstime.domain.model.AppTabs
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun Modifier.glass(t: ThemeState, radius: Dp = 28.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return when (t.appTheme) {
        "AMOLED" -> this.clip(shape)
            .background(Color(0xFF101010))
            .border(1.dp, Color(0xFF292929).copy(alpha = t.borderAlpha), shape)
        "Standard" -> this.clip(shape)
            .background(Color(0xFFFFFFFF))
            .border(1.dp, Color(0xFFE1E3E6).copy(alpha = t.borderAlpha), shape)
        else -> {
            val a = t.glass
            this.clip(shape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = (a + 0.14f).coerceAtMost(0.85f)),
                            Color.White.copy(alpha = (a * 0.6f).coerceAtMost(0.85f))
                        )
                    )
                )
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = t.borderAlpha),
                            Color.White.copy(alpha = t.borderAlpha * 0.25f),
                            Color.White.copy(alpha = t.borderAlpha * 0.7f)
                        )
                    ),
                    shape
                )
        }
    }
}

@Composable
fun Background(t: ThemeState) {
    Box(Modifier.fillMaxSize()) {
        if (t.appTheme == "AMOLED") {
            Box(Modifier.fillMaxSize().background(Color.Black))
        } else if (t.appTheme == "Standard") {
            Box(Modifier.fillMaxSize().background(Color(0xFFF1F3F4)))
        } else {
        val photo = t.photo
        if (t.bgType == 1 && photo != null) {
            Image(
                bitmap = photo,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(scaleX = 1.12f, scaleY = 1.12f)
                    .blur(t.blur.dp, BlurredEdgeTreatment.Unbounded)
            )
        } else {
            val cols = Presets[t.preset.coerceIn(0, Presets.size - 1)].colors
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(cols)))
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(t.accentColor.copy(alpha = 0.55f), Color.Transparent),
                        center = Offset(w * 0.15f, h * 0.2f),
                        radius = w * 0.9f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(cols.last().copy(alpha = 0.6f), Color.Transparent),
                        center = Offset(w * 0.9f, h * 0.75f),
                        radius = w * 1.0f
                    )
                )
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = t.dim)))
        }
    }
}

@Composable
fun GText(
    t: ThemeState,
    text: String,
    size: Int = 15,
    bold: Boolean = false,
    secondary: Boolean = false,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        modifier = modifier,
        color = if (secondary) t.secondaryTextColor else t.textColor,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        fontFamily = when (t.globalFont) { "Serif" -> androidx.compose.ui.text.font.FontFamily.Serif; "Mono" -> androidx.compose.ui.text.font.FontFamily.Monospace; "Cursive" -> androidx.compose.ui.text.font.FontFamily.Cursive; else -> androidx.compose.ui.text.font.FontFamily.SansSerif }
    )
}

@Composable
fun GlassCard(t: ThemeState, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier.fillMaxWidth().glass(t, t.cardRadius.dp).padding(16.dp),
        content = content
    )
}

@Composable
fun GButton(t: ThemeState, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interactionSource = androidx.compose.runtime.remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .glass(t, t.cardRadius.dp)
            .clickable(interactionSource = interactionSource, indication = if (t.pressEffects) LocalIndication.current else null, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        GText(t, label, 15, true)
    }
}

@Composable
fun GChip(t: ThemeState, label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .glass(t, 20.dp)
            .background(if (selected) t.accentColor.copy(alpha = 0.4f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        GText(t, label, 14, selected)
    }
}

@Composable
fun BottomBar(t: ThemeState, tab: Int, onTab: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .fillMaxWidth()
            .glass(t, 28.dp)
            .padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTabs.all.forEach { item ->
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (tab == item.id) t.accentColor.copy(alpha = 0.28f) else Color.Transparent)
                    .clickable { onTab(item.id) }
                    .padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = item.symbol,
                    color = t.textColor,
                    fontSize = 17.sp,
                    fontWeight = if (tab == item.id) FontWeight.Bold else FontWeight.Normal
                )
                Text(
                    text = item.shortTitle,
                    color = if (tab == item.id) t.textColor else t.secondaryTextColor,
                    fontSize = 8.sp,
                    maxLines = 1
                )
            }
        }
    }
}
