package com.example.glasstime

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object TelegramWallpaperStore {
    private const val FILE_NAME = "telegram_theme_wallpaper.jpg"
    private const val PREFS = "telegram_theme_wallpaper"

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    fun copyFromUri(context: Context, uri: Uri) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: error("Не удалось открыть изображение")
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Файл не является изображением" }
        var sample = 1
        while (bounds.outWidth / sample > 1400 || bounds.outHeight / sample > 1400) sample *= 2
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: error("Не удалось прочитать изображение")
        try {
            file(context).outputStream().use { out ->
                check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) { "Не удалось сохранить фон" }
            }
        } finally { bitmap.recycle() }
    }

    fun loadBitmap(context: Context): android.graphics.Bitmap? {
        val source = file(context).takeIf { it.exists() } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1000 || bounds.outHeight / sample > 1000) sample *= 2
        return BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun export(context: Context, uri: Uri) {
        val source = file(context)
        require(source.exists()) { "Сначала выбери изображение фона" }
        context.contentResolver.openOutputStream(uri)?.use { output -> source.inputStream().use { it.copyTo(output) } }
            ?: error("Не удалось экспортировать изображение")
    }

    fun hasWallpaper(context: Context) = file(context).exists()

    fun loadDim(context: Context): Float = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat("dim", 0.22f).coerceIn(0f, 0.8f)

    fun saveDim(context: Context, value: Float) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat("dim", value.coerceIn(0f, 0.8f)).apply()
    }
}
