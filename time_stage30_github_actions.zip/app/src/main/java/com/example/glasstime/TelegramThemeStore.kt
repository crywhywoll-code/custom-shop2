package com.example.glasstime

import android.content.Context
import org.json.JSONObject
import org.json.JSONArray

/** Local Telegram theme draft. Values are exported using Telegram Android .attheme color keys. */
data class TelegramTheme(
    val background: Int = 0xFF101216.toInt(),
    val panel: Int = 0xFF1B1F25.toInt(),
    val incomingBubble: Int = 0xFF292E35.toInt(),
    val outgoingBubble: Int = 0xFF343E4B.toInt(),
    val messageText: Int = 0xFFF2F3F5.toInt(),
    val accent: Int = 0xFF9CCFFF.toInt(),
    val actionBar: Int = 0xFF171A1F.toInt(),
    val actionText: Int = 0xFFFFFFFF.toInt(),
    val button: Int = 0xFF315477.toInt(),
    val iconColor: Int = 0xFFFFFFFF.toInt()
)

object TelegramThemeStore {
    data class SavedTheme(val name: String, val theme: TelegramTheme)
    private const val PREFS = "telegram_theme_draft"
    private const val SAVED_PREFS = "telegram_theme_presets"
    private const val SAVED_KEY = "themes"

    fun load(context: Context): TelegramTheme {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return TelegramTheme(
            background = p.getInt("background", 0xFF101216.toInt()),
            panel = p.getInt("panel", 0xFF1B1F25.toInt()),
            incomingBubble = p.getInt("incoming", 0xFF292E35.toInt()),
            outgoingBubble = p.getInt("outgoing", 0xFF343E4B.toInt()),
            messageText = p.getInt("text", 0xFFF2F3F5.toInt()),
            accent = p.getInt("accent", 0xFF9CCFFF.toInt()),
            actionBar = p.getInt("action_bar", 0xFF171A1F.toInt()),
            actionText = p.getInt("action_text", 0xFFFFFFFF.toInt()),
            button = p.getInt("button", 0xFF315477.toInt()),
            iconColor = p.getInt("icon", 0xFFFFFFFF.toInt())
        )
    }

    fun save(context: Context, theme: TelegramTheme) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("background", theme.background).putInt("panel", theme.panel)
            .putInt("incoming", theme.incomingBubble).putInt("outgoing", theme.outgoingBubble)
            .putInt("text", theme.messageText).putInt("accent", theme.accent)
            .putInt("action_bar", theme.actionBar).putInt("action_text", theme.actionText)
            .putInt("button", theme.button).putInt("icon", theme.iconColor)
            .apply()
    }

    fun saveNamed(context: Context, name: String, theme: TelegramTheme) {
        val clean = name.trim().take(32)
        require(clean.isNotBlank()) { "Укажи название темы" }
        val all = saved(context).filterNot { it.name.equals(clean, true) }.toMutableList()
        require(all.size <= 19) { "Можно сохранить не более 20 тем" }
        all.add(0, SavedTheme(clean, theme))
        val array = JSONArray()
        all.forEach { array.put(JSONObject().put("name", it.name).put("theme", toJson(it.theme))) }
        context.getSharedPreferences(SAVED_PREFS, Context.MODE_PRIVATE).edit().putString(SAVED_KEY, array.toString()).apply()
    }

    fun saved(context: Context): List<SavedTheme> = runCatching {
        val raw = context.getSharedPreferences(SAVED_PREFS, Context.MODE_PRIVATE).getString(SAVED_KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val name = item.optString("name").trim().take(32)
            if (name.isBlank()) null else SavedTheme(name, fromJson(item.optJSONObject("theme") ?: JSONObject()))
        }
    }.getOrDefault(emptyList())

    fun deleteNamed(context: Context, name: String) {
        val array = JSONArray()
        saved(context).filterNot { it.name == name }.forEach {
            array.put(JSONObject().put("name", it.name).put("theme", toJson(it.theme)))
        }
        context.getSharedPreferences(SAVED_PREFS, Context.MODE_PRIVATE).edit().putString(SAVED_KEY, array.toString()).apply()
    }

    private fun toJson(theme: TelegramTheme) = JSONObject().apply {
        put("background", theme.background); put("panel", theme.panel)
        put("incoming", theme.incomingBubble); put("outgoing", theme.outgoingBubble)
        put("text", theme.messageText); put("accent", theme.accent)
        put("actionBar", theme.actionBar); put("actionText", theme.actionText)
        put("button", theme.button); put("icon", theme.iconColor)
    }

    private fun fromJson(j: JSONObject): TelegramTheme {
        val d = TelegramTheme()
        return d.copy(
            background = j.optInt("background", d.background), panel = j.optInt("panel", d.panel),
            incomingBubble = j.optInt("incoming", d.incomingBubble), outgoingBubble = j.optInt("outgoing", d.outgoingBubble),
            messageText = j.optInt("text", d.messageText), accent = j.optInt("accent", d.accent),
            actionBar = j.optInt("actionBar", d.actionBar), actionText = j.optInt("actionText", d.actionText),
            button = j.optInt("button", d.button), iconColor = j.optInt("icon", d.iconColor)
        )
    }

    fun export(theme: TelegramTheme): ByteArray {
        fun rgb(color: Int) = "#%06X".format(color and 0x00FFFFFF)
        val lines = linkedMapOf(
            "// time個 · Telegram Android theme" to "",
            "windowBackgroundWhite" to rgb(theme.background),
            "windowBackgroundGray" to rgb(theme.panel),
            "actionBarDefault" to rgb(theme.actionBar),
            "actionBarDefaultTitle" to rgb(theme.actionText),
            "chat_inBubble" to rgb(theme.incomingBubble),
            "chat_outBubble" to rgb(theme.outgoingBubble),
            "chat_messageTextIn" to rgb(theme.messageText),
            "chat_messageTextOut" to rgb(theme.messageText),
            "chat_linkSelectBackground" to rgb(theme.accent),
            "featuredStickers_addButton" to rgb(theme.button),
            "chat_goDownButton" to rgb(theme.button),
            "actionBarDefaultIcon" to rgb(theme.iconColor)
        )
        return lines.entries.joinToString("\n") { (key, value) -> if (key.startsWith("//")) key else "$key=$value" }
            .toByteArray(Charsets.UTF_8)
    }

    fun import(bytes: ByteArray): TelegramTheme {
        require(bytes.isNotEmpty() && bytes.size <= 256 * 1024) { "Файл пустой или слишком большой" }
        val values = mutableMapOf<String, Int>()
        bytes.toString(Charsets.UTF_8).lineSequence().forEach { line ->
            val clean = line.trim()
            if (clean.isEmpty() || clean.startsWith("//") || clean.startsWith("#")) return@forEach
            val split = clean.split('=', limit = 2)
            if (split.size != 2) return@forEach
            parseColor(split[1])?.let { values[split[0].trim()] = it }
        }
        require(values.isNotEmpty()) { "Не найдены поддерживаемые цвета .attheme" }
        val defaults = TelegramTheme()
        return defaults.copy(
            background = values["windowBackgroundWhite"] ?: defaults.background,
            panel = values["windowBackgroundGray"] ?: defaults.panel,
            actionBar = values["actionBarDefault"] ?: defaults.actionBar,
            actionText = values["actionBarDefaultTitle"] ?: defaults.actionText,
            button = values["featuredStickers_addButton"] ?: values["chat_goDownButton"] ?: defaults.button,
            iconColor = values["actionBarDefaultIcon"] ?: defaults.iconColor,
            incomingBubble = values["chat_inBubble"] ?: defaults.incomingBubble,
            outgoingBubble = values["chat_outBubble"] ?: defaults.outgoingBubble,
            messageText = values["chat_messageTextIn"] ?: defaults.messageText,
            accent = values["chat_linkSelectBackground"] ?: values["featuredStickers_addButton"] ?: defaults.accent
        )
    }

    private fun parseColor(raw: String): Int? = runCatching {
        val value = raw.trim().removePrefix("#")
        when (value.length) {
            6 -> (0xFF000000L or value.toLong(16)).toInt()
            8 -> value.toLong(16).toInt()
            else -> raw.trim().toInt()
        }
    }.getOrNull()
}
