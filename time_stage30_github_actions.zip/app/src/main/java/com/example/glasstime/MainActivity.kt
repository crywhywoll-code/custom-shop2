package com.example.glasstime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.example.glasstime.data.local.LocalNavigationRepository
import com.example.glasstime.domain.repository.NavigationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val theme = ThemeState(getSharedPreferences("glass", MODE_PRIVATE))
        val navigation = LocalNavigationRepository(getSharedPreferences("navigation", MODE_PRIVATE))
        setContent {
            LaunchedEffect(Unit) {
                theme.photo = withContext(Dispatchers.IO) { PhotoStore.load(applicationContext) }
                theme.navBlockPhoto = withContext(Dispatchers.IO) { PhotoStore.loadBlock(applicationContext, "nav") }
                theme.cardBlockPhoto = withContext(Dispatchers.IO) { PhotoStore.loadBlock(applicationContext, "card") }
            }
            MaterialTheme(colorScheme = darkColorScheme()) {
                App(theme, navigation)
            }
        }
    }
}

@Composable
fun App(t: ThemeState, navigation: NavigationRepository) {
    val pagerState = rememberPagerState(
        initialPage = navigation.selectedTab(),
        pageCount = { 6 }
    )
    val scope = rememberCoroutineScope()
    var showSplash by remember { mutableStateOf(t.splashEnabled) }
    LaunchedEffect(t.splashEnabled, t.splashDuration) {
        if (t.splashEnabled) { showSplash = true; delay(t.splashDuration.toLong()); showSplash = false }
    }
    LaunchedEffect(pagerState.currentPage) {
        navigation.saveSelectedTab(pagerState.currentPage)
    }

    Box(Modifier.fillMaxSize()) {
        Background(t)
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Box(Modifier.weight(1f)) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondViewportPageCount = 1
                ) { page ->
                    val distance = abs(pagerState.currentPage - page + pagerState.currentPageOffsetFraction)
                    Box(
                        Modifier.fillMaxSize().graphicsLayer {
                            alpha = (1f - distance * 0.18f).coerceIn(0.82f, 1f)
                        }
                    ) {
                        when (page) {
                            0 -> UsageScreen(t)
                            1 -> PlayerScreen(t)
                            2 -> WidgetStudioScreen(t)
                            3 -> TelegramThemesScreen(t)
                            4 -> StyleScreen(t)
                            5 -> ProfileScreen(t)
                        }
                    }
                }
            }
            BottomBar(t, pagerState.currentPage) { target ->
                scope.launch { pagerState.animateScrollToPage(target) }
            }
        }
        val enter = when (t.splashAnimation) {
            "Scale" -> fadeIn() + scaleIn(initialScale = 0.88f)
            "Slide" -> fadeIn() + slideInVertically(initialOffsetY = { it / 5 })
            else -> fadeIn()
        }
        AnimatedVisibility(visible = showSplash, enter = enter, exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color(0xFF08090B)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.material3.Text("time个", color = Color.White, fontSize = 34.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    androidx.compose.material3.Text("by kodokuzawa", color = Color.White.copy(alpha = 0.62f), fontSize = 12.sp)
                }
            }
        }
    }
}
